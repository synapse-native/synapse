// Generado por Synapse (auto-hospedado)
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <pthread.h>
typedef struct {int longitud;const char* datos;} CadenaSegura;
typedef struct {uint32_t filas;uint32_t columnas;float* datos;} Tensor;
typedef struct {FILE* stream;int es_valido;int es_virtual;const char* virtual_data;int virtual_len;} Canal;
#define POOL_BLOQUES 64
#define TAMANO_BLOQUE 4096
#define nulo ((void*)0)
// --- Declaraciones extern del runtime precompilado (synapse_rt.o) ---
extern void escribir(CadenaSegura contenido);
extern void escribir_linea(CadenaSegura contenido);
extern CadenaSegura leer_linea(void);
extern Canal abrir(CadenaSegura ruta, CadenaSegura modo);
extern CadenaSegura leer(Canal canal);
extern void cerrar(Canal canal);
extern Tensor crear_tensor(int filas, int columnas);
extern Tensor suma_tensor(Tensor a, Tensor b);
extern Tensor producto_punto(Tensor a, Tensor b);
extern Tensor relu(Tensor a);
extern Tensor reserva(int tamano);
extern void libera(Tensor bloque);
extern Tensor suma(Tensor a, Tensor b);
extern Tensor producto(Tensor a, Tensor b);
extern int texto_a_entero(CadenaSegura str);
extern float texto_a_decimal(CadenaSegura str);
extern CadenaSegura decimal_a_texto(float n);
extern CadenaSegura entero_a_texto(int n);
extern void synapse_lanzar_hilo(void* (*fn)(void*), void* arg);
extern void synapse_esperar_hilos(void);
extern void pool_init(uint32_t total_blocks, uint32_t block_size);
extern void pool_free(void* ptr);
static int _g_argc;
static char** _g_argv;
int _argc(){return _g_argc;}
CadenaSegura _argv(int i){if(i<0||i>=_g_argc)return (CadenaSegura){0,(char*)""};return (CadenaSegura){.longitud=(int)strlen(_g_argv[i]),.datos=_g_argv[i]};}
void salir(int c){exit(c);}
CadenaSegura concat(CadenaSegura a,CadenaSegura b){int _tl=a.longitud+b.longitud;char* _buf=(char*)malloc(_tl+1);memcpy(_buf,a.datos,a.longitud);memcpy(_buf+a.longitud,b.datos,b.longitud);_buf[_tl]=0;CadenaSegura _r={.longitud=_tl,.datos=_buf};return _r;}
void principal();
/* importar std.io */
void principal()
{
    escribir_linea((CadenaSegura){.longitud=38,.datos="======================================"});
    escribir_linea((CadenaSegura){.longitud=27,.datos="  Bienvenido a Synapse v2.0"});
    escribir_linea((CadenaSegura){.longitud=36,.datos="  Lenguaje de programacion poliglota"});
    escribir_linea((CadenaSegura){.longitud=38,.datos="======================================"});
    escribir((CadenaSegura){.longitud=16,.datos="Como te llamas? "});
    CadenaSegura nombre = leer_linea();
    escribir_linea((CadenaSegura){.longitud=0,.datos=""});
    escribir((CadenaSegura){.longitud=13,.datos="Mucho gusto, "});
    escribir_linea(nombre);
    escribir_linea((CadenaSegura){.longitud=37,.datos="Synapse te da la bienvenida al futuro"});
    escribir_linea((CadenaSegura){.longitud=33,.datos="de la programacion con IA nativa."});
}
int main(int argc, char** argv) {
    int _g_argc=argc;
    char** _g_argv=argv;
    pool_init(POOL_BLOQUES, TAMANO_BLOQUE);
    principal();
    synapse_esperar_hilos();
    return 0;
}
