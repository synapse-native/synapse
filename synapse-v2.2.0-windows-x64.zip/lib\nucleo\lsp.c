// salida_metal.c - Generado por Synapse Compilador
// Lenguaje: Synapse v1.0 (#lang: es)
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <pthread.h>
#include <string.h>
#include <assert.h>

typedef struct { int longitud; const char* datos; } CadenaSegura;

typedef struct { uint32_t filas; uint32_t columnas; float* datos; int es_mapeado; } Tensor;

typedef struct { FILE* stream; int es_valido; int es_virtual; const char* virtual_data; int virtual_len; } Canal;

#define nulo ((void*)0)
#define verdadero 1
#define falso 0

// --- OO AST node types ---
struct Token;
struct Nodo;
struct ListaNodo;
struct Programa;
struct Identificador;
struct LiteralNumero;
struct LiteralCadena;
struct OpBinaria;
struct OpUnaria;
struct LlamadaFuncion;
struct ExprAccesoCampo;
struct AsignacionVariable;
struct AsignacionCampo;
struct SentenciaSi;
struct SentenciaMientras;
struct SentenciaRetornar;
struct SentenciaExpr;
struct LogLlamada;
struct Parametro;
struct ListaParametro;
struct DefinicionFuncion;
struct DefinicionEstructura;
struct SentenciaRomper;
struct SentenciaSiguiente;
struct SentenciaLanzar;
struct SentenciaRecuperar;
struct SentenciaEscuchar;
struct ExprTensor;
struct ExprIndice;
struct ArgumentoTransferido;
struct SentenciaImportar;
struct ImportarC;
struct DeclaracionExterna;
struct DeclaracionVariable;
struct BloqueInseguro;
struct ExprObtenerDireccion;
struct ExprDereferencia;

typedef struct Token { int tipo; CadenaSegura lexema; int linea; int columna; } Token;
typedef struct Nodo { CadenaSegura tipo; } Nodo;
typedef struct ListaNodo { struct Nodo* cabeza; struct ListaNodo* cola; } ListaNodo;
typedef struct Programa { CadenaSegura tipo; struct ListaNodo* sentencias; } Programa;

#define POOL_BLOQUES 64
#define TAMANO_BLOQUE 4096

#define _GEN_TMP_SIZE (4096)
#include "librerias/embedded_libs.h"

char _gen_tmp_buf[4096];

char _G_emit_buf[1048576];
int _G_emit_pos = 0;
FILE* _G_fp = NULL;

extern int _G_indent;

const char* _G_mt(const char* st);
void _G_vest(struct DefinicionEstructura* n);

#define TAG_OK 0
#define TAG_ERR 1
#define TAG_ALGUNO 0
#define TAG_NINGUNO 1

// --- Helpers de serialización primitiva ---
inline void* _synapse_box_int(int v) { return (void*)(intptr_t)v; }
inline int _synapse_unbox_int(void* p) { return (int)(intptr_t)p; }
inline void* _synapse_box_float(float v) {
    float* _p = (float*)malloc(sizeof(float));
    if (!_p) { fprintf(stderr, "ESCAPA_DEL_ALCANCE: malloc fallo\\n"); exit(1); }
    *_p = v;
    return (void*)_p;
}
inline float _synapse_unbox_float(void* p) {
    float _v = *(float*)p;
    free(p);
    return _v;
}

extern void pool_init(uint32_t total_blocks, uint32_t block_size);
extern void pool_free(void* ptr);
extern void escribir(CadenaSegura contenido);
extern void escribir_linea(CadenaSegura contenido);
extern CadenaSegura leer_linea(void);
extern Canal abrir(CadenaSegura ruta, CadenaSegura modo);
extern CadenaSegura leer(Canal canal);
extern void cerrar(Canal canal);
extern Tensor crear_tensor(int filas, int columnas);
extern Tensor suma_tensor(Tensor a, Tensor b);
extern Tensor producto_punto(Tensor a, Tensor b);
extern Tensor relu(Tensor a);
extern Tensor reserva(int tamano);
extern void libera(Tensor bloque);
extern Tensor suma(Tensor a, Tensor b);
extern Tensor producto(Tensor a, Tensor b);
extern int texto_a_entero(CadenaSegura str);
extern float texto_a_decimal(CadenaSegura str);
extern CadenaSegura decimal_a_texto(float n);
extern CadenaSegura entero_a_texto(int n);
extern void synapse_lanzar_hilo(void* (*fn)(void*), void* arg);
extern void synapse_esperar_hilos(void);
extern void _syn_texto_liberar(CadenaSegura s);

typedef struct { int es_ok; union {
void* ok_valor; const char* err_mensaje;
} datos; } Resultado_T;
typedef struct CanalConcurrencia CanalConcurrencia;
extern CanalConcurrencia* canal_crear(uint32_t capacidad);
extern void canal_enviar(CanalConcurrencia* canal, void* paquete);
extern void* canal_recibir(CanalConcurrencia* canal);
extern void canal_destruir(CanalConcurrencia* canal);
extern void cerrar_canal(CanalConcurrencia* canal);
// --- Contratos (requiere/garantiza) ---
#ifdef SYNAPSE_RELEASE
#define assert_contrato(expr, msg) ((void)0)
#else
#define assert_contrato(expr, msg) \
    do { if (!(expr)) { \
        fprintf(stderr, "CONTRATO: %s en %%s:%%d\\n", \
                msg, __FILE__, __LINE__); \
        exit(1); }} while(0)
#endif

int _g_argc;
char** _g_argv;
int _argc() { return _g_argc; }

CadenaSegura _argv(int i) {
    if (i < 0 || i >= _g_argc) return (CadenaSegura){0, ""};
    return (CadenaSegura){ .longitud = (int)strlen(_g_argv[i]), .datos = _g_argv[i] };
}

void salir(int codigo) { exit(codigo); }

CadenaSegura concat(CadenaSegura a, CadenaSegura b) {
    int _tl = a.longitud + b.longitud;
    char* _buf = (char*)malloc(_tl + 1);
    if (!_buf) { fprintf(stderr,"Error: malloc fallo en concat()\\n"); exit(1); }
    memcpy(_buf, a.datos, a.longitud);
    memcpy(_buf + a.longitud, b.datos, b.longitud);
    _buf[_tl] = 0;
    return (CadenaSegura){_tl, _buf};
}

struct TokenLex;
struct LexerEstado;
struct Token;
struct Nodo;
struct ListaNodo;
struct Programa;
struct Identificador;
struct LiteralNumero;
struct LiteralCadena;
struct OpBinaria;
struct OpUnaria;
struct LlamadaFuncion;
struct ExprAccesoCampo;
struct AsignacionVariable;
struct DeclaracionVariable;
struct AsignacionCampo;
struct SentenciaSi;
struct SentenciaMientras;
struct SentenciaRetornar;
struct SentenciaExpr;
struct LogLlamada;
struct Parametro;
struct ListaParametro;
struct DefinicionFuncion;
struct DefinicionEstructura;
struct SentenciaRomper;
struct SentenciaSiguiente;
struct SentenciaLanzar;
struct SentenciaRecuperar;
struct SentenciaEscuchar;
struct ExprTensor;
struct ExprIndice;
struct ArgumentoTransferido;
struct SentenciaImportar;
struct BloqueInseguro;
struct ExprObtenerDireccion;
struct ExprDereferencia;
struct ImportarC;
struct DeclaracionExterna;
struct ExprCrearCanal;
struct SentenciaEnviarCanal;
struct ExprRecibirCanal;
struct ReporteError;
struct GestorDiagnostico;
struct TokenExt;
struct NodoAST;
struct ParserEst;
struct Simbolo;
struct TablaSimbolos;
struct SemNodo;
struct SemSimbolo;
struct SemTablaSimbolos;
struct SemEstructuraInfo;
struct AnalizadorSemanticoEst;
struct GeneradorCEst;
struct DepNoDeclaradaError;
struct Resultado;
struct Opcion;
struct ParJson;
struct NodoJson;

typedef struct TokenLex {
    int tipo;
    int linea;
    int columna;
    CadenaSegura valor;
} TokenLex;

typedef struct LexerEstado {
    int ptr_fuente;
    int len_fuente;
    int posicion;
    int linea_actual;
    int columna_actual;
    struct TokenLex* tokens;
    int total_tokens;
    int pila_indent[64];
    int nivel_pila;
    int hay_error;
    CadenaSegura error_mensaje;
    int error_linea;
    int error_columna;
} LexerEstado;

typedef struct Identificador {
    CadenaSegura tipo;
    CadenaSegura nombre;
} Identificador;

typedef struct LiteralNumero {
    CadenaSegura tipo;
    int valor;
} LiteralNumero;

typedef struct LiteralCadena {
    CadenaSegura tipo;
    CadenaSegura valor;
} LiteralCadena;

typedef struct OpBinaria {
    CadenaSegura tipo;
    struct Nodo* izquierdo;
    struct Token* operador;
    struct Nodo* derecho;
} OpBinaria;

typedef struct OpUnaria {
    CadenaSegura tipo;
    struct Token* operador;
    struct Nodo* expr;
} OpUnaria;

typedef struct LlamadaFuncion {
    CadenaSegura tipo;
    CadenaSegura nombre;
    struct ListaNodo* argumentos;
} LlamadaFuncion;

typedef struct ExprAccesoCampo {
    CadenaSegura tipo;
    struct Nodo* objeto;
    CadenaSegura nombre_campo;
} ExprAccesoCampo;

typedef struct AsignacionVariable {
    CadenaSegura tipo;
    CadenaSegura nombre;
    struct Nodo* expresion;
} AsignacionVariable;

typedef struct DeclaracionVariable {
    CadenaSegura tipo;
    CadenaSegura nombre;
    struct Nodo* expresion;
    int linea;
    int columna;
} DeclaracionVariable;

typedef struct AsignacionCampo {
    CadenaSegura tipo;
    struct Nodo* objeto;
    CadenaSegura nombre_campo;
    struct Nodo* expresion;
} AsignacionCampo;

typedef struct SentenciaSi {
    CadenaSegura tipo;
    struct Nodo* condicion;
    struct ListaNodo* cuerpo;
    struct ListaNodo* cuerpo_sino;
} SentenciaSi;

typedef struct SentenciaMientras {
    CadenaSegura tipo;
    struct Nodo* condicion;
    struct ListaNodo* cuerpo;
} SentenciaMientras;

typedef struct SentenciaRetornar {
    CadenaSegura tipo;
    struct Nodo* expr;
} SentenciaRetornar;

typedef struct SentenciaExpr {
    CadenaSegura tipo;
    struct Nodo* expr;
} SentenciaExpr;

typedef struct LogLlamada {
    CadenaSegura tipo;
    struct ListaNodo* argumentos;
} LogLlamada;

typedef struct Parametro {
    CadenaSegura tipo;
    CadenaSegura nombre;
    CadenaSegura tipo_param;
    int es_transferencia;
} Parametro;

typedef struct ListaParametro {
    struct Parametro* cabeza;
    struct ListaParametro* cola;
} ListaParametro;

typedef struct DefinicionFuncion {
    CadenaSegura tipo;
    CadenaSegura nombre;
    struct ListaParametro* parametros;
    CadenaSegura tipo_retorno;
    struct ListaNodo* requiere;
    struct ListaNodo* garantiza;
    struct ListaNodo* cuerpo;
} DefinicionFuncion;

typedef struct DefinicionEstructura {
    CadenaSegura tipo;
    CadenaSegura nombre;
    struct ListaParametro* campos;
} DefinicionEstructura;

typedef struct SentenciaRomper {
    CadenaSegura tipo;
} SentenciaRomper;

typedef struct SentenciaSiguiente {
    CadenaSegura tipo;
} SentenciaSiguiente;

typedef struct SentenciaLanzar {
    CadenaSegura tipo;
    struct Nodo* llamada;
} SentenciaLanzar;

typedef struct SentenciaRecuperar {
    CadenaSegura tipo;
    struct Nodo* accion_critica;
    struct Nodo* plan_b;
} SentenciaRecuperar;

typedef struct SentenciaEscuchar {
    CadenaSegura tipo;
    struct Nodo* canal;
    struct Nodo* respuesta;
} SentenciaEscuchar;

typedef struct ExprTensor {
    CadenaSegura tipo;
    struct Nodo* filas;
    struct Nodo* columnas;
} ExprTensor;

typedef struct ExprIndice {
    CadenaSegura tipo;
    struct Nodo* expr;
    struct Nodo* indice;
} ExprIndice;

typedef struct ArgumentoTransferido {
    CadenaSegura tipo;
    struct Nodo* expr;
} ArgumentoTransferido;

typedef struct SentenciaImportar {
    CadenaSegura tipo;
    CadenaSegura ruta;
} SentenciaImportar;

typedef struct BloqueInseguro {
    CadenaSegura tipo;
    struct ListaNodo* cuerpo;
} BloqueInseguro;

typedef struct ExprObtenerDireccion {
    CadenaSegura tipo;
    struct Nodo* expr;
} ExprObtenerDireccion;

typedef struct ExprDereferencia {
    CadenaSegura tipo;
    struct Nodo* expr;
} ExprDereferencia;

typedef struct ImportarC {
    CadenaSegura tipo;
    CadenaSegura ruta;
    int es_sistema;
} ImportarC;

typedef struct DeclaracionExterna {
    CadenaSegura tipo;
    CadenaSegura nombre;
    struct ListaParametro* parametros;
    CadenaSegura tipo_retorno;
} DeclaracionExterna;

typedef struct ExprCrearCanal {
    CadenaSegura tipo;
    CadenaSegura tipo_contenido;
    struct Nodo* capacidad;
} ExprCrearCanal;

typedef struct SentenciaEnviarCanal {
    CadenaSegura tipo;
    struct Nodo* canal;
    struct Nodo* valor;
} SentenciaEnviarCanal;

typedef struct ExprRecibirCanal {
    CadenaSegura tipo;
    struct Nodo* canal;
} ExprRecibirCanal;

typedef struct ReporteError {
    int codigo;
    int linea;
    int columna;
    CadenaSegura mensaje;
} ReporteError;

typedef struct GestorDiagnostico {
    struct ReporteError* reportes;
    int total_reportes;
    int capacidad;
    CadenaSegura idioma;
    CadenaSegura ruta_archivo;
} GestorDiagnostico;

typedef struct TokenExt {
    int tipo;
    int linea;
    int columna;
    int ptr_valor;
    int len_valor;
} TokenExt;

typedef struct NodoAST {
    int tipo_nodo;
    int linea;
    int columna;
    int valor_int;
    float valor_dec;
    int ptr_str;
    int len_str;
    int hijo_izq;
    int hijo_der;
    int hermano;
    int ptr_extra;
} NodoAST;

typedef struct ParserEst {
    struct TokenExt* tokens;
    int total_tokens;
    int posicion;
    struct NodoAST* nodos;
    int total_nodos;
    int hay_error;
    CadenaSegura error_mensaje;
    int error_linea;
    int error_columna;
    int es_sin_std;
    int ptr_hi;
    int max_nodos;
} ParserEst;

typedef struct Simbolo {
    CadenaSegura nombre;
    CadenaSegura tipo;
    struct Nodo* nodo;
    int nivel_ambito;
    int propiedad;
    int es_constante;
    CadenaSegura uri;
    int linea;
    int columna;
} Simbolo;

typedef struct TablaSimbolos {
    struct Simbolo* entradas;
    int total_entradas;
    int nivel_actual;
} TablaSimbolos;

typedef struct SemNodo {
    int tipo_nodo;
    int linea;
    int columna;
    int valor_int;
    float valor_dec;
    int ptr_str;
    int len_str;
    int hijo_izq;
    int hijo_der;
    int hermano;
    int ptr_extra;
} SemNodo;

typedef struct SemSimbolo {
    CadenaSegura nombre;
    CadenaSegura tipo;
    int nivel_ambito;
    int propiedad;
    int es_constante;
    int linea;
    int columna;
} SemSimbolo;

typedef struct SemTablaSimbolos {
    struct SemSimbolo* entradas;
    int total_entradas;
    int nivel_actual;
} SemTablaSimbolos;

typedef struct SemEstructuraInfo {
    CadenaSegura nombre;
    CadenaSegura campos_nombre;
    CadenaSegura campos_tipo;
    int total_campos;
} SemEstructuraInfo;

typedef struct AnalizadorSemanticoEst {
    struct SemNodo* nodos;
    int total_nodos;
    struct SemTablaSimbolos* tabla;
    CadenaSegura func_retorno;
    CadenaSegura func_actual;
    int en_coincidir;
    int dentro_de_inseguro;
    int hay_error;
    struct SemEstructuraInfo* info_estructuras;
    int total_estructuras;
    CadenaSegura asignaciones_campos_var;
    CadenaSegura asignaciones_campos_campo;
    CadenaSegura asignaciones_campos_tipo;
    int total_asignaciones;
} AnalizadorSemanticoEst;

typedef struct GeneradorCEst {
    int buf_lineas;
    int buf_capacidad;
    int buf_longitud;
    int indent_actual;
    int archivo_actual;
    int contador_thread;
    int contador_listener;
    int funciones_emitidas;
    CadenaSegura func_emitidas_nombres;
    CadenaSegura func_return_types_nombres;
    CadenaSegura func_return_types_tipos;
    int func_return_types_total;
    int in_function_scope;
    CadenaSegura var_nombres;
    CadenaSegura var_tipos;
    int var_total;
    int var_capacidad;
    CadenaSegura const_types_nombres;
    CadenaSegura const_types_tipos;
    int const_types_total;
    CadenaSegura scope_var_nombres;
    CadenaSegura scope_var_tipos;
    int scope_var_total;
    int scope_stack_top;
    int scope_stack_at;
    CadenaSegura tensor_vars;
    int tensor_vars_total;
    CadenaSegura tensor_transferidas;
    int tensor_transferidas_total;
    CadenaSegura canal_vars;
    int canal_vars_total;
    CadenaSegura canal_cerradas;
    int canal_cerradas_total;
    CadenaSegura listener_funciones;
    int listener_total;
    CadenaSegura struct_nombres;
    int struct_total;
    CadenaSegura struct_nombres_c;
    int struct_total_c;
    CadenaSegura extern_nombres;
    CadenaSegura extern_params;
    int extern_total;
    CadenaSegura dtor_tipos;
    CadenaSegura dtor_funcs;
    int dtor_total;
    int gen_tok_emitido;
    int gen_parse_emitido;
    int gen_defs_emitido;
    CadenaSegura garantizas_nombres;
    CadenaSegura garantizas_valores;
    int garantizas_total;
    int es_no_std;
    CadenaSegura linker_libs;
    int linker_libs_total;
    CadenaSegura build_buf;
    CadenaSegura func_retorno_actual;
    CadenaSegura strings_heap;
    int strings_heap_total;
} GeneradorCEst;

typedef struct DepNoDeclaradaError {
    CadenaSegura mensaje;
} DepNoDeclaradaError;

typedef struct Resultado {
    int tag;
    union {
        int valor;
        CadenaSegura valor_str;
        float valor_float;
    } dato;
} Resultado;

typedef struct Opcion {
    int tag;
    union {
        int valor;
        CadenaSegura valor_str;
        float valor_float;
    } dato;
} Opcion;

typedef struct ParJson {
    CadenaSegura clave;
    struct NodoJson* valor;
} ParJson;

typedef struct NodoJson {
    int tipo;
    int valor_bool;
    float valor_num;
    CadenaSegura valor_str;
    struct NodoJson* arreglo_hijos;
    struct ParJson* objeto_pares;
    int longitud;
} NodoJson;

int str_len(CadenaSegura s);
int str_char(CadenaSegura s, int i);
int str_char_at(int ptr, int i);
int str_eq(CadenaSegura a, CadenaSegura b);
int str_len_ptr(int ptr);
int keyword_token(CadenaSegura palabra);
int es_digito(int c);
int es_letra(int c);
int es_alnum(int c);
void lexer_push_token(struct LexerEstado lex, int tipo, int linea, int columna);
void lexer_error(struct LexerEstado lex, CadenaSegura mensaje, int linea, int columna);
void lexer_detectar_idioma(struct LexerEstado lex);
void lexer_procesar_indentacion(struct LexerEstado lex, int ptr_linea, int len_linea);
void lexer_tokenizar_linea(struct LexerEstado lex, int ptr_texto, int len_texto);
int tokenizar(CadenaSegura fuente);
struct GestorDiagnostico gestor_nuevo(CadenaSegura idioma, CadenaSegura ruta, int capacidad);
void reportar_error(struct GestorDiagnostico diag, int codigo, int linea, int columna, CadenaSegura mensaje);
int hay_errores(struct GestorDiagnostico diag);
int contar_errores(struct GestorDiagnostico diag);
int codigo_salida(struct GestorDiagnostico diag);
CadenaSegura resumen_errores(struct GestorDiagnostico diag);
CadenaSegura obtener_plantilla_error(int codigo, CadenaSegura idioma);
CadenaSegura obtener_linea_contexto(CadenaSegura lineas, int linea_num);
CadenaSegura formatear_entrada_error(CadenaSegura ruta, int linea, int columna, CadenaSegura mensaje);
CadenaSegura formatear_ubicacion(CadenaSegura ruta, int linea, int columna);
int parser_nuevo_nodo(struct ParserEst est, int tipo, int linea, int columna);
void parser_error(struct ParserEst est, CadenaSegura mensaje, int linea, int columna);
int token_tipo(struct ParserEst est, int pos);
int token_linea(struct ParserEst est, int pos);
int token_columna(struct ParserEst est, int pos);
void token_avanzar(struct ParserEst est);
int token_mirar(struct ParserEst est);
int token_esperar(struct ParserEst est, int esperado);
int token_esperar_texto(struct ParserEst est, int esperado);
int parsear_expresion(struct ParserEst est);
int parsear_logica(struct ParserEst est);
int parsear_comparacion(struct ParserEst est);
int parsear_adicion(struct ParserEst est);
int parsear_multiplicacion(struct ParserEst est);
int parsear_unario(struct ParserEst est);
int parsear_primario(struct ParserEst est);
int parsear_sentencia(struct ParserEst est);
int parsear_funcion(struct ParserEst est);
int parsear_si(struct ParserEst est);
int parsear_mientras(struct ParserEst est);
int parsear_para(struct ParserEst est);
int parsear_retornar(struct ParserEst est);
int parsear_lanzar(struct ParserEst est);
int parsear_escuchar(struct ParserEst est);
int parsear_asignacion(struct ParserEst est);
int parsear_estructura_def(struct ParserEst est);
int parsear_constante(struct ParserEst est);
int parsear_asm(struct ParserEst est);
int parsear_inseguro(struct ParserEst est);
int parsear_importar_c(struct ParserEst est);
int parsear_externo(struct ParserEst est);
int parsear_coincidir(struct ParserEst est);
int parsear_enviar_canal(struct ParserEst est);
int parsear_crear_canal(struct ParserEst est);
int parsear_recibir_canal(struct ParserEst est);
struct Programa parsear(CadenaSegura fuente);
void sem_error(struct AnalizadorSemanticoEst est, int codigo, int idx_nodo, CadenaSegura mensaje);
int tabla_declarar(struct AnalizadorSemanticoEst est, CadenaSegura nombre, CadenaSegura tipo, int idx_nodo, int es_constante);
int tabla_buscar(struct AnalizadorSemanticoEst est, CadenaSegura nombre);
void tabla_entrar_scope(struct AnalizadorSemanticoEst est);
void tabla_salir_scope(struct AnalizadorSemanticoEst est);
void tabla_marcar_movido(struct AnalizadorSemanticoEst est, CadenaSegura nombre);
int tabla_esta_movido(struct AnalizadorSemanticoEst est, CadenaSegura nombre);
CadenaSegura tipo_normalizado(CadenaSegura tipo);
int es_builtin(CadenaSegura nombre);
int builtin_cantidad_args(CadenaSegura nombre);
CadenaSegura builtin_tipo_retorno(CadenaSegura nombre);
CadenaSegura builtin_tipo_parametro(CadenaSegura nombre, int idx);
int nodo_tipo(struct AnalizadorSemanticoEst est, int idx);
int nodo_linea(struct AnalizadorSemanticoEst est, int idx);
int nodo_hijo_izq(struct AnalizadorSemanticoEst est, int idx);
int nodo_hijo_der(struct AnalizadorSemanticoEst est, int idx);
int nodo_hermano(struct AnalizadorSemanticoEst est, int idx);
void registrar_estructura(struct AnalizadorSemanticoEst est, CadenaSegura nombre, int idx_nodo);
int parsear_patron_coincidir(CadenaSegura patron, CadenaSegura tag_nombre, CadenaSegura var_nombre);
void analizar_sentencia(struct AnalizadorSemanticoEst est, int idx_nodo);
void analizar_paso_estructuras(struct AnalizadorSemanticoEst est, int idx_programa);
void analizar_paso_funciones(struct AnalizadorSemanticoEst est, int idx_programa);
void analizar_paso_cuerpos(struct AnalizadorSemanticoEst est, int idx_programa);
void analizar(struct AnalizadorSemanticoEst est);
struct AnalizadorSemanticoEst analizador_nuevo(struct SemNodo nodos, int total);
void traducir_tipo_c(void* tipo_synapse);
void gen_emitir_linea(struct GeneradorCEst est, CadenaSegura linea);
void gen_emitir_str(struct GeneradorCEst est, void* str);
void gen_emitir_nueva_linea(struct GeneradorCEst est);
CadenaSegura gen_obtener_salida(struct GeneradorCEst est);
void gen_escribir_cadena_escapada(struct GeneradorCEst est, void* str);
void gen_emitir_traza(struct GeneradorCEst est, void* modulo, void* nombre_nodo);
void gen_abrir_bloque_c(struct GeneradorCEst est);
void gen_cerrar_bloque_c(struct GeneradorCEst est);
int _syn_es_tipo(void* ptr_tipo_nodo, void* esperado);
void _oo_expr_a_c(struct GeneradorCEst est, void* nodo, void* buf, int bufsz);
void gen_visitar_si(struct GeneradorCEst est, void* stmt);
void gen_visitar_mientras(struct GeneradorCEst est, void* stmt);
void gen_visitar_retornar(struct GeneradorCEst est, void* stmt);
void gen_visitar_declaracion(struct GeneradorCEst est, void* stmt);
void gen_visitar_asignacion(struct GeneradorCEst est, void* stmt);
void gen_visitar_expr(struct GeneradorCEst est, void* stmt);
void gen_visitar_romper(struct GeneradorCEst est, void* stmt);
void gen_visitar_siguiente(struct GeneradorCEst est, void* stmt);
void gen_visitar_stmt_generico(struct GeneradorCEst est, void* stmt);
int generar(struct Programa programa, CadenaSegura ruta);
void gen_visitar_top_level(struct GeneradorCEst est, void* stmt);
CadenaSegura buscar_en(CadenaSegura dir_base, CadenaSegura ruta_import);
CadenaSegura resolver(CadenaSegura ruta_import, CadenaSegura dir_base, CadenaSegura dependencias_nombres, CadenaSegura dependencias_valores, int total_dependencias);
struct NodoJson desde_texto(CadenaSegura entrada);
void liberar_nodo(struct NodoJson n);
struct NodoJson obtener_elemento(struct NodoJson nodo, int indice);
struct NodoJson obtener_campo(struct NodoJson nodo, CadenaSegura clave);
int principal(void);

#define IF (1)
#define ELSE (2)
#define FUNCTION (3)
#define RETURN (4)
#define SPAWN (5)
#define RECOVER (6)
#define LISTEN (7)
#define WHILE (8)
#define IMPORT (9)
#define STRUCT (10)
#define BREAK (11)
#define CONTINUE (12)
#define DOT (13)
#define AND (14)
#define OR (15)
#define NOT (16)
#define TRUE (17)
#define FALSE (18)
#define IDENTIFIER (19)
#define NUMBER (20)
#define FLOAT (21)
#define STRING (22)
#define GREATER (23)
#define LESS (24)
#define EQUALS (25)
#define NOT_EQUALS (26)
#define LESS_EQUALS (27)
#define GREATER_EQUALS (28)
#define ASSIGN (29)
#define PLUS (30)
#define MINUS (31)
#define STAR (32)
#define SLASH (33)
#define MODULO (34)
#define ARROW (35)
#define MATCH (36)
#define ARROW_RIGHT (37)
#define LPAREN (38)
#define RPAREN (39)
#define COLON (40)
#define COMMA (41)
#define NEWLINE (42)
#define INDENT (43)
#define DEDENT (44)
#define AMPERSAND (45)
#define INSEGURO (46)
#define IMPORTAR_C (47)
#define EXTERNO (48)
#define ARROW_LEFT (49)
#define REQUIERE (50)
#define GARANTIZA (51)
#define CANAL (52)
#define ASM (53)
#define CONSTANTE (54)
#define SEMICOLON (55)
#define PARA (56)
#define T_IF (1)
#define T_ELSE (2)
#define T_FUNCION (3)
#define T_RETORNAR (4)
#define T_LANZAR (5)
#define T_RECUPERAR (6)
#define T_ESCUCHAR (7)
#define T_MIENTRAS (8)
#define T_IMPORTAR (9)
#define T_ESTRUCTURA (10)
#define T_ROMPER (11)
#define T_SIGUIENTE (12)
#define T_PUNTO (13)
#define T_Y (14)
#define T_O (15)
#define T_NO (16)
#define T_VERDADERO (17)
#define T_FALSO (18)
#define T_IDENTIFICADOR (19)
#define T_NUMERO (20)
#define T_FLOTANTE (21)
#define T_CADENA (22)
#define T_MAYOR (23)
#define T_MENOR (24)
#define T_IGUAL (25)
#define T_DISTINTO (26)
#define T_MENOR_IGUAL (27)
#define T_MAYOR_IGUAL (28)
#define T_ASIGNAR (29)
#define T_MAS (30)
#define T_MENOS (31)
#define T_POR (32)
#define T_DIV (33)
#define T_MOD (34)
#define T_FLECHA (35)
#define T_COINCIDIR (36)
#define T_FLECHA_DER (37)
#define T_PAREN_IZQ (38)
#define T_PAREN_DER (39)
#define T_DOSPUNTOS (40)
#define T_COMA (41)
#define T_NUEVALINEA (42)
#define T_INDENTAR (43)
#define T_DESINDENTAR (44)
#define T_AMPERSAND (45)
#define T_INSEGURO (46)
#define T_IMPORTAR_C (47)
#define T_EXTERNO (48)
#define T_FLECHA_IZQ (49)
#define T_REQUIERE (50)
#define T_GARANTIZA (51)
#define T_CANAL (52)
#define T_ASM (53)
#define T_CONSTANTE (54)
#define T_PUNTOCOMA (55)
#define T_PARA (56)
#define T_FIN (57)
#define T_ERROR (58)
int str_len(CadenaSegura s) {
    int r;
    { /* unsafe */
        r = 0;
        r = s.longitud;
        int _ret_75 = r;
        return _ret_75;
    }
}

int str_char(CadenaSegura s, int i) {
    int r;
    { /* unsafe */
        r = 0;
        r = (i >= 0 && i < s.longitud) ? (unsigned char)s.datos[i] : 0;
        int _ret_81 = r;
        return _ret_81;
    }
}

int str_char_at(int ptr, int i) {
    int r;
    { /* unsafe */
        r = 0;
        r = (unsigned char)((const char*)ptr)[i];
        int _ret_87 = r;
        return _ret_87;
    }
}

int str_eq(CadenaSegura a, CadenaSegura b) {
    int r;
    { /* unsafe */
        r = 0;
        if (a.longitud != b.longitud) { r = 0; } else { r = 1; for (int _si = 0; _si < a.longitud; _si++) { if (a.datos[_si] != b.datos[_si]) { r = 0; break; } } };
        int _ret_93 = r;
        return _ret_93;
    }
}

int str_len_ptr(int ptr) {
    int r;
    { /* unsafe */
        r = 0;
        r = (int)strlen((const char*)ptr);
        int _ret_99 = r;
        return _ret_99;
    }
}

int keyword_token(CadenaSegura palabra) {
    if ((str_eq(palabra, (CadenaSegura){ .longitud = (int)strlen("si"), .datos = "si" }) == 1)) {
        int _ret_104 = T_IF;
        return _ret_104;
    }
    if ((str_eq(palabra, (CadenaSegura){ .longitud = (int)strlen("sino"), .datos = "sino" }) == 1)) {
        int _ret_106 = T_ELSE;
        return _ret_106;
    }
    if ((str_eq(palabra, (CadenaSegura){ .longitud = (int)strlen("funcion"), .datos = "funcion" }) == 1)) {
        int _ret_108 = T_FUNCION;
        return _ret_108;
    }
    if ((str_eq(palabra, (CadenaSegura){ .longitud = (int)strlen("retornar"), .datos = "retornar" }) == 1)) {
        int _ret_110 = T_RETORNAR;
        return _ret_110;
    }
    if ((str_eq(palabra, (CadenaSegura){ .longitud = (int)strlen("lanzar"), .datos = "lanzar" }) == 1)) {
        int _ret_112 = T_LANZAR;
        return _ret_112;
    }
    if ((str_eq(palabra, (CadenaSegura){ .longitud = (int)strlen("recuperar"), .datos = "recuperar" }) == 1)) {
        int _ret_114 = T_RECUPERAR;
        return _ret_114;
    }
    if ((str_eq(palabra, (CadenaSegura){ .longitud = (int)strlen("escuchar"), .datos = "escuchar" }) == 1)) {
        int _ret_116 = T_ESCUCHAR;
        return _ret_116;
    }
    if ((str_eq(palabra, (CadenaSegura){ .longitud = (int)strlen("mientras"), .datos = "mientras" }) == 1)) {
        int _ret_118 = T_MIENTRAS;
        return _ret_118;
    }
    if ((str_eq(palabra, (CadenaSegura){ .longitud = (int)strlen("importar"), .datos = "importar" }) == 1)) {
        int _ret_120 = T_IMPORTAR;
        return _ret_120;
    }
    if ((str_eq(palabra, (CadenaSegura){ .longitud = (int)strlen("romper"), .datos = "romper" }) == 1)) {
        int _ret_122 = T_ROMPER;
        return _ret_122;
    }
    if ((str_eq(palabra, (CadenaSegura){ .longitud = (int)strlen("siguiente"), .datos = "siguiente" }) == 1)) {
        int _ret_124 = T_SIGUIENTE;
        return _ret_124;
    }
    if ((str_eq(palabra, (CadenaSegura){ .longitud = (int)strlen("estructura"), .datos = "estructura" }) == 1)) {
        int _ret_126 = T_ESTRUCTURA;
        return _ret_126;
    }
    if ((str_eq(palabra, (CadenaSegura){ .longitud = (int)strlen("y"), .datos = "y" }) == 1)) {
        int _ret_128 = T_Y;
        return _ret_128;
    }
    if ((str_eq(palabra, (CadenaSegura){ .longitud = (int)strlen("o"), .datos = "o" }) == 1)) {
        int _ret_130 = T_O;
        return _ret_130;
    }
    if ((str_eq(palabra, (CadenaSegura){ .longitud = (int)strlen("no"), .datos = "no" }) == 1)) {
        int _ret_132 = T_NO;
        return _ret_132;
    }
    if ((str_eq(palabra, (CadenaSegura){ .longitud = (int)strlen("verdadero"), .datos = "verdadero" }) == 1)) {
        int _ret_134 = T_VERDADERO;
        return _ret_134;
    }
    if ((str_eq(palabra, (CadenaSegura){ .longitud = (int)strlen("falso"), .datos = "falso" }) == 1)) {
        int _ret_136 = T_FALSO;
        return _ret_136;
    }
    if ((str_eq(palabra, (CadenaSegura){ .longitud = (int)strlen("inseguro"), .datos = "inseguro" }) == 1)) {
        int _ret_138 = T_INSEGURO;
        return _ret_138;
    }
    if ((str_eq(palabra, (CadenaSegura){ .longitud = (int)strlen("importar_c"), .datos = "importar_c" }) == 1)) {
        int _ret_140 = T_IMPORTAR_C;
        return _ret_140;
    }
    if ((str_eq(palabra, (CadenaSegura){ .longitud = (int)strlen("externo"), .datos = "externo" }) == 1)) {
        int _ret_142 = T_EXTERNO;
        return _ret_142;
    }
    if ((str_eq(palabra, (CadenaSegura){ .longitud = (int)strlen("coincidir"), .datos = "coincidir" }) == 1)) {
        int _ret_144 = T_COINCIDIR;
        return _ret_144;
    }
    if ((str_eq(palabra, (CadenaSegura){ .longitud = (int)strlen("requiere"), .datos = "requiere" }) == 1)) {
        int _ret_146 = T_REQUIERE;
        return _ret_146;
    }
    if ((str_eq(palabra, (CadenaSegura){ .longitud = (int)strlen("garantiza"), .datos = "garantiza" }) == 1)) {
        int _ret_148 = T_GARANTIZA;
        return _ret_148;
    }
    if ((str_eq(palabra, (CadenaSegura){ .longitud = (int)strlen("canal"), .datos = "canal" }) == 1)) {
        int _ret_150 = T_CANAL;
        return _ret_150;
    }
    if ((str_eq(palabra, (CadenaSegura){ .longitud = (int)strlen("asm"), .datos = "asm" }) == 1)) {
        int _ret_152 = T_ASM;
        return _ret_152;
    }
    if ((str_eq(palabra, (CadenaSegura){ .longitud = (int)strlen("constante"), .datos = "constante" }) == 1)) {
        int _ret_154 = T_CONSTANTE;
        return _ret_154;
    }
    if ((str_eq(palabra, (CadenaSegura){ .longitud = (int)strlen("para"), .datos = "para" }) == 1)) {
        int _ret_156 = T_PARA;
        return _ret_156;
    }
    int _ret_157 = 0;
    return _ret_157;
}

int es_digito(int c) {
    if ((c >= 48)) {
        if ((c <= 57)) {
            int _ret_163 = 1;
            return _ret_163;
        }
    }
    int _ret_164 = 0;
    return _ret_164;
}

int es_letra(int c) {
    if ((c >= 65)) {
        if ((c <= 90)) {
            int _ret_169 = 1;
            return _ret_169;
        }
    }
    if ((c >= 97)) {
        if ((c <= 122)) {
            int _ret_172 = 1;
            return _ret_172;
        }
    }
    if ((c == 95)) {
        int _ret_174 = 1;
        return _ret_174;
    }
    int _ret_175 = 0;
    return _ret_175;
}

int es_alnum(int c) {
    if ((es_digito(c) == 1)) {
        int _ret_179 = 1;
        return _ret_179;
    }
    if ((es_letra(c) == 1)) {
        int _ret_181 = 1;
        return _ret_181;
    }
    int _ret_182 = 0;
    return _ret_182;
}

#define MAX_TOKENS (16384)
#define MAX_INDENT (64)
void lexer_push_token(struct LexerEstado lex, int tipo, int linea, int columna) {
    { /* unsafe */
        if (lex.total_tokens >= 16384) return;
        lex.tokens[lex.total_tokens].tipo = tipo;
        lex.tokens[lex.total_tokens].linea = linea;
        lex.tokens[lex.total_tokens].columna = columna;
        lex.total_tokens = lex.total_tokens + 1;
    }
}

void lexer_error(struct LexerEstado lex, CadenaSegura mensaje, int linea, int columna) {
    lex.hay_error = 1;
    lex.error_mensaje = mensaje;
    lex.error_linea = linea;
    lex.error_columna = columna;
}

void lexer_detectar_idioma(struct LexerEstado lex) {
    int r;
    { /* unsafe */
        r = 0;
        r = (lex.len_fuente >= 7 && ((const char*)lex.ptr_fuente)[0] == '#' && ((const char*)lex.ptr_fuente)[1] == 'l' && ((const char*)lex.ptr_fuente)[2] == 'a' && ((const char*)lex.ptr_fuente)[3] == 'n' && ((const char*)lex.ptr_fuente)[4] == 'g' && ((const char*)lex.ptr_fuente)[5] == ':') ? 1 : 0;
        if ((r == 0)) {
            lexer_error(lex, (CadenaSegura){ .longitud = (int)strlen("Falta declaracion de idioma #lang: en la linea 1"), .datos = "Falta declaracion de idioma #lang: en la linea 1" }, 1, 0);
        }
    }
}

void lexer_procesar_indentacion(struct LexerEstado lex, int ptr_linea, int len_linea) {
    int espacios;
    int r;
    int nivel;
    int tope;
    { /* unsafe */
        espacios = 0;
        while (espacios < len_linea && ((const char*)ptr_linea)[espacios] == ' ') { espacios = espacios + 1; }
        if ((espacios < len_linea)) {
            r = 0;
            r = (((const char*)ptr_linea)[espacios] == '	') ? 1 : 0;
            if ((r == 1)) {
                lexer_error(lex, (CadenaSegura){ .longitud = (int)strlen("Tabulador prohibido E-101"), .datos = "Tabulador prohibido E-101" }, lex.linea_actual, (espacios + 1));
                return;
            }
        }
        if (((espacios % 4) != 0)) {
            lexer_error(lex, (CadenaSegura){ .longitud = (int)strlen("Indentacion debe ser multiplo de 4 espacios"), .datos = "Indentacion debe ser multiplo de 4 espacios" }, lex.linea_actual, 0);
            return;
        }
        nivel = (espacios / 4);
        tope = 0;
        tope = (lex.nivel_pila > 0) ? lex.pila_indent[lex.nivel_pila - 1] : 0;
        if ((nivel > tope)) {
            lex.pila_indent[lex.nivel_pila] = nivel;
            lex.nivel_pila = lex.nivel_pila + 1;
            lexer_push_token(lex, T_INDENTAR, lex.linea_actual, 0);
        }
        if ((nivel < tope)) {
            while ((nivel < tope)) {
                lex.nivel_pila = lex.nivel_pila - 1;
                tope = (lex.nivel_pila > 0) ? lex.pila_indent[lex.nivel_pila - 1] : 0;
                lexer_push_token(lex, T_DESINDENTAR, lex.linea_actual, 0);
            }
        }
    }
}

void lexer_tokenizar_linea(struct LexerEstado lex, int ptr_texto, int len_texto) {
    int i;
    int r;
    int c;
    i = 0;
    r = 1;
    while ((r == 1)) {
        { /* unsafe */
            r = (i < len_texto) ? 1 : 0;
            if ((r == 0)) {
                break;
            }
            c = 0;
            c = (unsigned char)((const char*)ptr_texto)[i];
            if ((c == 32)) {
                i = i + 1;
                continue;
            }
            if ((c == 47)) {
                if (((i + 1) < len_texto)) {
                    c = (unsigned char)((const char*)ptr_texto)[i + 1];
                    if ((c == 47)) {
                        return;
                    }
                }
            }
            if ((c == 34)) {
                i = i + 1;
                while ((i < len_texto)) {
                    c = (unsigned char)((const char*)ptr_texto)[i];
                    if ((c == 92)) {
                        i = i + 1;
                    }
                    else {
                        if ((c == 34)) {
                            break;
                        }
                    }
                    i = i + 1;
                }
                i = i + 1;
                continue;
            }
            if ((c == 39)) {
                i = i + 1;
                while ((i < len_texto)) {
                    c = (unsigned char)((const char*)ptr_texto)[i];
                    if ((c == 92)) {
                        i = i + 1;
                    }
                    else {
                        if ((c == 39)) {
                            break;
                        }
                    }
                    i = i + 1;
                }
                i = i + 1;
                continue;
            }
            if ((c >= 48)) {
                if ((c <= 57)) {
                    while ((i < len_texto)) {
                        c = (unsigned char)((const char*)ptr_texto)[i];
                        if ((c < 48)) {
                            break;
                        }
                        if ((c > 57)) {
                            break;
                        }
                        i = i + 1;
                    }
                    continue;
                }
            }
            if ((es_letra(c) == 1)) {
                while ((i < len_texto)) {
                    c = (unsigned char)((const char*)ptr_texto)[i];
                    if ((es_alnum(c) == 0)) {
                        if ((c != 95)) {
                            break;
                        }
                    }
                    i = i + 1;
                }
                continue;
            }
            if ((c == 43)) {
                lexer_push_token(lex, T_MAS, lex.linea_actual, (i + 1));
                i = i + 1;
                continue;
            }
            if ((c == 45)) {
                if (((i + 1) < len_texto)) {
                    c = (unsigned char)((const char*)ptr_texto)[i + 1];
                    if ((c == 62)) {
                        lexer_push_token(lex, T_FLECHA, lex.linea_actual, (i + 1));
                        i = i + 2;
                        continue;
                    }
                    if ((c == 60)) {
                        lexer_push_token(lex, T_FLECHA_IZQ, lex.linea_actual, (i + 1));
                        i = i + 2;
                        continue;
                    }
                }
                lexer_push_token(lex, T_MENOS, lex.linea_actual, (i + 1));
                i = i + 1;
                continue;
            }
            if ((c == 61)) {
                if (((i + 1) < len_texto)) {
                    c = (unsigned char)((const char*)ptr_texto)[i + 1];
                    if ((c == 62)) {
                        lexer_push_token(lex, T_FLECHA_DER, lex.linea_actual, (i + 1));
                        i = i + 2;
                        continue;
                    }
                    if ((c == 61)) {
                        lexer_push_token(lex, T_IGUAL, lex.linea_actual, (i + 1));
                        i = i + 2;
                        continue;
                    }
                }
                lexer_push_token(lex, T_ASIGNAR, lex.linea_actual, (i + 1));
                i = i + 1;
                continue;
            }
            if ((c == 33)) {
                if (((i + 1) < len_texto)) {
                    c = (unsigned char)((const char*)ptr_texto)[i + 1];
                    if ((c == 61)) {
                        lexer_push_token(lex, T_DISTINTO, lex.linea_actual, (i + 1));
                        i = i + 2;
                        continue;
                    }
                }
                i = i + 1;
                continue;
            }
            if ((c == 60)) {
                if (((i + 1) < len_texto)) {
                    c = (unsigned char)((const char*)ptr_texto)[i + 1];
                    if ((c == 61)) {
                        lexer_push_token(lex, T_MENOR_IGUAL, lex.linea_actual, (i + 1));
                        i = i + 2;
                        continue;
                    }
                }
                lexer_push_token(lex, T_MENOR, lex.linea_actual, (i + 1));
                i = i + 1;
                continue;
            }
            if ((c == 62)) {
                if (((i + 1) < len_texto)) {
                    c = (unsigned char)((const char*)ptr_texto)[i + 1];
                    if ((c == 61)) {
                        lexer_push_token(lex, T_MAYOR_IGUAL, lex.linea_actual, (i + 1));
                        i = i + 2;
                        continue;
                    }
                }
                lexer_push_token(lex, T_MAYOR, lex.linea_actual, (i + 1));
                i = i + 1;
                continue;
            }
            if ((c == 42)) {
                lexer_push_token(lex, T_POR, lex.linea_actual, (i + 1));
                i = i + 1;
                continue;
            }
            if ((c == 47)) {
                lexer_push_token(lex, T_DIV, lex.linea_actual, (i + 1));
                i = i + 1;
                continue;
            }
            if ((c == 37)) {
                lexer_push_token(lex, T_MOD, lex.linea_actual, (i + 1));
                i = i + 1;
                continue;
            }
            if ((c == 40)) {
                lexer_push_token(lex, T_PAREN_IZQ, lex.linea_actual, (i + 1));
                i = i + 1;
                continue;
            }
            if ((c == 41)) {
                lexer_push_token(lex, T_PAREN_DER, lex.linea_actual, (i + 1));
                i = i + 1;
                continue;
            }
            if ((c == 58)) {
                lexer_push_token(lex, T_DOSPUNTOS, lex.linea_actual, (i + 1));
                i = i + 1;
                continue;
            }
            if ((c == 44)) {
                lexer_push_token(lex, T_COMA, lex.linea_actual, (i + 1));
                i = i + 1;
                continue;
            }
            if ((c == 46)) {
                lexer_push_token(lex, T_PUNTO, lex.linea_actual, (i + 1));
                i = i + 1;
                continue;
            }
            if ((c == 38)) {
                lexer_push_token(lex, T_AMPERSAND, lex.linea_actual, (i + 1));
                i = i + 1;
                continue;
            }
            if ((c == 59)) {
                lexer_push_token(lex, T_PUNTOCOMA, lex.linea_actual, (i + 1));
                i = i + 1;
                continue;
            }
            lexer_error(lex, (CadenaSegura){ .longitud = (int)strlen("Caracter inesperado"), .datos = "Caracter inesperado" }, lex.linea_actual, (i + 1));
            i = i + 1;
        }
        continue;
    }
}

int tokenizar(CadenaSegura fuente) {
    int _i=0, _linea=1, _columna=1, _token_count=0;
    while (_i < fuente.longitud) {
        char _c = fuente.datos[_i];
        if (_c==' '||_c=='\t'){_i++;_columna++;continue;}
        if (_c=='\r'){_i++;continue;}
        if (_c=='\n'){_i++;_linea++;_columna=1;continue;}
        if (_c=='/'&&_i+1<fuente.longitud&&fuente.datos[_i+1]=='/'){
            while(_i<fuente.longitud&&fuente.datos[_i]!='\n')_i++;continue;
        }
        if(_c=='\"'||_c=='\''){char _q=_c;int _st=_i;_i++;_columna++;while(_i<fuente.longitud&&fuente.datos[_i]!=_q){_i++;_columna++;}if(_i>=fuente.longitud){break;}_i++;_columna++;_token_count++;}
        else if(_c>='0'&&_c<='9'){int _st=_i;while(_i<fuente.longitud&&fuente.datos[_i]>='0'&&fuente.datos[_i]<='9')_i++;_columna+=_i-_st;_token_count++;}
        else if((_c>='a'&&_c<='z')||(_c>='A'&&_c<='Z')||_c=='_'){int _st=_i;while(_i<fuente.longitud&&((fuente.datos[_i]>='a'&&fuente.datos[_i]<='z')||(fuente.datos[_i]>='A'&&fuente.datos[_i]<='Z')||(fuente.datos[_i]>='0'&&fuente.datos[_i]<='9')||fuente.datos[_i]=='_'))_i++;_columna+=_i-_st;_token_count++;}
        else{_i++;_columna++;_token_count++;}
    }
    return _token_count;
}

#define ERR_SYNTAX_EXPECTED_TOKEN (1)
#define ERR_SYNTAX_UNEXPECTED_TOKEN (2)
#define ERR_SYNTAX_UNEXPECTED_EXPR (3)
#define ERR_SYNTAX_EXPECTED_NEWLINE (4)
#define ERR_LANG_MISSING (5)
#define ERR_LANG_UNSUPPORTED (6)
#define ERR_INDENT_INVALID (7)
#define ERR_INDENT_INCONSISTENT (8)
#define ERR_STRING_UNCLOSED (9)
#define ERR_LEX_CHAR_UNEXPECTED (10)
#define ERR_LEX (11)
#define ERR_FILE_NOT_FOUND (12)
#define ERR_CANONICAL_FORMAT (13)
#define ERR_SEM_VAR_NO_DECLARADA (14)
#define ERR_SEM_TIPO_INCOMPATIBLE (15)
#define ERR_SEM_TIPO_RETORNO (16)
#define ERR_SEM_FUNC_NO_DEFINIDA (17)
#define ERR_SEM_REDEFINICION (18)
#define ERR_SEM_ARGUMENTOS_INVALIDOS (19)
#define ERR_SEM_ESTRUCTURA_NO_DEFINIDA (20)
#define ERR_SEM_CAMPO_NO_EXISTE (21)
#define ERR_SEM_VAR_MOVIDA (22)
#define ERR_SEM_ACCESO_MEMORIA_MOVIDA (23)
#define ERR_SEM_RESULTADO_SIN_DESEMPAQUETAR (24)
#define ERR_MANIFEST_NOT_FOUND (25)
#define ERR_MODULE_STD_NOT_FOUND (26)
#define ERR_MODULE_AXON_NOT_FOUND (27)
#define ERR_DEP_NOT_DECLARED (28)
#define ERR_LOCK_HASH_MISMATCH (29)
#define ERR_GIT_FAILURE (30)
#define ERR_SEM_ASM_FUERA_INSEGURO (31)
#define ERR_SEM_CONSTANTE_INMUTABLE (32)
struct GestorDiagnostico gestor_nuevo(CadenaSegura idioma, CadenaSegura ruta, int capacidad) {
    struct GestorDiagnostico g;
    g = (struct GestorDiagnostico){0};
    g.idioma = idioma;
    g.ruta_archivo = ruta;
    g.total_reportes = 0;
    g.capacidad = capacidad;
    struct GestorDiagnostico _ret_58 = g;
    return _ret_58;
}

void reportar_error(struct GestorDiagnostico diag, int codigo, int linea, int columna, CadenaSegura mensaje) {
    { /* unsafe */
        if (diag.total_reportes >= diag.capacidad) return;
        diag.reportes[diag.total_reportes].codigo = codigo;
        diag.reportes[diag.total_reportes].linea = linea;
        diag.reportes[diag.total_reportes].columna = columna;
        diag.total_reportes = diag.total_reportes + 1;
    }
}

int hay_errores(struct GestorDiagnostico diag) {
    if ((diag.total_reportes > 0)) {
        int _ret_73 = 1;
        return _ret_73;
    }
    int _ret_74 = 0;
    return _ret_74;
}

int contar_errores(struct GestorDiagnostico diag) {
    int _ret_77 = diag.total_reportes;
    return _ret_77;
}

int codigo_salida(struct GestorDiagnostico diag) {
    if ((hay_errores(diag) == 1)) {
        int _ret_81 = 1;
        return _ret_81;
    }
    int _ret_82 = 0;
    return _ret_82;
}

CadenaSegura resumen_errores(struct GestorDiagnostico diag) {
    if ((hay_errores(diag) == 0)) {
        CadenaSegura _ret_86 = (CadenaSegura){ .longitud = (int)strlen("0 errores"), .datos = "0 errores" };
        return _ret_86;
    }
    CadenaSegura _ret_87 = concat(entero_a_texto(diag.total_reportes), (CadenaSegura){ .longitud = (int)strlen(" error(es) encontrado(s)"), .datos = " error(es) encontrado(s)" });
    return _ret_87;
}

CadenaSegura obtener_plantilla_error(int codigo, CadenaSegura idioma) {
    if ((str_eq(idioma, (CadenaSegura){ .longitud = (int)strlen("es"), .datos = "es" }) == 1)) {
        if ((codigo == ERR_SYNTAX_EXPECTED_TOKEN)) {
            CadenaSegura _ret_93 = (CadenaSegura){ .longitud = (int)strlen("Se esperaba {esperado}, se encontro '{encontrado}'"), .datos = "Se esperaba {esperado}, se encontro '{encontrado}'" };
            return _ret_93;
        }
        if ((codigo == ERR_SYNTAX_UNEXPECTED_TOKEN)) {
            CadenaSegura _ret_95 = (CadenaSegura){ .longitud = (int)strlen("Token inesperado '{tok_name}' tras expresion"), .datos = "Token inesperado '{tok_name}' tras expresion" };
            return _ret_95;
        }
        if ((codigo == ERR_SYNTAX_UNEXPECTED_EXPR)) {
            CadenaSegura _ret_97 = (CadenaSegura){ .longitud = (int)strlen("Expresion inesperada: '{tipo}'"), .datos = "Expresion inesperada: '{tipo}'" };
            return _ret_97;
        }
        if ((codigo == ERR_SYNTAX_EXPECTED_NEWLINE)) {
            CadenaSegura _ret_99 = (CadenaSegura){ .longitud = (int)strlen("Se esperaba nueva linea despues de '{construccion}'"), .datos = "Se esperaba nueva linea despues de '{construccion}'" };
            return _ret_99;
        }
        if ((codigo == ERR_LANG_MISSING)) {
            CadenaSegura _ret_101 = (CadenaSegura){ .longitud = (int)strlen("Falta declaracion de idioma '#lang: <codigo>' en la linea 1"), .datos = "Falta declaracion de idioma '#lang: <codigo>' en la linea 1" };
            return _ret_101;
        }
        if ((codigo == ERR_LANG_UNSUPPORTED)) {
            CadenaSegura _ret_103 = (CadenaSegura){ .longitud = (int)strlen("Idioma '{idioma}' no soportado"), .datos = "Idioma '{idioma}' no soportado" };
            return _ret_103;
        }
        if ((codigo == ERR_INDENT_INVALID)) {
            CadenaSegura _ret_105 = (CadenaSegura){ .longitud = (int)strlen("La indentacion debe ser multiplo de 4 espacios"), .datos = "La indentacion debe ser multiplo de 4 espacios" };
            return _ret_105;
        }
        if ((codigo == ERR_INDENT_INCONSISTENT)) {
            CadenaSegura _ret_107 = (CadenaSegura){ .longitud = (int)strlen("Nivel de indentacion inconsistente"), .datos = "Nivel de indentacion inconsistente" };
            return _ret_107;
        }
        if ((codigo == ERR_STRING_UNCLOSED)) {
            CadenaSegura _ret_109 = (CadenaSegura){ .longitud = (int)strlen("Cadena sin cerrar"), .datos = "Cadena sin cerrar" };
            return _ret_109;
        }
        if ((codigo == ERR_LEX)) {
            CadenaSegura _ret_111 = (CadenaSegura){ .longitud = (int)strlen("{mensaje}"), .datos = "{mensaje}" };
            return _ret_111;
        }
        if ((codigo == ERR_LEX_CHAR_UNEXPECTED)) {
            CadenaSegura _ret_113 = (CadenaSegura){ .longitud = (int)strlen("Caracter inesperado '{char}'"), .datos = "Caracter inesperado '{char}'" };
            return _ret_113;
        }
        if ((codigo == ERR_FILE_NOT_FOUND)) {
            CadenaSegura _ret_115 = (CadenaSegura){ .longitud = (int)strlen("Archivo no encontrado: {archivo}"), .datos = "Archivo no encontrado: {archivo}" };
            return _ret_115;
        }
        if ((codigo == ERR_CANONICAL_FORMAT)) {
            CadenaSegura _ret_117 = (CadenaSegura){ .longitud = (int)strlen("Formato canonico no reconocido o corrupto"), .datos = "Formato canonico no reconocido o corrupto" };
            return _ret_117;
        }
        if ((codigo == ERR_SEM_VAR_NO_DECLARADA)) {
            CadenaSegura _ret_119 = (CadenaSegura){ .longitud = (int)strlen("Variable '{nombre}' no declarada en este ambito"), .datos = "Variable '{nombre}' no declarada en este ambito" };
            return _ret_119;
        }
        if ((codigo == ERR_SEM_TIPO_INCOMPATIBLE)) {
            CadenaSegura _ret_121 = (CadenaSegura){ .longitud = (int)strlen("Tipos incompatibles: no se puede usar '{tipo1}' con '{tipo2}' en '{operacion}'"), .datos = "Tipos incompatibles: no se puede usar '{tipo1}' con '{tipo2}' en '{operacion}'" };
            return _ret_121;
        }
        if ((codigo == ERR_SEM_TIPO_RETORNO)) {
            CadenaSegura _ret_123 = (CadenaSegura){ .longitud = (int)strlen("Tipo de retorno incorrecto: se esperaba '{esperado}', se obtuvo '{obtenido}'"), .datos = "Tipo de retorno incorrecto: se esperaba '{esperado}', se obtuvo '{obtenido}'" };
            return _ret_123;
        }
        if ((codigo == ERR_SEM_FUNC_NO_DEFINIDA)) {
            CadenaSegura _ret_125 = (CadenaSegura){ .longitud = (int)strlen("Funcion '{nombre}' no definida"), .datos = "Funcion '{nombre}' no definida" };
            return _ret_125;
        }
        if ((codigo == ERR_SEM_REDEFINICION)) {
            CadenaSegura _ret_127 = (CadenaSegura){ .longitud = (int)strlen("Redefinicion de '{nombre}' en el mismo ambito"), .datos = "Redefinicion de '{nombre}' en el mismo ambito" };
            return _ret_127;
        }
        if ((codigo == ERR_SEM_ARGUMENTOS_INVALIDOS)) {
            CadenaSegura _ret_129 = (CadenaSegura){ .longitud = (int)strlen("Cantidad de argumentos invalida para '{nombre}': se esperaban {esperados}"), .datos = "Cantidad de argumentos invalida para '{nombre}': se esperaban {esperados}" };
            return _ret_129;
        }
        if ((codigo == ERR_SEM_ESTRUCTURA_NO_DEFINIDA)) {
            CadenaSegura _ret_131 = (CadenaSegura){ .longitud = (int)strlen("Estructura '{nombre}' no definida"), .datos = "Estructura '{nombre}' no definida" };
            return _ret_131;
        }
        if ((codigo == ERR_SEM_CAMPO_NO_EXISTE)) {
            CadenaSegura _ret_133 = (CadenaSegura){ .longitud = (int)strlen("La estructura '{struct}' no tiene un campo '{campo}'"), .datos = "La estructura '{struct}' no tiene un campo '{campo}'" };
            return _ret_133;
        }
        if ((codigo == ERR_SEM_VAR_MOVIDA)) {
            CadenaSegura _ret_135 = (CadenaSegura){ .longitud = (int)strlen("Uso ilegal de variable ya movida '{nombre}'"), .datos = "Uso ilegal de variable ya movida '{nombre}'" };
            return _ret_135;
        }
        if ((codigo == ERR_SEM_ACCESO_MEMORIA_MOVIDA)) {
            CadenaSegura _ret_137 = (CadenaSegura){ .longitud = (int)strlen("Acceso prohibido a memoria movida '{nombre}'"), .datos = "Acceso prohibido a memoria movida '{nombre}'" };
            return _ret_137;
        }
        if ((codigo == ERR_SEM_RESULTADO_SIN_DESEMPAQUETAR)) {
            CadenaSegura _ret_139 = (CadenaSegura){ .longitud = (int)strlen("Resultado de canal sin desempaquetar"), .datos = "Resultado de canal sin desempaquetar" };
            return _ret_139;
        }
        if ((codigo == ERR_MANIFEST_NOT_FOUND)) {
            CadenaSegura _ret_141 = (CadenaSegura){ .longitud = (int)strlen("Manifiesto axon.toml no encontrado en el directorio actual"), .datos = "Manifiesto axon.toml no encontrado en el directorio actual" };
            return _ret_141;
        }
        if ((codigo == ERR_MODULE_STD_NOT_FOUND)) {
            CadenaSegura _ret_143 = (CadenaSegura){ .longitud = (int)strlen("Modulo estandar '{modulo}' no encontrado. Sysroot corrupto"), .datos = "Modulo estandar '{modulo}' no encontrado. Sysroot corrupto" };
            return _ret_143;
        }
        if ((codigo == ERR_MODULE_AXON_NOT_FOUND)) {
            CadenaSegura _ret_145 = (CadenaSegura){ .longitud = (int)strlen("Dependencia '{modulo}' no encontrada en axon_modules"), .datos = "Dependencia '{modulo}' no encontrada en axon_modules" };
            return _ret_145;
        }
        if ((codigo == ERR_DEP_NOT_DECLARED)) {
            CadenaSegura _ret_147 = (CadenaSegura){ .longitud = (int)strlen("Dependencia '{modulo}' importada en el codigo pero no declarada en axon.toml"), .datos = "Dependencia '{modulo}' importada en el codigo pero no declarada en axon.toml" };
            return _ret_147;
        }
        if ((codigo == ERR_LOCK_HASH_MISMATCH)) {
            CadenaSegura _ret_149 = (CadenaSegura){ .longitud = (int)strlen("El hash de la dependencia '{modulo}' no coincide con axon.lock"), .datos = "El hash de la dependencia '{modulo}' no coincide con axon.lock" };
            return _ret_149;
        }
        if ((codigo == ERR_GIT_FAILURE)) {
            CadenaSegura _ret_151 = (CadenaSegura){ .longitud = (int)strlen("Error de red o revision Git invalida para la dependencia '{modulo}'"), .datos = "Error de red o revision Git invalida para la dependencia '{modulo}'" };
            return _ret_151;
        }
        if ((codigo == ERR_SEM_ASM_FUERA_INSEGURO)) {
            CadenaSegura _ret_153 = (CadenaSegura){ .longitud = (int)strlen("asm() solo puede usarse dentro de un bloque 'inseguro:'"), .datos = "asm() solo puede usarse dentro de un bloque 'inseguro:'" };
            return _ret_153;
        }
        if ((codigo == ERR_SEM_CONSTANTE_INMUTABLE)) {
            CadenaSegura _ret_155 = (CadenaSegura){ .longitud = (int)strlen("No se puede reasignar la constante '{nombre}'"), .datos = "No se puede reasignar la constante '{nombre}'" };
            return _ret_155;
        }
        CadenaSegura _ret_156 = (CadenaSegura){ .longitud = (int)strlen("Error desconocido"), .datos = "Error desconocido" };
        return _ret_156;
    }
    if ((codigo == ERR_SYNTAX_EXPECTED_TOKEN)) {
        CadenaSegura _ret_159 = (CadenaSegura){ .longitud = (int)strlen("Expected {esperado}, found '{encontrado}'"), .datos = "Expected {esperado}, found '{encontrado}'" };
        return _ret_159;
    }
    if ((codigo == ERR_SYNTAX_UNEXPECTED_TOKEN)) {
        CadenaSegura _ret_161 = (CadenaSegura){ .longitud = (int)strlen("Unexpected token '{tok_name}' after expression"), .datos = "Unexpected token '{tok_name}' after expression" };
        return _ret_161;
    }
    if ((codigo == ERR_SYNTAX_UNEXPECTED_EXPR)) {
        CadenaSegura _ret_163 = (CadenaSegura){ .longitud = (int)strlen("Unexpected expression: '{tipo}'"), .datos = "Unexpected expression: '{tipo}'" };
        return _ret_163;
    }
    if ((codigo == ERR_SYNTAX_EXPECTED_NEWLINE)) {
        CadenaSegura _ret_165 = (CadenaSegura){ .longitud = (int)strlen("Expected newline after '{construccion}'"), .datos = "Expected newline after '{construccion}'" };
        return _ret_165;
    }
    if ((codigo == ERR_LANG_MISSING)) {
        CadenaSegura _ret_167 = (CadenaSegura){ .longitud = (int)strlen("Missing language declaration '#lang: <code>' at line 1"), .datos = "Missing language declaration '#lang: <code>' at line 1" };
        return _ret_167;
    }
    if ((codigo == ERR_LANG_UNSUPPORTED)) {
        CadenaSegura _ret_169 = (CadenaSegura){ .longitud = (int)strlen("Language '{idioma}' not supported"), .datos = "Language '{idioma}' not supported" };
        return _ret_169;
    }
    if ((codigo == ERR_INDENT_INVALID)) {
        CadenaSegura _ret_171 = (CadenaSegura){ .longitud = (int)strlen("Indentation must be a multiple of 4 spaces"), .datos = "Indentation must be a multiple of 4 spaces" };
        return _ret_171;
    }
    if ((codigo == ERR_INDENT_INCONSISTENT)) {
        CadenaSegura _ret_173 = (CadenaSegura){ .longitud = (int)strlen("Inconsistent indentation level"), .datos = "Inconsistent indentation level" };
        return _ret_173;
    }
    if ((codigo == ERR_STRING_UNCLOSED)) {
        CadenaSegura _ret_175 = (CadenaSegura){ .longitud = (int)strlen("Unclosed string literal"), .datos = "Unclosed string literal" };
        return _ret_175;
    }
    if ((codigo == ERR_LEX)) {
        CadenaSegura _ret_177 = (CadenaSegura){ .longitud = (int)strlen("{mensaje}"), .datos = "{mensaje}" };
        return _ret_177;
    }
    if ((codigo == ERR_LEX_CHAR_UNEXPECTED)) {
        CadenaSegura _ret_179 = (CadenaSegura){ .longitud = (int)strlen("Unexpected character '{char}'"), .datos = "Unexpected character '{char}'" };
        return _ret_179;
    }
    if ((codigo == ERR_FILE_NOT_FOUND)) {
        CadenaSegura _ret_181 = (CadenaSegura){ .longitud = (int)strlen("File not found: {archivo}"), .datos = "File not found: {archivo}" };
        return _ret_181;
    }
    if ((codigo == ERR_CANONICAL_FORMAT)) {
        CadenaSegura _ret_183 = (CadenaSegura){ .longitud = (int)strlen("Unrecognized or corrupted canonical format"), .datos = "Unrecognized or corrupted canonical format" };
        return _ret_183;
    }
    if ((codigo == ERR_SEM_VAR_NO_DECLARADA)) {
        CadenaSegura _ret_185 = (CadenaSegura){ .longitud = (int)strlen("Variable '{nombre}' not declared in this scope"), .datos = "Variable '{nombre}' not declared in this scope" };
        return _ret_185;
    }
    if ((codigo == ERR_SEM_TIPO_INCOMPATIBLE)) {
        CadenaSegura _ret_187 = (CadenaSegura){ .longitud = (int)strlen("Incompatible types: cannot use '{tipo1}' with '{tipo2}' in '{operacion}'"), .datos = "Incompatible types: cannot use '{tipo1}' with '{tipo2}' in '{operacion}'" };
        return _ret_187;
    }
    if ((codigo == ERR_SEM_TIPO_RETORNO)) {
        CadenaSegura _ret_189 = (CadenaSegura){ .longitud = (int)strlen("Incorrect return type: expected '{esperado}', got '{obtenido}'"), .datos = "Incorrect return type: expected '{esperado}', got '{obtenido}'" };
        return _ret_189;
    }
    if ((codigo == ERR_SEM_FUNC_NO_DEFINIDA)) {
        CadenaSegura _ret_191 = (CadenaSegura){ .longitud = (int)strlen("Function '{nombre}' not defined"), .datos = "Function '{nombre}' not defined" };
        return _ret_191;
    }
    if ((codigo == ERR_SEM_REDEFINICION)) {
        CadenaSegura _ret_193 = (CadenaSegura){ .longitud = (int)strlen("Redefinition of '{nombre}' in the same scope"), .datos = "Redefinition of '{nombre}' in the same scope" };
        return _ret_193;
    }
    if ((codigo == ERR_SEM_ARGUMENTOS_INVALIDOS)) {
        CadenaSegura _ret_195 = (CadenaSegura){ .longitud = (int)strlen("Invalid argument count for '{nombre}': expected {esperados}"), .datos = "Invalid argument count for '{nombre}': expected {esperados}" };
        return _ret_195;
    }
    if ((codigo == ERR_SEM_ESTRUCTURA_NO_DEFINIDA)) {
        CadenaSegura _ret_197 = (CadenaSegura){ .longitud = (int)strlen("Struct '{nombre}' not defined"), .datos = "Struct '{nombre}' not defined" };
        return _ret_197;
    }
    if ((codigo == ERR_SEM_CAMPO_NO_EXISTE)) {
        CadenaSegura _ret_199 = (CadenaSegura){ .longitud = (int)strlen("Struct '{struct}' has no field '{campo}'"), .datos = "Struct '{struct}' has no field '{campo}'" };
        return _ret_199;
    }
    if ((codigo == ERR_SEM_VAR_MOVIDA)) {
        CadenaSegura _ret_201 = (CadenaSegura){ .longitud = (int)strlen("Illegal use of already moved variable '{nombre}'"), .datos = "Illegal use of already moved variable '{nombre}'" };
        return _ret_201;
    }
    if ((codigo == ERR_SEM_ACCESO_MEMORIA_MOVIDA)) {
        CadenaSegura _ret_203 = (CadenaSegura){ .longitud = (int)strlen("Forbidden access to moved memory '{nombre}'"), .datos = "Forbidden access to moved memory '{nombre}'" };
        return _ret_203;
    }
    if ((codigo == ERR_SEM_RESULTADO_SIN_DESEMPAQUETAR)) {
        CadenaSegura _ret_205 = (CadenaSegura){ .longitud = (int)strlen("Unpacked channel result"), .datos = "Unpacked channel result" };
        return _ret_205;
    }
    if ((codigo == ERR_MANIFEST_NOT_FOUND)) {
        CadenaSegura _ret_207 = (CadenaSegura){ .longitud = (int)strlen("axon.toml manifest not found in current directory"), .datos = "axon.toml manifest not found in current directory" };
        return _ret_207;
    }
    if ((codigo == ERR_MODULE_STD_NOT_FOUND)) {
        CadenaSegura _ret_209 = (CadenaSegura){ .longitud = (int)strlen("Standard module '{modulo}' not found. Corrupt Sysroot"), .datos = "Standard module '{modulo}' not found. Corrupt Sysroot" };
        return _ret_209;
    }
    if ((codigo == ERR_MODULE_AXON_NOT_FOUND)) {
        CadenaSegura _ret_211 = (CadenaSegura){ .longitud = (int)strlen("Dependency '{modulo}' not found in axon_modules"), .datos = "Dependency '{modulo}' not found in axon_modules" };
        return _ret_211;
    }
    if ((codigo == ERR_DEP_NOT_DECLARED)) {
        CadenaSegura _ret_213 = (CadenaSegura){ .longitud = (int)strlen("Dependency '{modulo}' imported in code but not declared in axon.toml"), .datos = "Dependency '{modulo}' imported in code but not declared in axon.toml" };
        return _ret_213;
    }
    if ((codigo == ERR_LOCK_HASH_MISMATCH)) {
        CadenaSegura _ret_215 = (CadenaSegura){ .longitud = (int)strlen("Hash of dependency '{modulo}' does not match axon.lock"), .datos = "Hash of dependency '{modulo}' does not match axon.lock" };
        return _ret_215;
    }
    if ((codigo == ERR_GIT_FAILURE)) {
        CadenaSegura _ret_217 = (CadenaSegura){ .longitud = (int)strlen("Network error or invalid Git revision for dependency '{modulo}'"), .datos = "Network error or invalid Git revision for dependency '{modulo}'" };
        return _ret_217;
    }
    if ((codigo == ERR_SEM_ASM_FUERA_INSEGURO)) {
        CadenaSegura _ret_219 = (CadenaSegura){ .longitud = (int)strlen("asm() can only be used inside an 'unsafe:' block"), .datos = "asm() can only be used inside an 'unsafe:' block" };
        return _ret_219;
    }
    if ((codigo == ERR_SEM_CONSTANTE_INMUTABLE)) {
        CadenaSegura _ret_221 = (CadenaSegura){ .longitud = (int)strlen("Cannot reassign constant '{nombre}'"), .datos = "Cannot reassign constant '{nombre}'" };
        return _ret_221;
    }
    CadenaSegura _ret_222 = (CadenaSegura){ .longitud = (int)strlen("Unknown error"), .datos = "Unknown error" };
    return _ret_222;
}

CadenaSegura obtener_linea_contexto(CadenaSegura lineas, int linea_num) {
    CadenaSegura r = (CadenaSegura){ .longitud = (int)strlen(""), .datos = "" };
    { /* unsafe */
        // buscar linea_num en buffer de lineas (pendiente);
    }
    CadenaSegura _ret_229 = r;
    return _ret_229;
}

CadenaSegura formatear_entrada_error(CadenaSegura ruta, int linea, int columna, CadenaSegura mensaje) {
    CadenaSegura r = (CadenaSegura){ .longitud = (int)strlen(""), .datos = "" };
    { /* unsafe */
        { char _buf[1024]; snprintf(_buf, 1024, "[Synapse] %s:%d:%d - %s", ruta.datos, linea, columna, mensaje.datos); r = (CadenaSegura){ .longitud = (int)strlen(_buf), .datos = strdup(_buf) }; }
    }
    CadenaSegura _ret_236 = r;
    return _ret_236;
}

CadenaSegura formatear_ubicacion(CadenaSegura ruta, int linea, int columna) {
    if ((linea > 0)) {
        CadenaSegura r = (CadenaSegura){ .longitud = (int)strlen(""), .datos = "" };
        { /* unsafe */
            { char _buf[256]; snprintf(_buf, 256, "%s:%d:%d", ruta.datos, linea, columna); r = (CadenaSegura){ .longitud = (int)strlen(_buf), .datos = strdup(_buf) }; }
        }
        CadenaSegura _ret_244 = r;
        return _ret_244;
    }
    CadenaSegura _ret_245 = ruta;
    return _ret_245;
}

#define NODO_PROGRAMA (1)
#define NODO_FUNCION (2)
#define NODO_SI (3)
#define NODO_MIENTRAS (4)
#define NODO_RETORNAR (5)
#define NODO_EXPR (6)
#define NODO_ASIGNACION (7)
#define NODO_IDENTIFICADOR (8)
#define NODO_NUMERO (9)
#define NODO_DECIMAL (10)
#define NODO_CADENA_LIT (11)
#define NODO_BINARIA (12)
#define NODO_UNARIA (13)
#define NODO_LLAMADA (14)
#define NODO_PARAMETRO (15)
#define NODO_ESTRUCTURA (16)
#define NODO_IMPORTAR (17)
#define NODO_LANZAR (18)
#define NODO_ESCUCHAR (19)
#define NODO_ROMPER (20)
#define NODO_SIGUIENTE (21)
#define NODO_BOOLEANO (22)
#define NODO_CONSTANTE (23)
#define NODO_INSEGURO (24)
#define NODO_IMPORTAR_C (25)
#define NODO_EXTERNO (26)
#define NODO_RECUPERAR (27)
#define NODO_TENSOR (28)
#define NODO_INDICE (29)
#define NODO_TRANSFERIDO (30)
#define NODO_ACCESO_CAMPO (31)
#define NODO_ASIGNACION_CAMPO (32)
#define NODO_PARRAFO (33)
#define NODO_DECLARACION (34)
#define NODO_LOG (35)
#define NODO_PUNTERO (36)
#define NODO_DEREF (37)
#define NODO_COINCIDIR (38)
#define NODO_CASO (39)
#define NODO_ASM (40)
#define NODO_CANAL_CREAR (41)
#define NODO_ENVIAR_CANAL (42)
#define NODO_RECIBIR_CANAL (43)
#define NODO_VACIO (44)
#define NODO_PARA (45)
#define NODO_CONTRATO (46)
int parser_nuevo_nodo(struct ParserEst est, int tipo, int linea, int columna) {
    int idx;
    { /* unsafe */
        idx = 0;
        idx = est.total_nodos;
        est.nodos[idx].tipo_nodo = tipo;
        est.nodos[idx].linea = linea;
        est.nodos[idx].columna = columna;
        est.nodos[idx].valor_int = 0;
        est.nodos[idx].hijo_izq = 0;
        est.nodos[idx].hijo_der = 0;
        est.nodos[idx].hermano = 0;
        est.total_nodos = idx + 1;
        int _ret_161 = idx;
        return _ret_161;
    }
}

void parser_error(struct ParserEst est, CadenaSegura mensaje, int linea, int columna) {
    est.hay_error = 1;
    est.error_mensaje = mensaje;
    est.error_linea = linea;
    est.error_columna = columna;
}

int token_tipo(struct ParserEst est, int pos) {
    int r;
    { /* unsafe */
        r = 0;
        r = (pos < est.total_tokens) ? est.tokens[pos].tipo : 57;
        int _ret_175 = r;
        return _ret_175;
    }
}

int token_linea(struct ParserEst est, int pos) {
    int r;
    { /* unsafe */
        r = 0;
        r = (pos < est.total_tokens) ? est.tokens[pos].linea : 0;
        int _ret_181 = r;
        return _ret_181;
    }
}

int token_columna(struct ParserEst est, int pos) {
    int r;
    { /* unsafe */
        r = 0;
        r = (pos < est.total_tokens) ? est.tokens[pos].columna : 0;
        int _ret_187 = r;
        return _ret_187;
    }
}

void token_avanzar(struct ParserEst est) {
    { /* unsafe */
        est.posicion = est.posicion + 1;
    }
}

int token_mirar(struct ParserEst est) {
    int r;
    { /* unsafe */
        r = 0;
        r = (est.posicion < est.total_tokens) ? est.tokens[est.posicion].tipo : 57;
        int _ret_197 = r;
        return _ret_197;
    }
}

int token_esperar(struct ParserEst est, int esperado) {
    int t;
    t = token_mirar(est);
    if ((t == esperado)) {
        { /* unsafe */
            est.posicion = est.posicion + 1;
        }
        int _ret_204 = 1;
        return _ret_204;
    }
    est.hay_error = 1;
    int _ret_206 = 0;
    return _ret_206;
}

int token_esperar_texto(struct ParserEst est, int esperado) {
    int t;
    int linea;
    int col;
    t = token_mirar(est);
    if ((t == esperado)) {
        linea = token_linea(est, est.posicion);
        col = token_columna(est, est.posicion);
        { /* unsafe */
            est.posicion = est.posicion + 1;
        }
        int _ret_215 = parser_nuevo_nodo(est, NODO_IDENTIFICADOR, linea, col);
        return _ret_215;
    }
    est.hay_error = 1;
    int _ret_217 = 0;
    return _ret_217;
}

int parsear_expresion(struct ParserEst est) {
    int _ret_221 = parsear_logica(est);
    return _ret_221;
}

int parsear_logica(struct ParserEst est) {
    int linea;
    int col;
    int der;
    int nodo;
    int izq;
    int r;
    int t;
    linea = 0;
    col = 0;
    der = 0;
    nodo = 0;
    izq = parsear_comparacion(est);
    r = 1;
    while ((r == 1)) {
        t = token_mirar(est);
        if ((t == T_Y)) {
            linea = token_linea(est, est.posicion);
            col = token_columna(est, est.posicion);
            token_avanzar(est);
            der = parsear_comparacion(est);
            nodo = parser_nuevo_nodo(est, NODO_BINARIA, linea, col);
            { /* unsafe */
                est.nodos[nodo].valor_int = 100;
                est.nodos[nodo].hijo_izq = izq;
                est.nodos[nodo].hijo_der = der;
            }
            izq = nodo;
            continue;
        }
        if ((t == T_O)) {
            linea = token_linea(est, est.posicion);
            col = token_columna(est, est.posicion);
            token_avanzar(est);
            der = parsear_comparacion(est);
            nodo = parser_nuevo_nodo(est, NODO_BINARIA, linea, col);
            { /* unsafe */
                est.nodos[nodo].valor_int = 101;
                est.nodos[nodo].hijo_izq = izq;
                est.nodos[nodo].hijo_der = der;
            }
            izq = nodo;
            continue;
        }
        r = 0;
    }
    int _ret_257 = izq;
    return _ret_257;
}

int parsear_comparacion(struct ParserEst est) {
    int linea;
    int col;
    int der;
    int nodo;
    int izq;
    int r;
    int t;
    linea = 0;
    col = 0;
    der = 0;
    nodo = 0;
    izq = parsear_adicion(est);
    r = 1;
    while ((r == 1)) {
        t = token_mirar(est);
        if ((t == T_MAYOR)) {
            linea = token_linea(est, est.posicion);
            col = token_columna(est, est.posicion);
            token_avanzar(est);
            der = parsear_adicion(est);
            nodo = parser_nuevo_nodo(est, NODO_BINARIA, linea, col);
            { /* unsafe */
                est.nodos[nodo].valor_int = 200;
                est.nodos[nodo].hijo_izq = izq;
                est.nodos[nodo].hijo_der = der;
            }
            izq = nodo;
            continue;
        }
        if ((t == T_MENOR)) {
            linea = token_linea(est, est.posicion);
            col = token_columna(est, est.posicion);
            token_avanzar(est);
            der = parsear_adicion(est);
            nodo = parser_nuevo_nodo(est, NODO_BINARIA, linea, col);
            { /* unsafe */
                est.nodos[nodo].valor_int = 201;
                est.nodos[nodo].hijo_izq = izq;
                est.nodos[nodo].hijo_der = der;
            }
            izq = nodo;
            continue;
        }
        if ((t == T_IGUAL)) {
            linea = token_linea(est, est.posicion);
            col = token_columna(est, est.posicion);
            token_avanzar(est);
            der = parsear_adicion(est);
            nodo = parser_nuevo_nodo(est, NODO_BINARIA, linea, col);
            { /* unsafe */
                est.nodos[nodo].valor_int = 202;
                est.nodos[nodo].hijo_izq = izq;
                est.nodos[nodo].hijo_der = der;
            }
            izq = nodo;
            continue;
        }
        if ((t == T_DISTINTO)) {
            linea = token_linea(est, est.posicion);
            col = token_columna(est, est.posicion);
            token_avanzar(est);
            der = parsear_adicion(est);
            nodo = parser_nuevo_nodo(est, NODO_BINARIA, linea, col);
            { /* unsafe */
                est.nodos[nodo].valor_int = 203;
                est.nodos[nodo].hijo_izq = izq;
                est.nodos[nodo].hijo_der = der;
            }
            izq = nodo;
            continue;
        }
        if ((t == T_MENOR_IGUAL)) {
            linea = token_linea(est, est.posicion);
            col = token_columna(est, est.posicion);
            token_avanzar(est);
            der = parsear_adicion(est);
            nodo = parser_nuevo_nodo(est, NODO_BINARIA, linea, col);
            { /* unsafe */
                est.nodos[nodo].valor_int = 204;
                est.nodos[nodo].hijo_izq = izq;
                est.nodos[nodo].hijo_der = der;
            }
            izq = nodo;
            continue;
        }
        if ((t == T_MAYOR_IGUAL)) {
            linea = token_linea(est, est.posicion);
            col = token_columna(est, est.posicion);
            token_avanzar(est);
            der = parsear_adicion(est);
            nodo = parser_nuevo_nodo(est, NODO_BINARIA, linea, col);
            { /* unsafe */
                est.nodos[nodo].valor_int = 205;
                est.nodos[nodo].hijo_izq = izq;
                est.nodos[nodo].hijo_der = der;
            }
            izq = nodo;
            continue;
        }
        r = 0;
    }
    int _ret_341 = izq;
    return _ret_341;
}

int parsear_adicion(struct ParserEst est) {
    int linea;
    int col;
    int der;
    int nodo;
    int izq;
    int r;
    int t;
    linea = 0;
    col = 0;
    der = 0;
    nodo = 0;
    izq = parsear_multiplicacion(est);
    r = 1;
    while ((r == 1)) {
        t = token_mirar(est);
        if ((t == T_MAS)) {
            linea = token_linea(est, est.posicion);
            col = token_columna(est, est.posicion);
            token_avanzar(est);
            der = parsear_multiplicacion(est);
            nodo = parser_nuevo_nodo(est, NODO_BINARIA, linea, col);
            { /* unsafe */
                est.nodos[nodo].valor_int = 300;
                est.nodos[nodo].hijo_izq = izq;
                est.nodos[nodo].hijo_der = der;
            }
            izq = nodo;
            continue;
        }
        if ((t == T_MENOS)) {
            linea = token_linea(est, est.posicion);
            col = token_columna(est, est.posicion);
            token_avanzar(est);
            der = parsear_multiplicacion(est);
            nodo = parser_nuevo_nodo(est, NODO_BINARIA, linea, col);
            { /* unsafe */
                est.nodos[nodo].valor_int = 301;
                est.nodos[nodo].hijo_izq = izq;
                est.nodos[nodo].hijo_der = der;
            }
            izq = nodo;
            continue;
        }
        r = 0;
    }
    int _ret_377 = izq;
    return _ret_377;
}

int parsear_multiplicacion(struct ParserEst est) {
    int linea;
    int col;
    int der;
    int nodo;
    int izq;
    int r;
    int t;
    linea = 0;
    col = 0;
    der = 0;
    nodo = 0;
    izq = parsear_unario(est);
    r = 1;
    while ((r == 1)) {
        t = token_mirar(est);
        if ((t == T_POR)) {
            linea = token_linea(est, est.posicion);
            col = token_columna(est, est.posicion);
            token_avanzar(est);
            der = parsear_unario(est);
            nodo = parser_nuevo_nodo(est, NODO_BINARIA, linea, col);
            { /* unsafe */
                est.nodos[nodo].valor_int = 400;
                est.nodos[nodo].hijo_izq = izq;
                est.nodos[nodo].hijo_der = der;
            }
            izq = nodo;
            continue;
        }
        if ((t == T_DIV)) {
            linea = token_linea(est, est.posicion);
            col = token_columna(est, est.posicion);
            token_avanzar(est);
            der = parsear_unario(est);
            nodo = parser_nuevo_nodo(est, NODO_BINARIA, linea, col);
            { /* unsafe */
                est.nodos[nodo].valor_int = 401;
                est.nodos[nodo].hijo_izq = izq;
                est.nodos[nodo].hijo_der = der;
            }
            izq = nodo;
            continue;
        }
        if ((t == T_MOD)) {
            linea = token_linea(est, est.posicion);
            col = token_columna(est, est.posicion);
            token_avanzar(est);
            der = parsear_unario(est);
            nodo = parser_nuevo_nodo(est, NODO_BINARIA, linea, col);
            { /* unsafe */
                est.nodos[nodo].valor_int = 402;
                est.nodos[nodo].hijo_izq = izq;
                est.nodos[nodo].hijo_der = der;
            }
            izq = nodo;
            continue;
        }
        r = 0;
    }
    int _ret_425 = izq;
    return _ret_425;
}

int parsear_unario(struct ParserEst est) {
    int linea;
    int col;
    int expr;
    int nodo;
    int t;
    linea = 0;
    col = 0;
    expr = 0;
    nodo = 0;
    t = token_mirar(est);
    if ((t == T_MENOS)) {
        linea = token_linea(est, est.posicion);
        col = token_columna(est, est.posicion);
        token_avanzar(est);
        expr = parsear_unario(est);
        nodo = parser_nuevo_nodo(est, NODO_UNARIA, linea, col);
        { /* unsafe */
            est.nodos[nodo].valor_int = 500;
            est.nodos[nodo].hijo_izq = expr;
        }
        int _ret_442 = nodo;
        return _ret_442;
    }
    if ((t == T_NO)) {
        linea = token_linea(est, est.posicion);
        col = token_columna(est, est.posicion);
        token_avanzar(est);
        expr = parsear_unario(est);
        nodo = parser_nuevo_nodo(est, NODO_UNARIA, linea, col);
        { /* unsafe */
            est.nodos[nodo].valor_int = 501;
            est.nodos[nodo].hijo_izq = expr;
        }
        int _ret_452 = nodo;
        return _ret_452;
    }
    if ((t == T_AMPERSAND)) {
        linea = token_linea(est, est.posicion);
        col = token_columna(est, est.posicion);
        token_avanzar(est);
        expr = parsear_unario(est);
        nodo = parser_nuevo_nodo(est, NODO_PUNTERO, linea, col);
        { /* unsafe */
            est.nodos[nodo].hijo_izq = expr;
        }
        int _ret_461 = nodo;
        return _ret_461;
    }
    if ((t == T_POR)) {
        linea = token_linea(est, est.posicion);
        col = token_columna(est, est.posicion);
        token_avanzar(est);
        expr = parsear_unario(est);
        nodo = parser_nuevo_nodo(est, NODO_DEREF, linea, col);
        { /* unsafe */
            est.nodos[nodo].hijo_izq = expr;
        }
        int _ret_470 = nodo;
        return _ret_470;
    }
    int _ret_471 = parsear_primario(est);
    return _ret_471;
}

int parsear_primario(struct ParserEst est) {
    int linea;
    int col;
    int nodo;
    int t;
    int t2;
    int r;
    int arg;
    int tok_campo;
    int linea2;
    int col2;
    int nodo2;
    int expr;
    linea = 0;
    col = 0;
    nodo = 0;
    t = token_mirar(est);
    if ((t == T_NUMERO)) {
        linea = token_linea(est, est.posicion);
        col = token_columna(est, est.posicion);
        token_avanzar(est);
        nodo = parser_nuevo_nodo(est, NODO_NUMERO, linea, col);
        int _ret_483 = nodo;
        return _ret_483;
    }
    if ((t == T_FLOTANTE)) {
        linea = token_linea(est, est.posicion);
        col = token_columna(est, est.posicion);
        token_avanzar(est);
        nodo = parser_nuevo_nodo(est, NODO_DECIMAL, linea, col);
        int _ret_489 = nodo;
        return _ret_489;
    }
    if ((t == T_CADENA)) {
        linea = token_linea(est, est.posicion);
        col = token_columna(est, est.posicion);
        token_avanzar(est);
        nodo = parser_nuevo_nodo(est, NODO_CADENA_LIT, linea, col);
        int _ret_495 = nodo;
        return _ret_495;
    }
    if ((t == T_VERDADERO)) {
        linea = token_linea(est, est.posicion);
        col = token_columna(est, est.posicion);
        token_avanzar(est);
        nodo = parser_nuevo_nodo(est, NODO_BOOLEANO, linea, col);
        { /* unsafe */
            est.nodos[nodo].valor_int = 1;
        }
        int _ret_503 = nodo;
        return _ret_503;
    }
    if ((t == T_FALSO)) {
        linea = token_linea(est, est.posicion);
        col = token_columna(est, est.posicion);
        token_avanzar(est);
        nodo = parser_nuevo_nodo(est, NODO_BOOLEANO, linea, col);
        { /* unsafe */
            est.nodos[nodo].valor_int = 0;
        }
        int _ret_511 = nodo;
        return _ret_511;
    }
    if ((t == T_IDENTIFICADOR)) {
        linea = token_linea(est, est.posicion);
        col = token_columna(est, est.posicion);
        token_avanzar(est);
        nodo = parser_nuevo_nodo(est, NODO_IDENTIFICADOR, linea, col);
        t2 = token_mirar(est);
        if ((t2 == T_PAREN_IZQ)) {
            { /* unsafe */
                est.nodos[nodo].tipo_nodo = 14;
            }
            token_esperar(est, T_PAREN_IZQ);
            r = 1;
            while ((r == 1)) {
                if ((token_mirar(est) == T_PAREN_DER)) {
                    break;
                }
                arg = parsear_expresion(est);
                if ((token_mirar(est) == T_COMA)) {
                    token_avanzar(est);
                    continue;
                }
                r = 1;
            }
            token_esperar(est, T_PAREN_DER);
        }
        if ((t2 == T_PUNTO)) {
            if ((token_mirar(est) == T_PUNTO)) {
                token_avanzar(est);
                tok_campo = token_mirar(est);
                linea2 = token_linea(est, est.posicion);
                col2 = token_columna(est, est.posicion);
                if ((tok_campo == T_IDENTIFICADOR)) {
                    token_avanzar(est);
                    nodo2 = parser_nuevo_nodo(est, NODO_ACCESO_CAMPO, linea2, col2);
                    { /* unsafe */
                        est.nodos[nodo2].hijo_izq = nodo;
                    }
                    nodo = nodo2;
                }
            }
        }
        int _ret_544 = nodo;
        return _ret_544;
    }
    if ((t == T_CANAL)) {
        linea = token_linea(est, est.posicion);
        col = token_columna(est, est.posicion);
        token_avanzar(est);
        if ((token_mirar(est) == T_PAREN_IZQ)) {
            nodo = parser_nuevo_nodo(est, NODO_CANAL_CREAR, linea, col);
            token_esperar(est, T_PAREN_IZQ);
            if ((token_mirar(est) == T_IDENTIFICADOR)) {
                token_avanzar(est);
            }
            if ((token_mirar(est) == T_COMA)) {
                token_avanzar(est);
                expr = parsear_expresion(est);
                { /* unsafe */
                    est.nodos[nodo].hijo_izq = expr;
                }
            }
            token_esperar(est, T_PAREN_DER);
            int _ret_560 = nodo;
            return _ret_560;
        }
        parser_error(est, (CadenaSegura){ .longitud = (int)strlen("Se esperaba ( despues de canal"), .datos = "Se esperaba ( despues de canal" }, linea, col);
        int _ret_562 = 0;
        return _ret_562;
    }
    if ((t == T_PAREN_IZQ)) {
        token_avanzar(est);
        expr = parsear_expresion(est);
        token_esperar(est, T_PAREN_DER);
        int _ret_567 = expr;
        return _ret_567;
    }
    parser_error(est, (CadenaSegura){ .longitud = (int)strlen("Expresion inesperada"), .datos = "Expresion inesperada" }, token_linea(est, est.posicion), token_columna(est, est.posicion));
    int _ret_569 = 0;
    return _ret_569;
}

int parsear_sentencia(struct ParserEst est) {
    int linea;
    int col;
    int nodo;
    int t;
    int expr;
    int t2;
    int t3;
    int plan_b;
    linea = 0;
    col = 0;
    nodo = 0;
    t = token_mirar(est);
    if ((t == T_FUNCION)) {
        int _ret_578 = parsear_funcion(est);
        return _ret_578;
    }
    if ((t == T_ESTRUCTURA)) {
        int _ret_580 = parsear_estructura_def(est);
        return _ret_580;
    }
    if ((t == T_IF)) {
        int _ret_582 = parsear_si(est);
        return _ret_582;
    }
    if ((t == T_MIENTRAS)) {
        int _ret_584 = parsear_mientras(est);
        return _ret_584;
    }
    if ((t == T_PARA)) {
        int _ret_586 = parsear_para(est);
        return _ret_586;
    }
    if ((t == T_RETORNAR)) {
        int _ret_588 = parsear_retornar(est);
        return _ret_588;
    }
    if ((t == T_LANZAR)) {
        int _ret_590 = parsear_lanzar(est);
        return _ret_590;
    }
    if ((t == T_ESCUCHAR)) {
        int _ret_592 = parsear_escuchar(est);
        return _ret_592;
    }
    if ((t == T_ROMPER)) {
        linea = token_linea(est, est.posicion);
        col = token_columna(est, est.posicion);
        token_avanzar(est);
        int _ret_597 = parser_nuevo_nodo(est, NODO_ROMPER, linea, col);
        return _ret_597;
    }
    if ((t == T_SIGUIENTE)) {
        linea = token_linea(est, est.posicion);
        col = token_columna(est, est.posicion);
        token_avanzar(est);
        int _ret_602 = parser_nuevo_nodo(est, NODO_SIGUIENTE, linea, col);
        return _ret_602;
    }
    if ((t == T_IMPORTAR)) {
        linea = token_linea(est, est.posicion);
        col = token_columna(est, est.posicion);
        token_avanzar(est);
        nodo = parser_nuevo_nodo(est, NODO_IMPORTAR, linea, col);
        int _ret_608 = nodo;
        return _ret_608;
    }
    if ((t == T_ESTRUCTURA)) {
        int _ret_610 = parsear_estructura_def(est);
        return _ret_610;
    }
    if ((t == T_CONSTANTE)) {
        int _ret_612 = parsear_constante(est);
        return _ret_612;
    }
    if ((t == T_ASM)) {
        int _ret_614 = parsear_asm(est);
        return _ret_614;
    }
    if ((t == T_INSEGURO)) {
        int _ret_616 = parsear_inseguro(est);
        return _ret_616;
    }
    if ((t == T_IMPORTAR_C)) {
        int _ret_618 = parsear_importar_c(est);
        return _ret_618;
    }
    if ((t == T_EXTERNO)) {
        int _ret_620 = parsear_externo(est);
        return _ret_620;
    }
    if ((t == T_COINCIDIR)) {
        int _ret_622 = parsear_coincidir(est);
        return _ret_622;
    }
    if ((t == T_INDENTAR)) {
        int _ret_624 = 0;
        return _ret_624;
    }
    if ((t == T_DESINDENTAR)) {
        int _ret_626 = 0;
        return _ret_626;
    }
    if ((t == T_NUEVALINEA)) {
        int _ret_628 = 0;
        return _ret_628;
    }
    if ((t == T_FIN)) {
        int _ret_630 = 0;
        return _ret_630;
    }
    if ((t == T_CANAL)) {
        linea = token_linea(est, est.posicion);
        col = token_columna(est, est.posicion);
        expr = parsear_expresion(est);
        nodo = parser_nuevo_nodo(est, NODO_EXPR, linea, col);
        { /* unsafe */
            est.nodos[nodo].hijo_izq = expr;
        }
        int _ret_638 = nodo;
        return _ret_638;
    }
    if ((t == T_IDENTIFICADOR)) {
        t2 = token_tipo(est, (est.posicion + 1));
        if ((t2 == T_ASIGNAR)) {
            int _ret_642 = parsear_asignacion(est);
            return _ret_642;
        }
        if ((t2 == T_FLECHA_IZQ)) {
            int _ret_644 = parsear_enviar_canal(est);
            return _ret_644;
        }
        if ((t2 == T_FLECHA)) {
            int _ret_646 = parsear_recibir_canal(est);
            return _ret_646;
        }
        linea = token_linea(est, est.posicion);
        col = token_columna(est, est.posicion);
        expr = parsear_expresion(est);
        t3 = token_mirar(est);
        if ((t3 == T_RECUPERAR)) {
            token_avanzar(est);
            token_esperar(est, T_DOSPUNTOS);
            plan_b = parsear_expresion(est);
            int _ret_656 = expr;
            return _ret_656;
        }
        nodo = parser_nuevo_nodo(est, NODO_EXPR, linea, col);
        { /* unsafe */
            est.nodos[nodo].hijo_izq = expr;
        }
        int _ret_660 = nodo;
        return _ret_660;
    }
    int _ret_661 = 0;
    return _ret_661;
}

int parsear_funcion(struct ParserEst est) {
    int r2;
    int expr;
    int r;
    int t;
    int linea;
    int col;
    int nodo_func;
    int ultimo_param;
    int linea_p;
    int col_p;
    int nodo_p;
    int primera_requiere;
    int ultima_requiere;
    int cuenta_requiere;
    int primera_garantiza;
    int ultima_garantiza;
    int cuenta_garantiza;
    int contrato;
    int stmt;
    r2 = 0;
    expr = 0;
    r = 0;
    if ((token_esperar(est, T_FUNCION) == 0)) {
        int _ret_669 = 0;
        return _ret_669;
    }
    t = token_mirar(est);
    if ((t != T_IDENTIFICADOR)) {
        parser_error(est, (CadenaSegura){ .longitud = (int)strlen("Se esperaba nombre de funcion"), .datos = "Se esperaba nombre de funcion" }, token_linea(est, est.posicion), token_columna(est, est.posicion));
        int _ret_673 = 0;
        return _ret_673;
    }
    linea = token_linea(est, est.posicion);
    col = token_columna(est, est.posicion);
    token_avanzar(est);
    nodo_func = parser_nuevo_nodo(est, NODO_FUNCION, linea, col);
    if ((token_esperar(est, T_PAREN_IZQ) == 0)) {
        int _ret_679 = 0;
        return _ret_679;
    }
    ultimo_param = 0;
    if ((token_mirar(est) != T_PAREN_DER)) {
        r = 1;
        while ((r == 1)) {
            linea_p = token_linea(est, est.posicion);
            col_p = token_columna(est, est.posicion);
            if ((token_mirar(est) == T_IDENTIFICADOR)) {
                token_avanzar(est);
                if ((token_esperar(est, T_DOSPUNTOS) == 0)) {
                    int _ret_690 = 0;
                    return _ret_690;
                }
                if ((token_mirar(est) == T_IDENTIFICADOR)) {
                    token_avanzar(est);
                    nodo_p = parser_nuevo_nodo(est, NODO_PARAMETRO, linea_p, col_p);
                    if ((token_mirar(est) == T_COMA)) {
                        token_avanzar(est);
                        continue;
                    }
                    else {
                        r = 0;
                    }
                }
                else {
                    r = 0;
                }
            }
            else {
                r = 0;
            }
        }
    }
    if ((token_esperar(est, T_PAREN_DER) == 0)) {
        int _ret_704 = 0;
        return _ret_704;
    }
    if ((token_esperar(est, T_FLECHA) == 0)) {
        int _ret_706 = 0;
        return _ret_706;
    }
    if ((token_mirar(est) == T_IDENTIFICADOR)) {
        token_avanzar(est);
    }
    if ((token_esperar(est, T_DOSPUNTOS) == 0)) {
        int _ret_711 = 0;
        return _ret_711;
    }
    primera_requiere = 0;
    ultima_requiere = 0;
    cuenta_requiere = 0;
    primera_garantiza = 0;
    ultima_garantiza = 0;
    cuenta_garantiza = 0;
    r = 1;
    while ((r == 1)) {
        t = token_mirar(est);
        if ((t == T_NUEVALINEA)) {
            token_avanzar(est);
            continue;
        }
        if ((t == T_INDENTAR)) {
            token_avanzar(est);
            while ((r == 1)) {
                t = token_mirar(est);
                if ((t == T_REQUIERE)) {
                    token_avanzar(est);
                    if ((token_esperar(est, T_DOSPUNTOS) == 0)) {
                        int _ret_732 = 0;
                        return _ret_732;
                    }
                    r2 = 1;
                    while ((r2 == 1)) {
                        t = token_mirar(est);
                        if ((t == T_NUEVALINEA)) {
                            token_avanzar(est);
                            continue;
                        }
                        if ((t == T_INDENTAR)) {
                            token_avanzar(est);
                            while ((r2 == 1)) {
                                t = token_mirar(est);
                                if ((t == T_NUEVALINEA)) {
                                    token_avanzar(est);
                                    continue;
                                }
                                if ((t == T_DESINDENTAR)) {
                                    token_avanzar(est);
                                    r2 = 0;
                                    break;
                                }
                                expr = parsear_expresion(est);
                                if ((expr != 0)) {
                                    if ((primera_requiere == 0)) {
                                        primera_requiere = expr;
                                        ultima_requiere = expr;
                                    }
                                    else {
                                        { /* unsafe */
                                            est.nodos[ultima_requiere].hermano = expr;
                                        }
                                        ultima_requiere = expr;
                                    }
                                    cuenta_requiere = (cuenta_requiere + 1);
                                }
                                continue;
                            }
                        }
                        else {
                            r2 = 0;
                        }
                    }
                    continue;
                }
                if ((t == T_GARANTIZA)) {
                    token_avanzar(est);
                    if ((token_esperar(est, T_DOSPUNTOS) == 0)) {
                        int _ret_767 = 0;
                        return _ret_767;
                    }
                    r2 = 1;
                    while ((r2 == 1)) {
                        t = token_mirar(est);
                        if ((t == T_NUEVALINEA)) {
                            token_avanzar(est);
                            continue;
                        }
                        if ((t == T_INDENTAR)) {
                            token_avanzar(est);
                            while ((r2 == 1)) {
                                t = token_mirar(est);
                                if ((t == T_NUEVALINEA)) {
                                    token_avanzar(est);
                                    continue;
                                }
                                if ((t == T_DESINDENTAR)) {
                                    token_avanzar(est);
                                    r2 = 0;
                                    break;
                                }
                                expr = parsear_expresion(est);
                                if ((expr != 0)) {
                                    if ((primera_garantiza == 0)) {
                                        primera_garantiza = expr;
                                        ultima_garantiza = expr;
                                    }
                                    else {
                                        { /* unsafe */
                                            est.nodos[ultima_garantiza].hermano = expr;
                                        }
                                        ultima_garantiza = expr;
                                    }
                                    cuenta_garantiza = (cuenta_garantiza + 1);
                                }
                                continue;
                            }
                        }
                        else {
                            r2 = 0;
                        }
                    }
                    continue;
                }
                if ((t == T_DESINDENTAR)) {
                    token_avanzar(est);
                    r = 0;
                    break;
                }
                r = 0;
            }
        }
        else {
            r = 0;
        }
    }
    if (((primera_requiere != 0) || (primera_garantiza != 0))) {
        contrato = parser_nuevo_nodo(est, NODO_CONTRATO, linea, col);
        { /* unsafe */
            est.nodos[contrato].hijo_izq = primera_requiere;
            est.nodos[contrato].hijo_der = primera_garantiza;
            est.nodos[contrato].valor_int = cuenta_requiere;
            est.nodos[nodo_func].ptr_extra = contrato;
        }
    }
    if ((token_mirar(est) == T_INDENTAR)) {
        token_avanzar(est);
        while ((r == 1)) {
            t = token_mirar(est);
            if ((t == T_NUEVALINEA)) {
                token_avanzar(est);
                continue;
            }
            if ((t == T_DESINDENTAR)) {
                token_avanzar(est);
                r = 0;
                break;
            }
            if ((t == T_FIN)) {
                r = 0;
                break;
            }
            stmt = parsear_sentencia(est);
            continue;
        }
    }
    int _ret_831 = nodo_func;
    return _ret_831;
}

int parsear_si(struct ParserEst est) {
    int t;
    int stmt;
    int r;
    int linea;
    int col;
    int nodo;
    int cond;
    t = 0;
    stmt = 0;
    r = 1;
    if ((token_esperar(est, T_IF) == 0)) {
        int _ret_839 = 0;
        return _ret_839;
    }
    linea = token_linea(est, est.posicion);
    col = token_columna(est, est.posicion);
    nodo = parser_nuevo_nodo(est, NODO_SI, linea, col);
    cond = parsear_expresion(est);
    { /* unsafe */
        est.nodos[nodo].hijo_izq = cond;
    }
    if ((token_esperar(est, T_DOSPUNTOS) == 0)) {
        int _ret_847 = 0;
        return _ret_847;
    }
    if ((token_mirar(est) == T_NUEVALINEA)) {
        token_avanzar(est);
        if ((token_mirar(est) == T_INDENTAR)) {
            token_avanzar(est);
            while ((r == 1)) {
                t = token_mirar(est);
                if ((t == T_NUEVALINEA)) {
                    token_avanzar(est);
                    continue;
                }
                if ((t == T_DESINDENTAR)) {
                    token_avanzar(est);
                    r = 0;
                    break;
                }
                if ((t == T_FIN)) {
                    r = 0;
                    break;
                }
                stmt = parsear_sentencia(est);
                continue;
            }
        }
    }
    r = 1;
    if ((token_mirar(est) == T_ELSE)) {
        token_avanzar(est);
        if ((token_esperar(est, T_DOSPUNTOS) == 0)) {
            int _ret_870 = 0;
            return _ret_870;
        }
        if ((token_mirar(est) == T_NUEVALINEA)) {
            token_avanzar(est);
            if ((token_mirar(est) == T_INDENTAR)) {
                token_avanzar(est);
                while ((r == 1)) {
                    t = token_mirar(est);
                    if ((t == T_NUEVALINEA)) {
                        token_avanzar(est);
                        continue;
                    }
                    if ((t == T_DESINDENTAR)) {
                        token_avanzar(est);
                        r = 0;
                        break;
                    }
                    if ((t == T_FIN)) {
                        r = 0;
                        break;
                    }
                    stmt = parsear_sentencia(est);
                    continue;
                }
            }
        }
    }
    int _ret_889 = nodo;
    return _ret_889;
}

int parsear_mientras(struct ParserEst est) {
    int linea;
    int col;
    int nodo;
    int cond;
    int r;
    int t;
    int stmt;
    if ((token_esperar(est, T_MIENTRAS) == 0)) {
        int _ret_893 = 0;
        return _ret_893;
    }
    linea = token_linea(est, est.posicion);
    col = token_columna(est, est.posicion);
    nodo = parser_nuevo_nodo(est, NODO_MIENTRAS, linea, col);
    cond = parsear_expresion(est);
    { /* unsafe */
        est.nodos[nodo].hijo_izq = cond;
    }
    if ((token_esperar(est, T_DOSPUNTOS) == 0)) {
        int _ret_901 = 0;
        return _ret_901;
    }
    if ((token_mirar(est) == T_NUEVALINEA)) {
        token_avanzar(est);
        if ((token_mirar(est) == T_INDENTAR)) {
            token_avanzar(est);
            r = 1;
            while ((r == 1)) {
                t = token_mirar(est);
                if ((t == T_NUEVALINEA)) {
                    token_avanzar(est);
                    continue;
                }
                if ((t == T_DESINDENTAR)) {
                    token_avanzar(est);
                    r = 0;
                    break;
                }
                if ((t == T_FIN)) {
                    r = 0;
                    break;
                }
                stmt = parsear_sentencia(est);
                continue;
            }
        }
    }
    int _ret_921 = nodo;
    return _ret_921;
}

int parsear_para(struct ParserEst est) {
    int linea;
    int col;
    int nodo;
    int r;
    int t;
    int stmt;
    if ((token_esperar(est, T_PARA) == 0)) {
        int _ret_925 = 0;
        return _ret_925;
    }
    linea = token_linea(est, est.posicion);
    col = token_columna(est, est.posicion);
    nodo = parser_nuevo_nodo(est, NODO_VACIO, linea, col);
    parsear_asignacion(est);
    if ((token_esperar(est, T_PUNTOCOMA) == 0)) {
        int _ret_931 = 0;
        return _ret_931;
    }
    parsear_expresion(est);
    if ((token_esperar(est, T_PUNTOCOMA) == 0)) {
        int _ret_934 = 0;
        return _ret_934;
    }
    parsear_asignacion(est);
    if ((token_esperar(est, T_DOSPUNTOS) == 0)) {
        int _ret_937 = 0;
        return _ret_937;
    }
    if ((token_mirar(est) == T_NUEVALINEA)) {
        token_avanzar(est);
        if ((token_mirar(est) == T_INDENTAR)) {
            token_avanzar(est);
            r = 1;
            while ((r == 1)) {
                t = token_mirar(est);
                if ((t == T_NUEVALINEA)) {
                    token_avanzar(est);
                    continue;
                }
                if ((t == T_DESINDENTAR)) {
                    token_avanzar(est);
                    r = 0;
                    break;
                }
                if ((t == T_FIN)) {
                    r = 0;
                    break;
                }
                stmt = parsear_sentencia(est);
                continue;
            }
        }
    }
    int _ret_957 = nodo;
    return _ret_957;
}

int parsear_retornar(struct ParserEst est) {
    int linea;
    int col;
    int nodo;
    int t;
    int expr;
    if ((token_esperar(est, T_RETORNAR) == 0)) {
        int _ret_961 = 0;
        return _ret_961;
    }
    linea = token_linea(est, est.posicion);
    col = token_columna(est, est.posicion);
    nodo = parser_nuevo_nodo(est, NODO_RETORNAR, linea, col);
    t = token_mirar(est);
    if ((t != T_NUEVALINEA)) {
        if ((t != T_DESINDENTAR)) {
            if ((t != T_FIN)) {
                expr = parsear_expresion(est);
                { /* unsafe */
                    est.nodos[nodo].hijo_izq = expr;
                }
            }
        }
    }
    int _ret_972 = nodo;
    return _ret_972;
}

int parsear_lanzar(struct ParserEst est) {
    int linea;
    int col;
    int nodo;
    int expr;
    if ((token_esperar(est, T_LANZAR) == 0)) {
        int _ret_976 = 0;
        return _ret_976;
    }
    linea = token_linea(est, est.posicion);
    col = token_columna(est, est.posicion);
    nodo = parser_nuevo_nodo(est, NODO_LANZAR, linea, col);
    expr = parsear_expresion(est);
    { /* unsafe */
        est.nodos[nodo].hijo_izq = expr;
    }
    int _ret_983 = nodo;
    return _ret_983;
}

int parsear_escuchar(struct ParserEst est) {
    int linea;
    int col;
    int nodo;
    int expr;
    if ((token_esperar(est, T_ESCUCHAR) == 0)) {
        int _ret_987 = 0;
        return _ret_987;
    }
    linea = token_linea(est, est.posicion);
    col = token_columna(est, est.posicion);
    nodo = parser_nuevo_nodo(est, NODO_ESCUCHAR, linea, col);
    parsear_expresion(est);
    if ((token_esperar(est, T_FLECHA) == 0)) {
        int _ret_993 = 0;
        return _ret_993;
    }
    expr = parsear_expresion(est);
    int _ret_995 = nodo;
    return _ret_995;
}

int parsear_asignacion(struct ParserEst est) {
    int t;
    int linea;
    int col;
    int nodo;
    int expr;
    t = token_mirar(est);
    if ((t != T_IDENTIFICADOR)) {
        int _ret_1000 = 0;
        return _ret_1000;
    }
    linea = token_linea(est, est.posicion);
    col = token_columna(est, est.posicion);
    token_avanzar(est);
    if ((token_esperar(est, T_ASIGNAR) == 0)) {
        int _ret_1005 = 0;
        return _ret_1005;
    }
    nodo = parser_nuevo_nodo(est, NODO_ASIGNACION, linea, col);
    if (((token_mirar(est) == T_IDENTIFICADOR) && (token_tipo(est, (est.posicion + 1)) == T_FLECHA))) {
        expr = parsear_recibir_canal(est);
    }
    else {
        expr = parsear_expresion(est);
    }
    { /* unsafe */
        est.nodos[nodo].hijo_der = expr;
    }
    int _ret_1013 = nodo;
    return _ret_1013;
}

int parsear_estructura_def(struct ParserEst est) {
    int t;
    int linea;
    int col;
    int nodo;
    int r;
    if ((token_esperar(est, T_ESTRUCTURA) == 0)) {
        int _ret_1017 = 0;
        return _ret_1017;
    }
    t = token_mirar(est);
    if ((t != T_IDENTIFICADOR)) {
        int _ret_1020 = 0;
        return _ret_1020;
    }
    linea = token_linea(est, est.posicion);
    col = token_columna(est, est.posicion);
    token_avanzar(est);
    nodo = parser_nuevo_nodo(est, NODO_ESTRUCTURA, linea, col);
    if ((token_esperar(est, T_DOSPUNTOS) == 0)) {
        int _ret_1026 = 0;
        return _ret_1026;
    }
    if ((token_mirar(est) == T_NUEVALINEA)) {
        token_avanzar(est);
        if ((token_mirar(est) == T_INDENTAR)) {
            token_avanzar(est);
            r = 1;
            while ((r == 1)) {
                t = token_mirar(est);
                if ((t == T_NUEVALINEA)) {
                    token_avanzar(est);
                    continue;
                }
                if ((t == T_DESINDENTAR)) {
                    token_avanzar(est);
                    r = 0;
                    break;
                }
                if ((t == T_FIN)) {
                    r = 0;
                    break;
                }
                if ((t == T_IDENTIFICADOR)) {
                    token_avanzar(est);
                    if ((token_esperar(est, T_DOSPUNTOS) == 0)) {
                        int _ret_1047 = 0;
                        return _ret_1047;
                    }
                    if ((token_mirar(est) == T_IDENTIFICADOR)) {
                        token_avanzar(est);
                    }
                }
                continue;
            }
            int _ret_1051 = nodo;
            return _ret_1051;
        }
    }
    int _ret_1052 = nodo;
    return _ret_1052;
}

int parsear_constante(struct ParserEst est) {
    int t;
    int linea;
    int col;
    int nodo;
    int expr;
    if ((token_esperar(est, T_CONSTANTE) == 0)) {
        int _ret_1056 = 0;
        return _ret_1056;
    }
    t = token_mirar(est);
    if ((t != T_IDENTIFICADOR)) {
        int _ret_1059 = 0;
        return _ret_1059;
    }
    linea = token_linea(est, est.posicion);
    col = token_columna(est, est.posicion);
    token_avanzar(est);
    nodo = parser_nuevo_nodo(est, NODO_CONSTANTE, linea, col);
    if ((token_mirar(est) == T_DOSPUNTOS)) {
        token_avanzar(est);
        if ((token_mirar(est) == T_IDENTIFICADOR)) {
            token_avanzar(est);
        }
    }
    if ((token_esperar(est, T_ASIGNAR) == 0)) {
        int _ret_1069 = 0;
        return _ret_1069;
    }
    expr = parsear_expresion(est);
    { /* unsafe */
        est.nodos[nodo].hijo_izq = expr;
    }
    int _ret_1073 = nodo;
    return _ret_1073;
}

int parsear_asm(struct ParserEst est) {
    int linea;
    int col;
    int nodo;
    if ((token_esperar(est, T_ASM) == 0)) {
        int _ret_1077 = 0;
        return _ret_1077;
    }
    linea = token_linea(est, est.posicion);
    col = token_columna(est, est.posicion);
    nodo = parser_nuevo_nodo(est, NODO_ASM, linea, col);
    if ((token_esperar(est, T_PAREN_IZQ) == 0)) {
        int _ret_1082 = 0;
        return _ret_1082;
    }
    if ((token_mirar(est) == T_CADENA)) {
        { /* unsafe */
            est.nodos[nodo].ptr_str = est.tokens[est.posicion].ptr_valor;
            est.nodos[nodo].len_str = est.tokens[est.posicion].len_valor;
        }
        token_avanzar(est);
    }
    if ((token_esperar(est, T_PAREN_DER) == 0)) {
        int _ret_1089 = 0;
        return _ret_1089;
    }
    int _ret_1090 = nodo;
    return _ret_1090;
}

int parsear_inseguro(struct ParserEst est) {
    int linea;
    int col;
    int nodo;
    int r;
    int t;
    int stmt;
    if ((token_esperar(est, T_INSEGURO) == 0)) {
        int _ret_1094 = 0;
        return _ret_1094;
    }
    linea = token_linea(est, est.posicion);
    col = token_columna(est, est.posicion);
    nodo = parser_nuevo_nodo(est, NODO_INSEGURO, linea, col);
    if ((token_esperar(est, T_DOSPUNTOS) == 0)) {
        int _ret_1099 = 0;
        return _ret_1099;
    }
    if ((token_mirar(est) == T_NUEVALINEA)) {
        token_avanzar(est);
        if ((token_mirar(est) == T_INDENTAR)) {
            token_avanzar(est);
            r = 1;
            while ((r == 1)) {
                t = token_mirar(est);
                if ((t == T_NUEVALINEA)) {
                    token_avanzar(est);
                    continue;
                }
                if ((t == T_DESINDENTAR)) {
                    token_avanzar(est);
                    r = 0;
                    break;
                }
                if ((t == T_FIN)) {
                    r = 0;
                    break;
                }
                stmt = parsear_sentencia(est);
                continue;
            }
        }
    }
    int _ret_1119 = nodo;
    return _ret_1119;
}

int parsear_importar_c(struct ParserEst est) {
    int linea;
    int col;
    int nodo;
    if ((token_esperar(est, T_IMPORTAR_C) == 0)) {
        int _ret_1123 = 0;
        return _ret_1123;
    }
    linea = token_linea(est, est.posicion);
    col = token_columna(est, est.posicion);
    nodo = parser_nuevo_nodo(est, NODO_IMPORTAR_C, linea, col);
    if ((token_mirar(est) == T_CADENA)) {
        token_avanzar(est);
    }
    int _ret_1129 = nodo;
    return _ret_1129;
}

int parsear_externo(struct ParserEst est) {
    int t;
    int linea;
    int col;
    int nodo;
    int r;
    if ((token_esperar(est, T_EXTERNO) == 0)) {
        int _ret_1133 = 0;
        return _ret_1133;
    }
    if ((token_esperar(est, T_FUNCION) == 0)) {
        int _ret_1135 = 0;
        return _ret_1135;
    }
    t = token_mirar(est);
    if ((t != T_IDENTIFICADOR)) {
        int _ret_1138 = 0;
        return _ret_1138;
    }
    linea = token_linea(est, est.posicion);
    col = token_columna(est, est.posicion);
    token_avanzar(est);
    nodo = parser_nuevo_nodo(est, NODO_EXTERNO, linea, col);
    if ((token_esperar(est, T_PAREN_IZQ) == 0)) {
        int _ret_1144 = 0;
        return _ret_1144;
    }
    r = 1;
    while ((r == 1)) {
        t = token_mirar(est);
        if ((t == T_PAREN_DER)) {
            r = 0;
            break;
        }
        if ((t == T_IDENTIFICADOR)) {
            token_avanzar(est);
            if ((token_esperar(est, T_DOSPUNTOS) == 0)) {
                int _ret_1154 = 0;
                return _ret_1154;
            }
            if ((token_mirar(est) == T_IDENTIFICADOR)) {
                token_avanzar(est);
            }
            if ((token_mirar(est) == T_POR)) {
                token_avanzar(est);
            }
            if ((token_mirar(est) == T_COMA)) {
                token_avanzar(est);
                continue;
            }
        }
    }
    if ((token_esperar(est, T_PAREN_DER) == 0)) {
        int _ret_1163 = 0;
        return _ret_1163;
    }
    if ((token_esperar(est, T_FLECHA) == 0)) {
        int _ret_1165 = 0;
        return _ret_1165;
    }
    if ((token_mirar(est) == T_IDENTIFICADOR)) {
        token_avanzar(est);
    }
    int _ret_1168 = nodo;
    return _ret_1168;
}

int parsear_coincidir(struct ParserEst est) {
    int linea;
    int col;
    int nodo;
    int expr;
    int r;
    int t;
    int linea_c;
    int col_c;
    int nodo_caso;
    int r2;
    int stmt;
    if ((token_esperar(est, T_COINCIDIR) == 0)) {
        int _ret_1172 = 0;
        return _ret_1172;
    }
    linea = token_linea(est, est.posicion);
    col = token_columna(est, est.posicion);
    nodo = parser_nuevo_nodo(est, NODO_COINCIDIR, linea, col);
    expr = parsear_expresion(est);
    { /* unsafe */
        est.nodos[nodo].hijo_izq = expr;
    }
    if ((token_esperar(est, T_DOSPUNTOS) == 0)) {
        int _ret_1180 = 0;
        return _ret_1180;
    }
    if ((token_mirar(est) == T_NUEVALINEA)) {
        token_avanzar(est);
        if ((token_mirar(est) == T_INDENTAR)) {
            token_avanzar(est);
            r = 1;
            while ((r == 1)) {
                t = token_mirar(est);
                if ((t == T_NUEVALINEA)) {
                    token_avanzar(est);
                    continue;
                }
                if ((t == T_DESINDENTAR)) {
                    token_avanzar(est);
                    r = 0;
                    break;
                }
                if ((t == T_FIN)) {
                    r = 0;
                    break;
                }
                if ((t == T_IDENTIFICADOR)) {
                    linea_c = token_linea(est, est.posicion);
                    col_c = token_columna(est, est.posicion);
                    token_avanzar(est);
                    nodo_caso = parser_nuevo_nodo(est, NODO_CASO, linea_c, col_c);
                    if ((token_mirar(est) == T_PAREN_IZQ)) {
                        token_avanzar(est);
                        if ((token_mirar(est) == T_IDENTIFICADOR)) {
                            token_avanzar(est);
                        }
                        if ((token_esperar(est, T_PAREN_DER) == 0)) {
                            int _ret_1208 = 0;
                            return _ret_1208;
                        }
                    }
                    if ((token_esperar(est, T_FLECHA_DER) == 0)) {
                        int _ret_1210 = 0;
                        return _ret_1210;
                    }
                    r2 = 1;
                    while ((r2 == 1)) {
                        t = token_mirar(est);
                        if ((t == T_NUEVALINEA)) {
                            r2 = 0;
                            break;
                        }
                        if ((t == T_DESINDENTAR)) {
                            r2 = 0;
                            break;
                        }
                        if ((t == T_FIN)) {
                            r2 = 0;
                            break;
                        }
                        stmt = parsear_sentencia(est);
                        continue;
                    }
                }
                continue;
            }
        }
    }
    int _ret_1226 = nodo;
    return _ret_1226;
}

int parsear_enviar_canal(struct ParserEst est) {
    int linea;
    int col;
    int nodo;
    int expr;
    linea = token_linea(est, est.posicion);
    col = token_columna(est, est.posicion);
    nodo = parser_nuevo_nodo(est, NODO_ENVIAR_CANAL, linea, col);
    if ((token_mirar(est) == T_IDENTIFICADOR)) {
        token_avanzar(est);
    }
    if ((token_esperar(est, T_FLECHA_IZQ) == 0)) {
        int _ret_1235 = 0;
        return _ret_1235;
    }
    expr = parsear_expresion(est);
    int _ret_1237 = nodo;
    return _ret_1237;
}

int parsear_crear_canal(struct ParserEst est) {
    int linea;
    int col;
    int nodo;
    int expr;
    if ((token_esperar(est, T_CANAL) == 0)) {
        int _ret_1241 = 0;
        return _ret_1241;
    }
    linea = token_linea(est, est.posicion);
    col = token_columna(est, est.posicion);
    nodo = parser_nuevo_nodo(est, NODO_CANAL_CREAR, linea, col);
    if ((token_esperar(est, T_PAREN_IZQ) == 0)) {
        int _ret_1246 = 0;
        return _ret_1246;
    }
    if ((token_mirar(est) == T_IDENTIFICADOR)) {
        token_avanzar(est);
    }
    if ((token_mirar(est) == T_COMA)) {
        token_avanzar(est);
        expr = parsear_expresion(est);
        { /* unsafe */
            est.nodos[nodo].hijo_izq = expr;
        }
    }
    if ((token_esperar(est, T_PAREN_DER) == 0)) {
        int _ret_1255 = 0;
        return _ret_1255;
    }
    int _ret_1256 = nodo;
    return _ret_1256;
}

int parsear_recibir_canal(struct ParserEst est) {
    int linea;
    int col;
    int nodo;
    linea = token_linea(est, est.posicion);
    col = token_columna(est, est.posicion);
    nodo = parser_nuevo_nodo(est, NODO_RECIBIR_CANAL, linea, col);
    if ((token_mirar(est) == T_IDENTIFICADOR)) {
        token_avanzar(est);
    }
    if ((token_esperar(est, T_FLECHA) == 0)) {
        int _ret_1265 = 0;
        return _ret_1265;
    }
    int _ret_1266 = nodo;
    return _ret_1266;
}

// --- Token IDs ---
#define T_IF 1
#define T_ELSE 2
#define T_FUNC 3
#define T_RET 4
#define T_SPAWN 5
#define T_RECOVER 6
#define T_LISTEN 7
#define T_WHILE 8
#define T_IMPORT 9
#define T_BREAK 49
#define T_CONTINUE 11
#define T_DOT 12
#define T_IDENT 13
#define T_NUM 14
#define T_STR 15
#define T_GT 16
#define T_LT 17
#define T_EQ 25
#define T_NE 26
#define T_LE 27
#define T_GE 28
#define T_ASSIGN 29
#define T_PLUS 30
#define T_MINUS 31
#define T_MUL 32
#define T_DIV 33
#define T_MOD 34
#define T_ARROW 35
#define T_LPAREN 38
#define T_RPAREN 39
#define T_COLON 40
#define T_COMMA 41
#define T_NL 42
#define T_INDENT 43
#define T_DEDENT 44
#define T_EOF 57
#define T_STRUCT 10
#define T_AND 14
#define T_OR 15
#define T_NOT 16
#define T_TRUE 17
#define T_FALSE 18
#define T_INSEGURO 46
#define T_IMPORTAR_C 47
#define T_AMPERSAND 45
#define T_EXTERNO 48

#define MAX_TOKS 65536
typedef struct { int tipo; int linea; int col; char val[256]; } _P_Token;
_P_Token _P_tks[MAX_TOKS];
int _P_ntks = 0, _P_tpos = 0, _P_p_err = 0;
int _P_pila_indent[64], _P_nivel_pila = 0;

void _P_tokenizar(const char* s, int len) {
    int i = 0, li = 1, co = 1;
    while (i < len && _P_ntks < MAX_TOKS - 1) {
        if (_P_ntks >= MAX_TOKS - 1) { fprintf(stderr,"FATAL: MAX_TOKS (%d) superado en tokenizador.\n",MAX_TOKS); exit(1); }
        char c = s[i];
        if (c == ' ' || c == '\t') { i++; co++; continue; }
        if (c == '\r') { i++; continue; }
        if (c == '\n') {
            _P_tks[_P_ntks].tipo = T_NL; _P_tks[_P_ntks].linea = li; _P_tks[_P_ntks].col = 0;
            _P_ntks++; i++; li++; co = 1;
            while (i < len && (s[i]==' '||s[i]=='\t')) { if(s[i]==' ')co++; else co+=4; i++; }
            if (i < len && s[i]=='\n') continue;
            if (i < len && s[i]=='#') { while(i<len&&s[i]!='\n')i++; continue; }
            if (i < len && s[i]=='/' && i+1<len && s[i+1]=='/') { while(i<len&&s[i]!='\n')i++; continue; }
            { int _sp = co-1;
            if (_sp > _P_pila_indent[_P_nivel_pila]) {
                _P_nivel_pila++; _P_pila_indent[_P_nivel_pila] = _sp;
                _P_tks[_P_ntks].tipo = T_INDENT; _P_tks[_P_ntks].linea = li; _P_tks[_P_ntks].col = 0;
                _P_ntks++;
            } else if (_sp < _P_pila_indent[_P_nivel_pila]) {
                while (_P_nivel_pila > 0 && _sp < _P_pila_indent[_P_nivel_pila]) {
                    _P_tks[_P_ntks].tipo = T_DEDENT; _P_tks[_P_ntks].linea = li; _P_tks[_P_ntks].col = 0;
                    _P_ntks++; _P_nivel_pila--;
                }
            } }
            continue;
        }
        if (c == '/' && i+1 < len && s[i+1] == '/') {
            while (i < len && s[i] != '\n') i++; continue;
        }
        if (c == '#') {
            while (i < len && s[i] != '\n') i++; continue;
        }
        if (c == '"' || c == '\'') {
            char q = c; int st = i; int scol = co; i++; co++;
            while (i < len && s[i] != q) { if (s[i] == '\\' && i+1 < len) { i++; co++; } i++; co++; }
            if (i >= len) break;
            i++; co++;
            int _rlen = (i - st - 2) < 255 ? (i - st - 2) : 255;
            char _tmp[256]; strncpy(_tmp, s + st + 1, _rlen); _tmp[_rlen] = 0;
            int _un = 0;
            for (int _si = 0; _tmp[_si] && _un < 254; _si++) {
                if (_tmp[_si] == 92 && _tmp[_si+1]) {
                    switch (_tmp[_si+1]) {
                    case 34: _P_tks[_P_ntks].val[_un++] = 34; _si++; break;
                    case 39: _P_tks[_P_ntks].val[_un++] = 39; _si++; break;
                    case 92: _P_tks[_P_ntks].val[_un++] = 92; _si++; break;
                    case 110: _P_tks[_P_ntks].val[_un++] = 10; _si++; break;
                    case 116: _P_tks[_P_ntks].val[_un++] = 9; _si++; break;
                    case 114: _P_tks[_P_ntks].val[_un++] = 13; _si++; break;
                    case 48: _P_tks[_P_ntks].val[_un++] = 0; _si++; break;
                    default: _P_tks[_P_ntks].val[_un++] = _tmp[_si]; break;
                    }
                } else {
                    _P_tks[_P_ntks].val[_un++] = _tmp[_si];
                }
            }
            _P_tks[_P_ntks].val[_un] = 0;
            _P_tks[_P_ntks].tipo = T_STR; _P_tks[_P_ntks].linea = li; _P_tks[_P_ntks].col = scol;
            _P_ntks++; continue;
        }
        if (c >= '0' && c <= '9') {
            int st = i; int scol = co; while (i < len && s[i] >= '0' && s[i] <= '9') i++;
            if (i < len && s[i] == '.') { i++; while (i < len && s[i] >= '0' && s[i] <= '9') i++; }
            int vl = (i - st) < 255 ? (i - st) : 255;
            strncpy(_P_tks[_P_ntks].val, s + st, vl); _P_tks[_P_ntks].val[vl] = 0;
            _P_tks[_P_ntks].tipo = T_NUM; _P_tks[_P_ntks].linea = li; _P_tks[_P_ntks].col = scol;
            _P_ntks++; co += (i - st); continue;
        }
        if ((c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '_') {
            int st = i; int scol = co;
            while (i < len && ((s[i] >= 'a' && s[i] <= 'z') || (s[i] >= 'A' && s[i] <= 'Z') || (s[i] >= '0' && s[i] <= '9') || s[i] == '_')) i++;
            int vl = (i - st) < 255 ? (i - st) : 255;
            strncpy(_P_tks[_P_ntks].val, s + st, vl); _P_tks[_P_ntks].val[vl] = 0;
            _P_tks[_P_ntks].linea = li; _P_tks[_P_ntks].col = scol;
            typedef struct { const char* p; int t; } _KW;
            const _KW _ks[] = {
                {"si",T_IF},{"if",T_IF},{"se",T_IF},{"wenn",T_IF},
                {"sino",T_ELSE},{"else",T_ELSE},{"sinon",T_ELSE},{"senao",T_ELSE},{"sonst",T_ELSE},{"altrimenti",T_ELSE},
                {"funcion",T_FUNC},{"function",T_FUNC},{"fonction",T_FUNC},{"funcao",T_FUNC},{"funktion",T_FUNC},{"funzione",T_FUNC},
                {"retornar",T_RET},{"return",T_RET},{"retourner",T_RET},{"retornar",T_RET},{"rueckgabe",T_RET},{"restituisci",T_RET},
                {"lanzar",T_SPAWN},{"spawn",T_SPAWN},{"lancer",T_SPAWN},{"lancar",T_SPAWN},{"starten",T_SPAWN},{"lancia",T_SPAWN},
                {"recuperar",T_RECOVER},{"recover",T_RECOVER},{"recuperer",T_RECOVER},{"recuperar",T_RECOVER},{"wiederherstellen",T_RECOVER},{"recupera",T_RECOVER},
                {"escuchar",T_LISTEN},{"listen",T_LISTEN},{"ecouter",T_LISTEN},{"escutar",T_LISTEN},{"hoeren",T_LISTEN},{"ascolta",T_LISTEN},
                {"mientras",T_WHILE},{"while",T_WHILE},{"tantque",T_WHILE},{"enquanto",T_WHILE},{"waehrend",T_WHILE},{"mentre",T_WHILE},
                {"importar",T_IMPORT},{"import",T_IMPORT},{"importer",T_IMPORT},{"importar",T_IMPORT},{"importieren",T_IMPORT},{"importa",T_IMPORT},
                {"romper",T_BREAK},{"break",T_BREAK},{"rompre",T_BREAK},{"parar",T_BREAK},{"abbrechen",T_BREAK},{"interrompi",T_BREAK},
                {"siguiente",T_CONTINUE},{"continue",T_CONTINUE},{"continuer",T_CONTINUE},{"continuar",T_CONTINUE},{"fortsetzen",T_CONTINUE},{"continua",T_CONTINUE},
                {"estructura",T_STRUCT},{"struct",T_STRUCT},{"structure",T_STRUCT},{"estrutura",T_STRUCT},{"struktur",T_STRUCT},{"struttura",T_STRUCT},
                {"y",T_AND},{"and",T_AND},{"et",T_AND},{"e",T_AND},{"und",T_AND},
                {"o",T_OR},{"or",T_OR},{"ou",T_OR},{"oder",T_OR},
                {"no",T_NOT},{"not",T_NOT},{"non",T_NOT},{"nao",T_NOT},{"nicht",T_NOT},
                {"verdadero",T_TRUE},{"true",T_TRUE},{"vrai",T_TRUE},{"verdadeiro",T_TRUE},{"wahr",T_TRUE},{"vero",T_TRUE},
                {"falso",T_FALSE},{"false",T_FALSE},{"faux",T_FALSE},{"falsch",T_FALSE},
                {"inseguro",T_INSEGURO},{"unsafe",T_INSEGURO},
                {"importar_c",T_IMPORTAR_C},{"import_c",T_IMPORTAR_C},{"importer_c",T_IMPORTAR_C},{"importa_c",T_IMPORTAR_C},
                {"externo",T_EXTERNO},{"extern",T_EXTERNO},{"externe",T_EXTERNO},{"esterno",T_EXTERNO},
                {NULL,0}
            };
            int _kt = T_IDENT;
            for (int _ki = 0; _ks[_ki].p; _ki++) {
                if (strcmp(_P_tks[_P_ntks].val, _ks[_ki].p) == 0) { _kt = _ks[_ki].t; break; }
            }
            _P_tks[_P_ntks].tipo = _kt;
            if (li == 72) { fprintf(stderr, "[DEBUG LEXER L72] Texto: '%s' -> ID Asignado: %d\n", _P_tks[_P_ntks].val, _P_tks[_P_ntks].tipo); }
            _P_ntks++; co += (i - st); continue;
        }
        if ((unsigned char)c >= 0x80) { i++; continue; }
        if (i+1 < len) {
            if (c == '-' && s[i+1] == '>') {
                _P_tks[_P_ntks].tipo = T_ARROW; _P_tks[_P_ntks].linea = li; _P_tks[_P_ntks].col = co;
                _P_ntks++; i+=2; co+=2; continue;
            }
            if (c == '=' && s[i+1] == '=') {
                _P_tks[_P_ntks].tipo = T_EQ; _P_tks[_P_ntks].linea = li; _P_tks[_P_ntks].col = co;
                _P_ntks++; i+=2; co+=2; continue;
            }
            if (c == '!' && s[i+1] == '=') {
                _P_tks[_P_ntks].tipo = T_NE; _P_tks[_P_ntks].linea = li; _P_tks[_P_ntks].col = co;
                _P_ntks++; i+=2; co+=2; continue;
            }
            if (c == '<' && s[i+1] == '=') {
                _P_tks[_P_ntks].tipo = T_LE; _P_tks[_P_ntks].linea = li; _P_tks[_P_ntks].col = co;
                _P_ntks++; i+=2; co+=2; continue;
            }
            if (c == '>' && s[i+1] == '=') {
                _P_tks[_P_ntks].tipo = T_GE; _P_tks[_P_ntks].linea = li; _P_tks[_P_ntks].col = co;
                _P_ntks++; i+=2; co+=2; continue;
            }
        }
        {
            int tt = T_EOF;
            if (c == '=') tt = T_ASSIGN;
            else if (c == '+') tt = T_PLUS;
            else if (c == '-') tt = T_MINUS;
            else if (c == '*') tt = T_MUL;
            else if (c == '/') tt = T_DIV;
            else if (c == '%') tt = T_MOD;
            else if (c == '(') tt = T_LPAREN;
            else if (c == ')') tt = T_RPAREN;
            else if (c == ':') tt = T_COLON;
            else if (c == ',') tt = T_COMMA;
            else if (c == '.') tt = T_DOT;
            else if (c == '>') tt = T_GT;
            else if (c == '<') tt = T_LT;
            else if (c == '&') tt = T_AMPERSAND;
            if (tt == T_EOF) { fprintf(stderr,"Error Lexico: caracter inesperado '%%c'(%%d) en linea %%d\n",c,c,li); exit(1); }
            _P_tks[_P_ntks].tipo = tt; _P_tks[_P_ntks].linea = li; _P_tks[_P_ntks].col = co;
            _P_ntks++; i++; co++;
        }
    }
    while (_P_nivel_pila > 0) {
        _P_tks[_P_ntks].tipo = T_DEDENT; _P_tks[_P_ntks].linea = li; _P_tks[_P_ntks].col = 0;
        _P_ntks++; _P_nivel_pila--;
    }
    _P_tks[_P_ntks].tipo = T_EOF; _P_tks[_P_ntks].linea = li; _P_tks[_P_ntks].col = 0;
    _P_ntks++;
}

void _P_procesar_indentacion_final() {
    while (_P_nivel_pila > 0) {
        _P_tks[_P_ntks].tipo = T_DEDENT; _P_tks[_P_ntks].linea = _P_tks[_P_ntks-1].linea; _P_tks[_P_ntks].col = 0;
        _P_ntks++; _P_nivel_pila--;
    }
}

// --- AST builder helpers ---
CadenaSegura _P_cs(const char* s) {
    CadenaSegura c; c.longitud = (int)strlen(s);
    char* d = (char*)malloc(c.longitud + 1); strcpy(d, s); c.datos = d; return c;
}
struct ListaNodo* _P_mk_list(struct Nodo* h, struct ListaNodo* t) {
    struct ListaNodo* n = (struct ListaNodo*)calloc(1,sizeof(struct ListaNodo));
    n->cabeza = h; n->cola = t; return n;
}

_P_Token* _P_mirar() { return &_P_tks[_P_tpos]; }
void _P_avanzar() { if (_P_tpos < _P_ntks) _P_tpos++; }
int _P_posible(int t) { return _P_mirar()->tipo == t ? 1 : 0; }
int _P_esperar(int t) {
    if (_P_mirar()->tipo == t) { _P_avanzar(); return 1; }
    fprintf(stderr, "[PARSER] L%d:%d: esperaba token %d, encontre %d\n",
            _P_mirar()->linea, _P_mirar()->col, t, _P_mirar()->tipo);
    exit(1);
}
void _P_sinc_skip() {
    while (_P_tpos < _P_ntks) {
        int tt = _P_mirar()->tipo;
        if (tt == T_NL || tt == T_DEDENT || tt == T_EOF || tt == T_COMMA || tt == T_RPAREN || tt == T_COLON) break;
        _P_avanzar();
    }
}

// Forward declarations
struct Nodo* _P_expr();
struct Nodo* _P_logica();
struct ListaNodo* _P_bloque();
struct Nodo* _P_sentencia();
struct Nodo* _P_comp();
struct Nodo* _P_suma();
struct Nodo* _P_term();
struct Nodo* _P_una();
struct Nodo* _P_prim();
struct Programa _P_programa();
struct ListaNodo* _P_bloque() {
    if (!_P_esperar(T_NL)) { _P_sinc_skip(); return NULL; }
    while (_P_mirar()->tipo == T_NL) { _P_avanzar(); }
    if (!_P_esperar(T_INDENT)) { _P_sinc_skip(); return NULL; }
    struct ListaNodo* lst = NULL;
    struct ListaNodo** cur = &lst;
    while (_P_mirar()->tipo != T_DEDENT && _P_mirar()->tipo != T_EOF) {
        if (_P_mirar()->tipo == T_NL) { _P_avanzar(); continue; }
        struct Nodo* st=_P_sentencia();
        if (st) { *cur=_P_mk_list(st,NULL); cur=&(*cur)->cola; }
    }
    _P_esperar(T_DEDENT);
    return lst;
}
struct Nodo* _P_sentencia() {
#ifdef SYN_DEBUG_PARSE
    fprintf(stderr, "PARSE S tok=%d pos=%d/%d\n", _P_mirar()->tipo, _P_tpos, _P_ntks);
    fflush(stderr);
#endif
    while (_P_mirar()->tipo == T_NL) { _P_avanzar(); }
_P_retry:;
    _P_Token* t = _P_mirar();
    if (t->tipo == T_FUNC) {
        _P_avanzar();
        if (_P_mirar()->tipo != T_IDENT) { _P_sinc_skip(); return NULL; }
        char _nm[256]; strcpy(_nm, _P_mirar()->val);
        _P_avanzar();
        _P_esperar(T_LPAREN);
        struct ListaNodo* params = NULL;
        struct ListaNodo** pcur = &params;
        if (_P_mirar()->tipo != T_RPAREN) {
            while (1) {
                int is_transfer = 0;
                if (_P_mirar()->tipo == T_ARROW) { is_transfer=1; _P_avanzar(); }
                if (_P_mirar()->tipo != T_IDENT) break;
                char _pn[256]; strcpy(_pn, _P_mirar()->val);
                _P_avanzar();
                _P_esperar(T_COLON);
                if (_P_mirar()->tipo != T_IDENT) break;
                char _pt[256]; strcpy(_pt, _P_mirar()->val);
                _P_avanzar();
                while (_P_mirar()->tipo == T_MUL) { strcat(_pt,"*"); _P_avanzar(); }
                struct Parametro* pp = (struct Parametro*)calloc(1,sizeof(struct Parametro));
                pp->tipo=_P_cs("Parametro");
                pp->nombre=_P_cs(_pn); pp->tipo_param=_P_cs(_pt);
                pp->es_transferencia = is_transfer;
                *pcur=_P_mk_list((struct Nodo*)pp,NULL); pcur=&(*pcur)->cola;
                if (_P_mirar()->tipo != T_COMMA) break;
                _P_avanzar();
            }
        }
        _P_esperar(T_RPAREN); _P_esperar(T_ARROW);
        if (_P_mirar()->tipo != T_IDENT) { _P_sinc_skip(); return NULL; }
        char _rt[256]; strcpy(_rt, _P_mirar()->val);
        _P_avanzar();
        _P_esperar(T_COLON);
        struct ListaNodo* body=_P_bloque();
        struct DefinicionFuncion* n = (struct DefinicionFuncion*)calloc(1,sizeof(struct DefinicionFuncion));
        n->tipo=_P_cs("DefinicionFuncion");
        n->nombre=_P_cs(_nm); n->parametros=(struct ListaParametro*)params;
        n->tipo_retorno=_P_cs(_rt); n->cuerpo=body;
        return (struct Nodo*)n;
    }
    if (t->tipo == T_STRUCT) {
        _P_avanzar();
        if (_P_mirar()->tipo != T_IDENT) { _P_sinc_skip(); return NULL; }
        char _snm[256]; strcpy(_snm, _P_mirar()->val);
        _P_avanzar();
        _P_esperar(T_COLON);
        if (!_P_esperar(T_NL)) { _P_sinc_skip(); return NULL; }
        while (_P_mirar()->tipo == T_NL) { _P_avanzar(); }
        if (!_P_esperar(T_INDENT)) { _P_sinc_skip(); return NULL; }
        struct ListaParametro* campos = NULL;
        struct ListaParametro** ccur = &campos;
        while (_P_mirar()->tipo != T_DEDENT && _P_mirar()->tipo != T_EOF) {
            if (_P_mirar()->tipo == T_NL) { _P_avanzar(); continue; }
            if (_P_mirar()->tipo != T_IDENT) { _P_sinc_skip(); break; }
            char _pn[256]; strcpy(_pn, _P_mirar()->val);
            _P_avanzar();
            _P_esperar(T_COLON);
            if (_P_mirar()->tipo != T_IDENT) { _P_sinc_skip(); break; }
            char _pt[256]; strcpy(_pt, _P_mirar()->val);
            _P_avanzar();
            struct Parametro* pp=(struct Parametro*)calloc(1,sizeof(struct Parametro));
            pp->tipo=_P_cs("Parametro"); pp->nombre=_P_cs(_pn); pp->tipo_param=_P_cs(_pt); pp->es_transferencia=0;
            *ccur=(struct ListaParametro*)_P_mk_list((struct Nodo*)pp,NULL); ccur=&(*ccur)->cola;
        }
        _P_esperar(T_DEDENT);
        struct DefinicionEstructura* n = (struct DefinicionEstructura*)calloc(1,sizeof(struct DefinicionEstructura));
        n->tipo=_P_cs("DefinicionEstructura"); n->nombre=_P_cs(_snm); n->campos=campos;
        return (struct Nodo*)n;
    }
    if (t->tipo == T_IF) {
        _P_avanzar();
        struct Nodo* cond=_P_expr();
        _P_esperar(T_COLON);
        struct ListaNodo* cpo=NULL;
        if (_P_mirar()->tipo == T_NL) {
            cpo=_P_bloque();
        } else {
            struct Nodo* _st=_P_sentencia();
            if (_st) { cpo=_P_mk_list(_st,NULL); }
        }
        struct ListaNodo* sino = NULL;
        if (_P_mirar()->tipo == T_ELSE) { _P_avanzar(); _P_esperar(T_COLON);
            if (_P_mirar()->tipo == T_NL) {
                sino=_P_bloque();
            } else {
                struct Nodo* _st=_P_sentencia();
                if (_st) { sino=_P_mk_list(_st,NULL); }
            }
        }
        struct SentenciaSi* n = (struct SentenciaSi*)calloc(1,sizeof(struct SentenciaSi));
        n->tipo=_P_cs("SentenciaSi"); n->condicion=cond;
        n->cuerpo=cpo; n->cuerpo_sino=sino;
        return (struct Nodo*)n;
    }
    if (t->tipo == T_WHILE) {
        _P_avanzar();
        struct Nodo* cond=_P_expr();
        _P_esperar(T_COLON);
        struct ListaNodo* cpo=NULL;
        if (_P_mirar()->tipo == T_NL) {
            cpo=_P_bloque();
        } else {
            struct Nodo* _st=_P_sentencia();
            if (_st) { cpo=_P_mk_list(_st,NULL); }
        }
        struct SentenciaMientras* n = (struct SentenciaMientras*)calloc(1,sizeof(struct SentenciaMientras));
        n->tipo=_P_cs("SentenciaMientras"); n->condicion=cond; n->cuerpo=cpo;
        return (struct Nodo*)n;
    }
    if (t->tipo == T_RET) {
        _P_avanzar();
        struct Nodo* expr = NULL;
        if (_P_mirar()->tipo == T_ARROW) { _P_avanzar(); expr=_P_expr(); }
        else if (_P_mirar()->tipo != T_NL && _P_mirar()->tipo != T_DEDENT && _P_mirar()->tipo != T_EOF) { expr=_P_expr(); }
        struct SentenciaRetornar* n = (struct SentenciaRetornar*)calloc(1,sizeof(struct SentenciaRetornar));
        n->tipo=_P_cs("SentenciaRetornar"); n->expr=expr;
        return (struct Nodo*)n;
    }
    if (t->tipo == T_SPAWN) { _P_avanzar();
        struct Nodo* ll=_P_expr();
        struct SentenciaLanzar* n = (struct SentenciaLanzar*)calloc(1,sizeof(struct SentenciaLanzar));
        n->tipo=_P_cs("SentenciaLanzar"); n->llamada=ll;
        return (struct Nodo*)n;
    }
    if (t->tipo == T_RECOVER) { _P_avanzar();
        struct Nodo* ac=_P_expr(); _P_esperar(T_COLON);
        struct Nodo* pb=_P_expr();
        struct SentenciaRecuperar* n = (struct SentenciaRecuperar*)calloc(1,sizeof(struct SentenciaRecuperar));
        n->tipo=_P_cs("SentenciaRecuperar"); n->accion_critica=ac; n->plan_b=pb;
        return (struct Nodo*)n;
    }
    if (t->tipo == T_LISTEN) { _P_avanzar();
        struct Nodo* cn=_P_expr(); _P_esperar(T_ARROW);
        struct Nodo* rp=_P_expr();
        struct SentenciaEscuchar* n = (struct SentenciaEscuchar*)calloc(1,sizeof(struct SentenciaEscuchar));
        n->tipo=_P_cs("SentenciaEscuchar"); n->canal=cn; n->respuesta=rp;
        return (struct Nodo*)n;
    }
    if (t->tipo == T_BREAK) { _P_avanzar();
        struct SentenciaRomper* n = (struct SentenciaRomper*)calloc(1,sizeof(struct SentenciaRomper));
        n->tipo=_P_cs("SentenciaRomper");
        return (struct Nodo*)n;
    }
    if (t->tipo == T_CONTINUE) { _P_avanzar();
        struct SentenciaSiguiente* n = (struct SentenciaSiguiente*)calloc(1,sizeof(struct SentenciaSiguiente));
        n->tipo=_P_cs("SentenciaSiguiente");
        return (struct Nodo*)n;
    }
    if (t->tipo == T_IMPORT) { _P_avanzar();
        if (_P_mirar()->tipo != T_IDENT) { _P_sinc_skip(); return NULL; }
        char _imp[256]; strcpy(_imp, _P_mirar()->val); int _iml = (int)strlen(_imp);
        _P_avanzar();
        while (_P_mirar()->tipo == T_DOT) { _P_avanzar(); if (_P_mirar()->tipo != T_IDENT) break; strcat(_imp,"."); strcat(_imp,_P_mirar()->val); _P_avanzar(); }
        struct SentenciaImportar* n = (struct SentenciaImportar*)calloc(1,sizeof(struct SentenciaImportar));
        n->tipo=_P_cs("SentenciaImportar"); n->ruta=_P_cs(_imp);
        return (struct Nodo*)n;
    }
    if (t->tipo == T_IMPORTAR_C) { _P_avanzar();
        if (_P_mirar()->tipo != T_STR) { _P_sinc_skip(); return NULL; }
        char _hc[256]; strcpy(_hc, _P_mirar()->val);
        int _hsys = (_hc[0]=='<' && _hc[strlen(_hc)-1]=='>');
        if(_hsys){{ memmove(_hc,_hc+1,strlen(_hc)-2); _hc[strlen(_hc)-2]=0; }}
        _P_avanzar();
        struct ImportarC* n = (struct ImportarC*)calloc(1,sizeof(struct ImportarC));
        n->tipo=_P_cs("ImportarC"); n->ruta=_P_cs(_hc); n->es_sistema=_hsys;
        return (struct Nodo*)n;
    }
    if (t->tipo == T_EXTERNO) { _P_avanzar();
        if (_P_mirar()->tipo != T_FUNC) { _P_sinc_skip(); return NULL; }
        _P_avanzar();
        if (_P_mirar()->tipo != T_IDENT) { _P_sinc_skip(); return NULL; }
        char _enm[256]; strcpy(_enm, _P_mirar()->val);
        _P_avanzar();
        _P_esperar(T_LPAREN);
        struct ListaParametro* eparams = NULL;
        struct ListaParametro** epcur = &eparams;
        if (_P_mirar()->tipo != T_RPAREN) {
            while (1) {
                if (_P_mirar()->tipo != T_IDENT) break;
                char _epn[256]; strcpy(_epn, _P_mirar()->val);
                _P_avanzar();
                _P_esperar(T_COLON);
                if (_P_mirar()->tipo != T_IDENT) break;
                char _ept[256]; strcpy(_ept, _P_mirar()->val);
                _P_avanzar();
                while (_P_mirar()->tipo == T_MUL) { strcat(_ept,"*"); _P_avanzar(); }
                struct Parametro* epp=(struct Parametro*)calloc(1,sizeof(struct Parametro));
                epp->tipo=_P_cs("Parametro"); epp->nombre=_P_cs(_epn); epp->tipo_param=_P_cs(_ept); epp->es_transferencia=0;
                *epcur=(struct ListaParametro*)_P_mk_list((struct Nodo*)epp,NULL); epcur=&(*epcur)->cola;
                if (_P_mirar()->tipo != T_COMMA) break;
                _P_avanzar();
            }
        }
        _P_esperar(T_RPAREN); _P_esperar(T_ARROW);
        if (_P_mirar()->tipo != T_IDENT) { _P_sinc_skip(); return NULL; }
        char _ert[256]; strcpy(_ert, _P_mirar()->val);
        _P_avanzar();
        struct DeclaracionExterna* n = (struct DeclaracionExterna*)calloc(1,sizeof(struct DeclaracionExterna));
        n->tipo=_P_cs("DeclaracionExterna"); n->nombre=_P_cs(_enm);
        n->parametros=eparams; n->tipo_retorno=_P_cs(_ert);
        return (struct Nodo*)n;
    }
    if (t->tipo == T_INSEGURO) { _P_avanzar();
        _P_esperar(T_COLON);
        struct ListaNodo* cpo=NULL;
        if (_P_mirar()->tipo == T_NL) {
            cpo=_P_bloque();
        } else {
            struct Nodo* _st=_P_sentencia();
            if (_st) { cpo=_P_mk_list(_st,NULL); }
        }
        struct BloqueInseguro* n = (struct BloqueInseguro*)calloc(1,sizeof(struct BloqueInseguro));
        n->tipo=_P_cs("BloqueInseguro"); n->cuerpo=cpo;
        return (struct Nodo*)n;
    }
    if (t->tipo == T_IDENT && _P_tpos + 1 < _P_ntks && _P_tks[_P_tpos + 1].tipo == T_ASSIGN) {
        char _vn[256]; strcpy(_vn, t->val);
        _P_avanzar(); _P_avanzar();
        struct Nodo* val=_P_expr();
        struct AsignacionVariable* n = (struct AsignacionVariable*)calloc(1,sizeof(struct AsignacionVariable));
        n->tipo=_P_cs("AsignacionVariable");
        n->nombre=_P_cs(_vn); n->expresion=val;
        return (struct Nodo*)n;
    }
    // Guard: skip stray INDENT/DEDENT/NL and retry keyword matching
    if (_P_mirar()->tipo == T_INDENT || _P_mirar()->tipo == T_DEDENT || _P_mirar()->tipo == T_NL) {
        _P_avanzar();
        goto _P_retry;
    }
    if (_P_mirar()->tipo == T_EOF) { return NULL; }
    { struct Nodo* e=_P_expr();
        if (e && _P_mirar()->tipo == T_ASSIGN) {
            _P_avanzar();
            struct Nodo* val=_P_expr();
            if (strcmp(e->tipo.datos,"Identificador")==0) {
                struct AsignacionVariable* n = (struct AsignacionVariable*)calloc(1,sizeof(struct AsignacionVariable));
                n->tipo=_P_cs("AsignacionVariable");
                n->nombre=((struct Identificador*)e)->nombre; n->expresion=val;
                return (struct Nodo*)n;
            }
            if (strcmp(e->tipo.datos,"ExprAccesoCampo")==0) {
                struct AsignacionCampo* n = (struct AsignacionCampo*)calloc(1,sizeof(struct AsignacionCampo));
                n->tipo=_P_cs("AsignacionCampo");
                n->objeto=((struct ExprAccesoCampo*)e)->objeto; n->nombre_campo=((struct ExprAccesoCampo*)e)->nombre_campo; n->expresion=val;
                return (struct Nodo*)n;
            }
        }
        struct SentenciaExpr* n = (struct SentenciaExpr*)calloc(1,sizeof(struct SentenciaExpr));
        n->tipo=_P_cs("SentenciaExpr"); n->expr=e;
        return (struct Nodo*)n;
    }
}
struct Nodo* _P_expr() { return _P_logica(); }

struct Nodo* _P_logica() {
    struct Nodo* izq=_P_comp();
    while (1) {
        int tt=_P_mirar()->tipo;
        if (tt!=T_AND&&tt!=T_OR) break;
        _P_avanzar();
        struct Nodo* der=_P_comp();
        struct OpBinaria* n=(struct OpBinaria*)calloc(1,sizeof(struct OpBinaria));
        n->tipo=_P_cs("OpBinaria"); n->izquierdo=izq; n->derecho=der;
        n->operador=(struct Token*)calloc(1,sizeof(struct Token)); n->operador->tipo=tt; n->operador->linea=0; n->operador->columna=0;
        n->operador->lexema=_P_cs(tt==T_AND?"&&":"||");
        izq=(struct Nodo*)n;
    }
    return izq;
}

struct Nodo* _P_comp() {
    struct Nodo* izq=_P_suma();
    while (1) {
        int tt=_P_mirar()->tipo;
        if (tt!=T_EQ&&tt!=T_NE&&tt!=T_LT&&tt!=T_GT&&tt!=T_LE&&tt!=T_GE) break;
        _P_avanzar();
        struct Nodo* der=_P_suma();
        struct OpBinaria* n=(struct OpBinaria*)calloc(1,sizeof(struct OpBinaria));
        n->tipo=_P_cs("OpBinaria"); n->izquierdo=izq; n->derecho=der;
        n->operador=(struct Token*)calloc(1,sizeof(struct Token)); n->operador->tipo=tt; n->operador->linea=0; n->operador->columna=0;
        {char _b[4]={0,0,0,0};if(tt==T_EQ){_b[0]='=';_b[1]='=';}
        else if(tt==T_NE){_b[0]='!';_b[1]='=';}
        else if(tt==T_LE){_b[0]='<';_b[1]='=';}
        else if(tt==T_GE){_b[0]='>';_b[1]='=';}
        else if(tt==T_LT){_b[0]='<';}else{_b[0]='>';}
        n->operador->lexema=_P_cs(_b);}
        izq=(struct Nodo*)n;
    }
    return izq;
}
struct Nodo* _P_suma() {
    struct Nodo* izq=_P_term();
    while (_P_mirar()->tipo==T_PLUS||_P_mirar()->tipo==T_MINUS) {
        int tt=_P_mirar()->tipo; _P_avanzar();
        struct Nodo* der=_P_term();
        struct OpBinaria* n=(struct OpBinaria*)calloc(1,sizeof(struct OpBinaria));
        n->tipo=_P_cs("OpBinaria"); n->izquierdo=izq; n->derecho=der;
        n->operador=(struct Token*)calloc(1,sizeof(struct Token)); n->operador->tipo=tt; n->operador->linea=0; n->operador->columna=0;
        n->operador->lexema=_P_cs(tt==T_PLUS?"+":"-");
        izq=(struct Nodo*)n;
    }
    return izq;
}
struct Nodo* _P_term() {
    struct Nodo* izq=_P_una();
    while (_P_mirar()->tipo==T_MUL||_P_mirar()->tipo==T_DIV||_P_mirar()->tipo==T_MOD) {
        int tt=_P_mirar()->tipo; _P_avanzar();
        struct Nodo* der=_P_una();
        struct OpBinaria* n=(struct OpBinaria*)calloc(1,sizeof(struct OpBinaria));
        n->tipo=_P_cs("OpBinaria"); n->izquierdo=izq; n->derecho=der;
        n->operador=(struct Token*)calloc(1,sizeof(struct Token)); n->operador->tipo=tt; n->operador->linea=0; n->operador->columna=0;
        n->operador->lexema=_P_cs(tt==T_MUL?"*":tt==T_DIV?"/":"%");
        izq=(struct Nodo*)n;
    }
    return izq;
}
struct Nodo* _P_una() {
    if (_P_mirar()->tipo==T_MINUS||_P_mirar()->tipo==T_PLUS) {
        int tt=_P_mirar()->tipo; _P_avanzar();
        struct Nodo* e=_P_una();
        struct OpUnaria* n=(struct OpUnaria*)calloc(1,sizeof(struct OpUnaria));
        n->tipo=_P_cs("OpUnaria"); n->expr=e;
        n->operador=(struct Token*)calloc(1,sizeof(struct Token)); n->operador->tipo=tt; n->operador->linea=0; n->operador->columna=0;
        n->operador->lexema=_P_cs(tt==T_PLUS?"+":"-");
        return (struct Nodo*)n;
    }
    if (_P_mirar()->tipo==T_NOT) {
        int tt=_P_mirar()->tipo; _P_avanzar();
        struct Nodo* e=_P_una();
        struct OpUnaria* n=(struct OpUnaria*)calloc(1,sizeof(struct OpUnaria));
        n->tipo=_P_cs("OpUnaria"); n->expr=e;
        n->operador=(struct Token*)calloc(1,sizeof(struct Token)); n->operador->tipo=tt; n->operador->linea=0; n->operador->columna=0;
        n->operador->lexema=_P_cs("!");
        return (struct Nodo*)n;
    }
    if (_P_mirar()->tipo==T_AMPERSAND) {
        _P_avanzar();
        struct Nodo* e=_P_una();
        struct ExprObtenerDireccion* n=(struct ExprObtenerDireccion*)calloc(1,sizeof(struct ExprObtenerDireccion));
        n->tipo=_P_cs("ExprObtenerDireccion"); n->expr=e;
        return (struct Nodo*)n;
    }
    if (_P_mirar()->tipo==T_MUL) {
        _P_avanzar();
        struct Nodo* e=_P_una();
        struct ExprDereferencia* n=(struct ExprDereferencia*)calloc(1,sizeof(struct ExprDereferencia));
        n->tipo=_P_cs("ExprDereferencia"); n->expr=e;
        return (struct Nodo*)n;
    }
    return _P_prim();
}
struct Nodo* _P_prim() {
    _P_Token* t=_P_mirar();
    if (t->tipo==T_NUM) {
        struct LiteralNumero* n=(struct LiteralNumero*)calloc(1,sizeof(struct LiteralNumero));
        n->tipo=_P_cs("LiteralNumero"); n->valor=atoi(t->val);
        _P_avanzar(); return (struct Nodo*)n;
    }
    if (t->tipo==T_STR) {
        struct LiteralCadena* n=(struct LiteralCadena*)calloc(1,sizeof(struct LiteralCadena));
        n->tipo=_P_cs("LiteralCadena"); n->valor=_P_cs(t->val);
        _P_avanzar(); return (struct Nodo*)n;
    }
    if (t->tipo==T_TRUE) {
        _P_avanzar();
        struct LiteralNumero* n=(struct LiteralNumero*)calloc(1,sizeof(struct LiteralNumero));
        n->tipo=_P_cs("LiteralNumero"); n->valor=1;
        return (struct Nodo*)n;
    }
    if (t->tipo==T_FALSE) {
        _P_avanzar();
        struct LiteralNumero* n=(struct LiteralNumero*)calloc(1,sizeof(struct LiteralNumero));
        n->tipo=_P_cs("LiteralNumero"); n->valor=0;
        return (struct Nodo*)n;
    }
    if (t->tipo==T_IDENT) {
        char _nm[256]; strcpy(_nm, t->val);
        _P_avanzar();
        if (_P_mirar()->tipo==T_LPAREN) {
            _P_avanzar();
            struct ListaNodo* args=NULL; struct ListaNodo** acur=&args;
            if (_P_mirar()->tipo!=T_RPAREN) {
                while (1) {
                    if (_P_mirar()->tipo==T_ARROW) {
                        _P_avanzar();
                        struct Nodo* ae=_P_expr();
                        struct ArgumentoTransferido* at=(struct ArgumentoTransferido*)calloc(1,sizeof(struct ArgumentoTransferido));
                        at->tipo=_P_cs("ArgumentoTransferido"); at->expr=ae;
                        *acur=_P_mk_list((struct Nodo*)at,NULL);
                    } else { *acur=_P_mk_list(_P_expr(),NULL); }
                    acur=&(*acur)->cola;
                    if (_P_mirar()->tipo!=T_COMMA) break;
                    _P_avanzar();
                }
            }
            _P_esperar(T_RPAREN);
            if(strcmp(_nm,"log")==0) {
                struct LogLlamada* n=(struct LogLlamada*)calloc(1,sizeof(struct LogLlamada));
                n->tipo=_P_cs("LogLlamada"); n->argumentos=args;
                return (struct Nodo*)n;
            }
            struct LlamadaFuncion* n=(struct LlamadaFuncion*)calloc(1,sizeof(struct LlamadaFuncion));
            n->tipo=_P_cs("LlamadaFuncion"); n->nombre=_P_cs(_nm); n->argumentos=args;
            return (struct Nodo*)n;
        }
        if (_P_mirar()->tipo==T_DOT) {
            /* Build chain: a.b.c -> ExprAccesoCampo(ExprAccesoCampo(Ident("a"), "b"), "c") */
            struct Nodo* prev=(struct Nodo*)NULL;
            while (_P_mirar()->tipo==T_DOT) {
                _P_avanzar();
                if (_P_mirar()->tipo!=T_IDENT) break;
                if (!prev) {
                    struct Identificador* obj=(struct Identificador*)calloc(1,sizeof(struct Identificador));
                    obj->tipo=_P_cs("Identificador"); obj->nombre=_P_cs(_nm);
                    prev=(struct Nodo*)obj;
                }
                strcpy(_nm, _P_mirar()->val); _P_avanzar();
                if (_P_mirar()->tipo==T_LPAREN && _P_tpos + 1 < _P_ntks && _P_tks[_P_tpos + 1].tipo!=T_DOT) {
                    /* method call on last segment */
                    if(prev) free(prev);
                    _P_avanzar();
                    struct ListaNodo* args=NULL; struct ListaNodo** acur=&args;
                    if (_P_mirar()->tipo!=T_RPAREN) {
                        while (1) {
                            if (_P_mirar()->tipo==T_ARROW) {
                                _P_avanzar();
                                struct Nodo* ae=_P_expr();
                                struct ArgumentoTransferido* at=(struct ArgumentoTransferido*)calloc(1,sizeof(struct ArgumentoTransferido));
                                at->tipo=_P_cs("ArgumentoTransferido"); at->expr=ae;
                                *acur=_P_mk_list((struct Nodo*)at,NULL);
                            } else { *acur=_P_mk_list(_P_expr(),NULL); }
                            acur=&(*acur)->cola;
                            if (_P_mirar()->tipo!=T_COMMA) break;
                            _P_avanzar();
                        }
                    }
                    _P_esperar(T_RPAREN);
                    struct LlamadaFuncion* n=(struct LlamadaFuncion*)calloc(1,sizeof(struct LlamadaFuncion));
                    n->tipo=_P_cs("LlamadaFuncion"); n->nombre=_P_cs(_nm); n->argumentos=args;
                    return (struct Nodo*)n;
                }
                struct ExprAccesoCampo* ac=(struct ExprAccesoCampo*)calloc(1,sizeof(struct ExprAccesoCampo));
                ac->tipo=_P_cs("ExprAccesoCampo"); ac->objeto=prev; ac->nombre_campo=_P_cs(_nm);
                prev=(struct Nodo*)ac;
                if (_P_mirar()->tipo!=T_DOT) break;
            }
            return prev;
        }
        struct Identificador* n=(struct Identificador*)calloc(1,sizeof(struct Identificador));
        n->tipo=_P_cs("Identificador"); n->nombre=_P_cs(_nm);
        return (struct Nodo*)n;
    }
    if (t->tipo==T_LPAREN) { _P_avanzar(); struct Nodo* e=_P_expr(); _P_esperar(T_RPAREN); return e; }
    fprintf(stderr,"[PARSER] L%d:%d: expresion inesperada token=%d\n",t->linea,t->col,t->tipo);
    exit(1);
}
struct Programa _P_programa() {
    struct ListaNodo* lst=NULL; struct ListaNodo** cur=&lst;
    while (_P_mirar()->tipo!=T_EOF) {
        if (_P_mirar()->tipo==T_NL||_P_mirar()->tipo==T_DEDENT) { _P_avanzar(); continue; }
        struct Nodo* st=_P_sentencia();
        if (st) { *cur=_P_mk_list(st,NULL); cur=&(*cur)->cola; }
    }
    struct Programa p; memset(&p,0,sizeof(p));
    p.tipo=_P_cs("Programa"); p.sentencias=lst;
    return p;
}
struct Programa parsear(CadenaSegura fuente) {
    _P_ntks = 0; _P_tpos = 0; _P_p_err = 0; _P_nivel_pila = 0;
    _P_pila_indent[0] = 0;
    _P_tokenizar(fuente.datos, fuente.longitud);
    _P_procesar_indentacion_final();
    struct Programa _prog = _P_programa();
    return _prog;
}

#define PROPIEDAD_VIVO (1)
#define PROPIEDAD_MOVIDO (2)
void sem_error(struct AnalizadorSemanticoEst est, int codigo, int idx_nodo, CadenaSegura mensaje) {
    int linea;
    int columna;
    linea = 0;
    columna = 0;
    { /* unsafe */
        linea = (idx_nodo >= 0 && idx_nodo < est.total_nodos) ? est.nodos[idx_nodo].linea : 0;
        columna = (idx_nodo >= 0 && idx_nodo < est.total_nodos) ? est.nodos[idx_nodo].columna : 0;
    }
    est.hay_error = 1;
    { /* unsafe */
        // sem_error: reportado;
    }
}

int tabla_declarar(struct AnalizadorSemanticoEst est, CadenaSegura nombre, CadenaSegura tipo, int idx_nodo, int es_constante) {
    int linea;
    int columna;
    int i;
    int encontrado;
    int r;
    linea = 0;
    columna = 0;
    { /* unsafe */
        linea = (idx_nodo >= 0) ? est.nodos[idx_nodo].linea : 0;
        columna = (idx_nodo >= 0) ? est.nodos[idx_nodo].columna : 0;
    }
    i = 0;
    encontrado = 0;
    r = 1;
    while ((r == 1)) {
        { /* unsafe */
            r = (i < est.tabla->total_entradas) ? 1 : 0;
            if ((r == 0)) {
                break;
            }
            if (est.tabla->entradas[i].nivel_ambito == est.tabla->nivel_actual) {
                int _eq = 1;
                for (int _si = 0; _si < 256; _si++) { if (((const char*)nombre.datos)[_si] != ((const char*)est.tabla->entradas[i].nombre.datos)[_si]) { _eq = 0; break; } if (((const char*)nombre.datos)[_si] == 0) break; }
                if (_eq) { encontrado = verdadero; }
            }
            i = i + 1;
        }
    }
    if ((encontrado == 1)) {
        int _ret_153 = 0;
        return _ret_153;
    }
    { /* unsafe */
        est.tabla->entradas[est.tabla->total_entradas].nombre = nombre;
        est.tabla->entradas[est.tabla->total_entradas].tipo = tipo;
        est.tabla->entradas[est.tabla->total_entradas].nivel_ambito = est.tabla->nivel_actual;
        est.tabla->entradas[est.tabla->total_entradas].propiedad = 1;
        est.tabla->entradas[est.tabla->total_entradas].es_constante = es_constante;
        est.tabla->entradas[est.tabla->total_entradas].linea = linea;
        est.tabla->entradas[est.tabla->total_entradas].columna = columna;
        est.tabla->total_entradas = est.tabla->total_entradas + 1;
    }
    int _ret_164 = 1;
    return _ret_164;
}

int tabla_buscar(struct AnalizadorSemanticoEst est, CadenaSegura nombre) {
    int i;
    int r;
    i = 0;
    r = 1;
    while ((r == 1)) {
        { /* unsafe */
            r = (i < est.tabla->total_entradas) ? 1 : 0;
            if ((r == 0)) {
                break;
            }
            int _eq = 1;
            for (int _si = 0; _si < 256; _si++) {
                char _a = nombre.datos[_si];
                char _b = est.tabla->entradas[i].nombre.datos[_si];
                if (_a != _b) { _eq = 0; break; }
                if (_a == 0) break;
            }
            if (_eq) { return i; }
            i = i + 1;
        }
    }
    int _ret_183 = (-1);
    return _ret_183;
}

void tabla_entrar_scope(struct AnalizadorSemanticoEst est) {
    { /* unsafe */
        est.tabla->nivel_actual = est.tabla->nivel_actual + 1;
    }
}

void tabla_salir_scope(struct AnalizadorSemanticoEst est) {
    { /* unsafe */
        while (est.tabla->total_entradas > 0) {
            if (est.tabla->entradas[est.tabla->total_entradas - 1].nivel_ambito < est.tabla->nivel_actual) break;
            est.tabla->total_entradas = est.tabla->total_entradas - 1;
        }
        est.tabla->nivel_actual = est.tabla->nivel_actual - 1;
    }
}

void tabla_marcar_movido(struct AnalizadorSemanticoEst est, CadenaSegura nombre) {
    int idx;
    idx = tabla_buscar(est, nombre);
    if ((idx >= 0)) {
        { /* unsafe */
            est.tabla->entradas[idx].propiedad = 2;
        }
    }
}

int tabla_esta_movido(struct AnalizadorSemanticoEst est, CadenaSegura nombre) {
    int idx;
    int r;
    idx = tabla_buscar(est, nombre);
    if ((idx >= 0)) {
        r = 0;
        { /* unsafe */
            r = (est.tabla->entradas[idx].propiedad == 2) ? 1 : 0;
        }
        if ((r == 1)) {
            int _ret_210 = 1;
            return _ret_210;
        }
    }
    int _ret_211 = 0;
    return _ret_211;
}

CadenaSegura tipo_normalizado(CadenaSegura tipo) {
    if (((str_eq(tipo, (CadenaSegura){ .longitud = (int)strlen("entero"), .datos = "entero" }) == 1) || (str_eq(tipo, (CadenaSegura){ .longitud = (int)strlen("int"), .datos = "int" }) == 1))) {
        CadenaSegura _ret_216 = (CadenaSegura){ .longitud = (int)strlen("int"), .datos = "int" };
        return _ret_216;
    }
    if ((((str_eq(tipo, (CadenaSegura){ .longitud = (int)strlen("decimal"), .datos = "decimal" }) == 1) || (str_eq(tipo, (CadenaSegura){ .longitud = (int)strlen("real"), .datos = "real" }) == 1)) || (str_eq(tipo, (CadenaSegura){ .longitud = (int)strlen("flotante"), .datos = "flotante" }) == 1))) {
        CadenaSegura _ret_218 = (CadenaSegura){ .longitud = (int)strlen("decimal"), .datos = "decimal" };
        return _ret_218;
    }
    if (((str_eq(tipo, (CadenaSegura){ .longitud = (int)strlen("booleano"), .datos = "booleano" }) == 1) || (str_eq(tipo, (CadenaSegura){ .longitud = (int)strlen("logico"), .datos = "logico" }) == 1))) {
        CadenaSegura _ret_220 = (CadenaSegura){ .longitud = (int)strlen("booleano"), .datos = "booleano" };
        return _ret_220;
    }
    if (((str_eq(tipo, (CadenaSegura){ .longitud = (int)strlen("texto"), .datos = "texto" }) == 1) || (str_eq(tipo, (CadenaSegura){ .longitud = (int)strlen("cadena"), .datos = "cadena" }) == 1))) {
        CadenaSegura _ret_222 = (CadenaSegura){ .longitud = (int)strlen("texto"), .datos = "texto" };
        return _ret_222;
    }
    if (((str_eq(tipo, (CadenaSegura){ .longitud = (int)strlen("nulo"), .datos = "nulo" }) == 1) || (str_eq(tipo, (CadenaSegura){ .longitud = (int)strlen("vacio"), .datos = "vacio" }) == 1))) {
        CadenaSegura _ret_224 = (CadenaSegura){ .longitud = (int)strlen("nulo"), .datos = "nulo" };
        return _ret_224;
    }
    if ((str_eq(tipo, (CadenaSegura){ .longitud = (int)strlen("tensor"), .datos = "tensor" }) == 1)) {
        CadenaSegura _ret_226 = (CadenaSegura){ .longitud = (int)strlen("tensor"), .datos = "tensor" };
        return _ret_226;
    }
    if ((str_eq(tipo, (CadenaSegura){ .longitud = (int)strlen("CanalConcurrencia*"), .datos = "CanalConcurrencia*" }) == 1)) {
        CadenaSegura _ret_228 = (CadenaSegura){ .longitud = (int)strlen("CanalConcurrencia*"), .datos = "CanalConcurrencia*" };
        return _ret_228;
    }
    CadenaSegura _ret_229 = tipo;
    return _ret_229;
}

int es_builtin(CadenaSegura nombre) {
    { /* unsafe */
        if (strcmp(nombre.datos, "reserva") == 0) { return verdadero; }
        if (strcmp(nombre.datos, "libera") == 0) { return verdadero; }
        if (strcmp(nombre.datos, "crear_tensor") == 0) { return verdadero; }
        if (strcmp(nombre.datos, "suma_tensor") == 0) { return verdadero; }
        if (strcmp(nombre.datos, "producto_punto") == 0) { return verdadero; }
        if (strcmp(nombre.datos, "abrir") == 0) { return verdadero; }
        if (strcmp(nombre.datos, "leer") == 0) { return verdadero; }
        if (strcmp(nombre.datos, "escribir") == 0) { return verdadero; }
        if (strcmp(nombre.datos, "escribir_linea") == 0) { return verdadero; }
        if (strcmp(nombre.datos, "leer_linea") == 0) { return verdadero; }
        if (strcmp(nombre.datos, "cerrar") == 0) { return verdadero; }
        if (strcmp(nombre.datos, "suma") == 0) { return verdadero; }
        if (strcmp(nombre.datos, "producto") == 0) { return verdadero; }
        if (strcmp(nombre.datos, "relu") == 0) { return verdadero; }
        if (strcmp(nombre.datos, "tokenizar") == 0) { return verdadero; }
        if (strcmp(nombre.datos, "parsear") == 0) { return verdadero; }
        if (strcmp(nombre.datos, "generar") == 0) { return verdadero; }
        if (strcmp(nombre.datos, "_argc") == 0) { return verdadero; }
        if (strcmp(nombre.datos, "_argv") == 0) { return verdadero; }
        if (strcmp(nombre.datos, "salir") == 0) { return verdadero; }
        if (strcmp(nombre.datos, "concat") == 0) { return verdadero; }
        if (strcmp(nombre.datos, "texto_a_entero") == 0) { return verdadero; }
        if (strcmp(nombre.datos, "texto_a_decimal") == 0) { return verdadero; }
        if (strcmp(nombre.datos, "entero_a_texto") == 0) { return verdadero; }
        if (strcmp(nombre.datos, "decimal_a_texto") == 0) { return verdadero; }
        if (strcmp(nombre.datos, "volcar_ast") == 0) { return verdadero; }
        if (strcmp(nombre.datos, "canal_crear") == 0) { return verdadero; }
        if (strcmp(nombre.datos, "canal_enviar") == 0) { return verdadero; }
        if (strcmp(nombre.datos, "canal_recibir") == 0) { return verdadero; }
        if (strcmp(nombre.datos, "cerrar_canal") == 0) { return verdadero; }
    }
    int _ret_264 = 0;
    return _ret_264;
}

int builtin_cantidad_args(CadenaSegura nombre) {
    { /* unsafe */
        if (strcmp(nombre.datos, "reserva") == 0) { return 1; }
        if (strcmp(nombre.datos, "libera") == 0) { return 1; }
        if (strcmp(nombre.datos, "crear_tensor") == 0) { return 2; }
        if (strcmp(nombre.datos, "suma_tensor") == 0) { return 2; }
        if (strcmp(nombre.datos, "producto_punto") == 0) { return 2; }
        if (strcmp(nombre.datos, "abrir") == 0) { return 2; }
        if (strcmp(nombre.datos, "leer") == 0) { return 1; }
        if (strcmp(nombre.datos, "escribir") == 0) { return 1; }
        if (strcmp(nombre.datos, "escribir_linea") == 0) { return 1; }
        if (strcmp(nombre.datos, "leer_linea") == 0) { return 0; }
        if (strcmp(nombre.datos, "cerrar") == 0) { return 1; }
        if (strcmp(nombre.datos, "suma") == 0) { return 2; }
        if (strcmp(nombre.datos, "producto") == 0) { return 2; }
        if (strcmp(nombre.datos, "relu") == 0) { return 1; }
        if (strcmp(nombre.datos, "tokenizar") == 0) { return 1; }
        if (strcmp(nombre.datos, "parsear") == 0) { return 1; }
        if (strcmp(nombre.datos, "generar") == 0) { return 2; }
        if (strcmp(nombre.datos, "_argc") == 0) { return 0; }
        if (strcmp(nombre.datos, "_argv") == 0) { return 1; }
        if (strcmp(nombre.datos, "salir") == 0) { return 1; }
        if (strcmp(nombre.datos, "concat") == 0) { return 2; }
        if (strcmp(nombre.datos, "texto_a_entero") == 0) { return 1; }
        if (strcmp(nombre.datos, "texto_a_decimal") == 0) { return 1; }
        if (strcmp(nombre.datos, "entero_a_texto") == 0) { return 1; }
        if (strcmp(nombre.datos, "decimal_a_texto") == 0) { return 1; }
        if (strcmp(nombre.datos, "volcar_ast") == 0) { return 2; }
        if (strcmp(nombre.datos, "canal_crear") == 0) { return 1; }
        if (strcmp(nombre.datos, "canal_enviar") == 0) { return 2; }
        if (strcmp(nombre.datos, "canal_recibir") == 0) { return 1; }
        if (strcmp(nombre.datos, "cerrar_canal") == 0) { return 1; }
    }
    int _ret_298 = 0;
    return _ret_298;
}

CadenaSegura builtin_tipo_retorno(CadenaSegura nombre) {
    if ((str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("reserva"), .datos = "reserva" }) == 1)) {
        CadenaSegura _ret_301 = (CadenaSegura){ .longitud = (int)strlen("tensor"), .datos = "tensor" };
        return _ret_301;
    }
    if ((str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("libera"), .datos = "libera" }) == 1)) {
        CadenaSegura _ret_302 = (CadenaSegura){ .longitud = (int)strlen("nulo"), .datos = "nulo" };
        return _ret_302;
    }
    if ((str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("crear_tensor"), .datos = "crear_tensor" }) == 1)) {
        CadenaSegura _ret_303 = (CadenaSegura){ .longitud = (int)strlen("tensor"), .datos = "tensor" };
        return _ret_303;
    }
    if ((str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("suma_tensor"), .datos = "suma_tensor" }) == 1)) {
        CadenaSegura _ret_304 = (CadenaSegura){ .longitud = (int)strlen("tensor"), .datos = "tensor" };
        return _ret_304;
    }
    if ((str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("producto_punto"), .datos = "producto_punto" }) == 1)) {
        CadenaSegura _ret_305 = (CadenaSegura){ .longitud = (int)strlen("tensor"), .datos = "tensor" };
        return _ret_305;
    }
    if ((str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("abrir"), .datos = "abrir" }) == 1)) {
        CadenaSegura _ret_306 = (CadenaSegura){ .longitud = (int)strlen("Canal"), .datos = "Canal" };
        return _ret_306;
    }
    if ((str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("leer"), .datos = "leer" }) == 1)) {
        CadenaSegura _ret_307 = (CadenaSegura){ .longitud = (int)strlen("texto"), .datos = "texto" };
        return _ret_307;
    }
    if ((str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("escribir"), .datos = "escribir" }) == 1)) {
        CadenaSegura _ret_308 = (CadenaSegura){ .longitud = (int)strlen("nulo"), .datos = "nulo" };
        return _ret_308;
    }
    if ((str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("escribir_linea"), .datos = "escribir_linea" }) == 1)) {
        CadenaSegura _ret_309 = (CadenaSegura){ .longitud = (int)strlen("nulo"), .datos = "nulo" };
        return _ret_309;
    }
    if ((str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("leer_linea"), .datos = "leer_linea" }) == 1)) {
        CadenaSegura _ret_310 = (CadenaSegura){ .longitud = (int)strlen("texto"), .datos = "texto" };
        return _ret_310;
    }
    if ((str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("cerrar"), .datos = "cerrar" }) == 1)) {
        CadenaSegura _ret_311 = (CadenaSegura){ .longitud = (int)strlen("nulo"), .datos = "nulo" };
        return _ret_311;
    }
    if ((str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("suma"), .datos = "suma" }) == 1)) {
        CadenaSegura _ret_312 = (CadenaSegura){ .longitud = (int)strlen("tensor"), .datos = "tensor" };
        return _ret_312;
    }
    if ((str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("producto"), .datos = "producto" }) == 1)) {
        CadenaSegura _ret_313 = (CadenaSegura){ .longitud = (int)strlen("tensor"), .datos = "tensor" };
        return _ret_313;
    }
    if ((str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("relu"), .datos = "relu" }) == 1)) {
        CadenaSegura _ret_314 = (CadenaSegura){ .longitud = (int)strlen("tensor"), .datos = "tensor" };
        return _ret_314;
    }
    if ((str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("tokenizar"), .datos = "tokenizar" }) == 1)) {
        CadenaSegura _ret_315 = (CadenaSegura){ .longitud = (int)strlen("int"), .datos = "int" };
        return _ret_315;
    }
    if ((str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("parsear"), .datos = "parsear" }) == 1)) {
        CadenaSegura _ret_316 = (CadenaSegura){ .longitud = (int)strlen("Programa"), .datos = "Programa" };
        return _ret_316;
    }
    if ((str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("generar"), .datos = "generar" }) == 1)) {
        CadenaSegura _ret_317 = (CadenaSegura){ .longitud = (int)strlen("int"), .datos = "int" };
        return _ret_317;
    }
    if ((str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("_argc"), .datos = "_argc" }) == 1)) {
        CadenaSegura _ret_318 = (CadenaSegura){ .longitud = (int)strlen("int"), .datos = "int" };
        return _ret_318;
    }
    if ((str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("_argv"), .datos = "_argv" }) == 1)) {
        CadenaSegura _ret_319 = (CadenaSegura){ .longitud = (int)strlen("texto"), .datos = "texto" };
        return _ret_319;
    }
    if ((str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("salir"), .datos = "salir" }) == 1)) {
        CadenaSegura _ret_320 = (CadenaSegura){ .longitud = (int)strlen("nulo"), .datos = "nulo" };
        return _ret_320;
    }
    if ((str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("concat"), .datos = "concat" }) == 1)) {
        CadenaSegura _ret_321 = (CadenaSegura){ .longitud = (int)strlen("texto"), .datos = "texto" };
        return _ret_321;
    }
    if ((str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("texto_a_entero"), .datos = "texto_a_entero" }) == 1)) {
        CadenaSegura _ret_322 = (CadenaSegura){ .longitud = (int)strlen("int"), .datos = "int" };
        return _ret_322;
    }
    if ((str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("texto_a_decimal"), .datos = "texto_a_decimal" }) == 1)) {
        CadenaSegura _ret_323 = (CadenaSegura){ .longitud = (int)strlen("decimal"), .datos = "decimal" };
        return _ret_323;
    }
    if ((str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("entero_a_texto"), .datos = "entero_a_texto" }) == 1)) {
        CadenaSegura _ret_324 = (CadenaSegura){ .longitud = (int)strlen("texto"), .datos = "texto" };
        return _ret_324;
    }
    if ((str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("decimal_a_texto"), .datos = "decimal_a_texto" }) == 1)) {
        CadenaSegura _ret_325 = (CadenaSegura){ .longitud = (int)strlen("texto"), .datos = "texto" };
        return _ret_325;
    }
    if ((str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("volcar_ast"), .datos = "volcar_ast" }) == 1)) {
        CadenaSegura _ret_326 = (CadenaSegura){ .longitud = (int)strlen("nulo"), .datos = "nulo" };
        return _ret_326;
    }
    if ((str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("canal_crear"), .datos = "canal_crear" }) == 1)) {
        CadenaSegura _ret_327 = (CadenaSegura){ .longitud = (int)strlen("CanalConcurrencia*"), .datos = "CanalConcurrencia*" };
        return _ret_327;
    }
    if ((str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("canal_enviar"), .datos = "canal_enviar" }) == 1)) {
        CadenaSegura _ret_328 = (CadenaSegura){ .longitud = (int)strlen("nulo"), .datos = "nulo" };
        return _ret_328;
    }
    if ((str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("canal_recibir"), .datos = "canal_recibir" }) == 1)) {
        CadenaSegura _ret_329 = (CadenaSegura){ .longitud = (int)strlen("void*"), .datos = "void*" };
        return _ret_329;
    }
    if ((str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("cerrar_canal"), .datos = "cerrar_canal" }) == 1)) {
        CadenaSegura _ret_330 = (CadenaSegura){ .longitud = (int)strlen("nulo"), .datos = "nulo" };
        return _ret_330;
    }
    CadenaSegura _ret_331 = (CadenaSegura){ .longitud = (int)strlen(""), .datos = "" };
    return _ret_331;
}

CadenaSegura builtin_tipo_parametro(CadenaSegura nombre, int idx) {
    if ((((((str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("reserva"), .datos = "reserva" }) == 1) || (str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("libera"), .datos = "libera" }) == 1)) || (str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("crear_tensor"), .datos = "crear_tensor" }) == 1)) || (str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("suma_tensor"), .datos = "suma_tensor" }) == 1)) || (str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("producto_punto"), .datos = "producto_punto" }) == 1))) {
        if ((idx == 0)) {
            CadenaSegura _ret_335 = (CadenaSegura){ .longitud = (int)strlen("tensor"), .datos = "tensor" };
            return _ret_335;
        }
        if ((((idx == 1) || (str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("reserva"), .datos = "reserva" }) == 1)) || (str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("libera"), .datos = "libera" }) == 1))) {
            CadenaSegura _ret_336 = (CadenaSegura){ .longitud = (int)strlen("int"), .datos = "int" };
            return _ret_336;
        }
    }
    if ((str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("abrir"), .datos = "abrir" }) == 1)) {
        if (((idx == 0) || (idx == 1))) {
            CadenaSegura _ret_338 = (CadenaSegura){ .longitud = (int)strlen("texto"), .datos = "texto" };
            return _ret_338;
        }
    }
    if (((str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("leer"), .datos = "leer" }) == 1) || (str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("cerrar"), .datos = "cerrar" }) == 1))) {
        if ((idx == 0)) {
            CadenaSegura _ret_340 = (CadenaSegura){ .longitud = (int)strlen("Canal"), .datos = "Canal" };
            return _ret_340;
        }
    }
    if (((str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("escribir"), .datos = "escribir" }) == 1) || (str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("escribir_linea"), .datos = "escribir_linea" }) == 1))) {
        if ((idx == 0)) {
            CadenaSegura _ret_342 = (CadenaSegura){ .longitud = (int)strlen("texto"), .datos = "texto" };
            return _ret_342;
        }
    }
    if (((str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("suma"), .datos = "suma" }) == 1) || (str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("producto"), .datos = "producto" }) == 1))) {
        if (((idx == 0) || (idx == 1))) {
            CadenaSegura _ret_344 = (CadenaSegura){ .longitud = (int)strlen("tensor"), .datos = "tensor" };
            return _ret_344;
        }
    }
    if ((((str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("relu"), .datos = "relu" }) == 1) || (str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("tokenizar"), .datos = "tokenizar" }) == 1)) || (str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("parsear"), .datos = "parsear" }) == 1))) {
        if ((idx == 0)) {
            CadenaSegura _ret_346 = (CadenaSegura){ .longitud = (int)strlen("texto"), .datos = "texto" };
            return _ret_346;
        }
    }
    if ((str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("generar"), .datos = "generar" }) == 1)) {
        if ((idx == 0)) {
            CadenaSegura _ret_348 = (CadenaSegura){ .longitud = (int)strlen("Programa"), .datos = "Programa" };
            return _ret_348;
        }
        if ((idx == 1)) {
            CadenaSegura _ret_349 = (CadenaSegura){ .longitud = (int)strlen("texto"), .datos = "texto" };
            return _ret_349;
        }
    }
    if ((((str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("_argv"), .datos = "_argv" }) == 1) || (str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("salir"), .datos = "salir" }) == 1)) || (str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("texto_a_entero"), .datos = "texto_a_entero" }) == 1))) {
        if ((idx == 0)) {
            CadenaSegura _ret_351 = (CadenaSegura){ .longitud = (int)strlen("int"), .datos = "int" };
            return _ret_351;
        }
    }
    if ((str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("concat"), .datos = "concat" }) == 1)) {
        if (((idx == 0) || (idx == 1))) {
            CadenaSegura _ret_353 = (CadenaSegura){ .longitud = (int)strlen("texto"), .datos = "texto" };
            return _ret_353;
        }
    }
    if (((str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("texto_a_decimal"), .datos = "texto_a_decimal" }) == 1) || (str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("decimal_a_texto"), .datos = "decimal_a_texto" }) == 1))) {
        if ((idx == 0)) {
            CadenaSegura _ret_355 = (CadenaSegura){ .longitud = (int)strlen("texto"), .datos = "texto" };
            return _ret_355;
        }
    }
    if ((str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("entero_a_texto"), .datos = "entero_a_texto" }) == 1)) {
        if ((idx == 0)) {
            CadenaSegura _ret_357 = (CadenaSegura){ .longitud = (int)strlen("int"), .datos = "int" };
            return _ret_357;
        }
    }
    if ((str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("volcar_ast"), .datos = "volcar_ast" }) == 1)) {
        if ((idx == 0)) {
            CadenaSegura _ret_359 = (CadenaSegura){ .longitud = (int)strlen("Programa"), .datos = "Programa" };
            return _ret_359;
        }
    }
    if ((str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("canal_crear"), .datos = "canal_crear" }) == 1)) {
        if ((idx == 0)) {
            CadenaSegura _ret_361 = (CadenaSegura){ .longitud = (int)strlen("int"), .datos = "int" };
            return _ret_361;
        }
    }
    if ((str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("canal_enviar"), .datos = "canal_enviar" }) == 1)) {
        if ((idx == 0)) {
            CadenaSegura _ret_363 = (CadenaSegura){ .longitud = (int)strlen("CanalConcurrencia*"), .datos = "CanalConcurrencia*" };
            return _ret_363;
        }
        if ((idx == 1)) {
            CadenaSegura _ret_364 = (CadenaSegura){ .longitud = (int)strlen("void*"), .datos = "void*" };
            return _ret_364;
        }
    }
    if (((str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("canal_recibir"), .datos = "canal_recibir" }) == 1) || (str_eq(nombre, (CadenaSegura){ .longitud = (int)strlen("cerrar_canal"), .datos = "cerrar_canal" }) == 1))) {
        if ((idx == 0)) {
            CadenaSegura _ret_366 = (CadenaSegura){ .longitud = (int)strlen("CanalConcurrencia*"), .datos = "CanalConcurrencia*" };
            return _ret_366;
        }
    }
    CadenaSegura _ret_367 = (CadenaSegura){ .longitud = (int)strlen(""), .datos = "" };
    return _ret_367;
}

int nodo_tipo(struct AnalizadorSemanticoEst est, int idx) {
    int r;
    r = 0;
    { /* unsafe */
        r = (idx >= 0 && idx < est.total_nodos) ? est.nodos[idx].tipo_nodo : 0;
    }
    int _ret_374 = r;
    return _ret_374;
}

int nodo_linea(struct AnalizadorSemanticoEst est, int idx) {
    int r;
    r = 0;
    { /* unsafe */
        r = (idx >= 0 && idx < est.total_nodos) ? est.nodos[idx].linea : 0;
    }
    int _ret_380 = r;
    return _ret_380;
}

int nodo_hijo_izq(struct AnalizadorSemanticoEst est, int idx) {
    int r;
    r = 0;
    { /* unsafe */
        r = (idx >= 0 && idx < est.total_nodos) ? est.nodos[idx].hijo_izq : 0;
    }
    int _ret_386 = r;
    return _ret_386;
}

int nodo_hijo_der(struct AnalizadorSemanticoEst est, int idx) {
    int r;
    r = 0;
    { /* unsafe */
        r = (idx >= 0 && idx < est.total_nodos) ? est.nodos[idx].hijo_der : 0;
    }
    int _ret_392 = r;
    return _ret_392;
}

int nodo_hermano(struct AnalizadorSemanticoEst est, int idx) {
    int r;
    r = 0;
    { /* unsafe */
        r = (idx >= 0 && idx < est.total_nodos) ? est.nodos[idx].hermano : 0;
    }
    int _ret_398 = r;
    return _ret_398;
}

void registrar_estructura(struct AnalizadorSemanticoEst est, CadenaSegura nombre, int idx_nodo) {
    int i;
    int r;
    i = 0;
    r = 1;
    while ((r == 1)) {
        { /* unsafe */
            r = (i < est.total_estructuras) ? 1 : 0;
            if ((r == 0)) {
                break;
            }
            int _eq = 1;
            for (int _si = 0; _si < 256; _si++) { if (nombre.datos[_si] != est.info_estructuras[i].nombre.datos[_si]) { _eq = 0; break; } if (nombre.datos[_si] == 0) break; }
            if (_eq) {
                sem_error(est, ERR_SEM_REDEFINICION, idx_nodo, nombre);
                return;
            }
            i = i + 1;
        }
    }
    { /* unsafe */
        est.info_estructuras[est.total_estructuras].nombre = nombre;
        est.info_estructuras[est.total_estructuras].total_campos = 0;
        est.total_estructuras = est.total_estructuras + 1;
    }
}

int parsear_patron_coincidir(CadenaSegura patron, CadenaSegura tag_nombre, CadenaSegura var_nombre) {
    { /* unsafe */
        if (patron.datos[0] == '_' && patron.datos[1] == 0) { return 0; }
        // Extract tag name before '(';
        int _i = 0;
        char _tag[64]; int _tp = 0;
        while (patron.datos[_i] != 0 && patron.datos[_i] != '(') { _tag[_tp++] = patron.datos[_i]; _i++; }
        _tag[_tp] = 0;
        if (patron.datos[_i] != '(') { return -1; }
        _i++; // skip '(';
        char _var[64]; int _vp = 0;
        while (patron.datos[_i] != 0 && patron.datos[_i] != ')') { _var[_vp++] = patron.datos[_i]; _i++; }
        _var[_vp] = 0;
        if (patron.datos[_i] != ')') { return -1; }
        // Copy results using strdup to own memory;
        tag_nombre = (CadenaSegura){ .longitud = _tp, .datos = strdup(_tag) };
        var_nombre = (CadenaSegura){ .longitud = _vp, .datos = strdup(_var) };
    }
    int _ret_444 = 1;
    return _ret_444;
}

void analizar_sentencia(struct AnalizadorSemanticoEst est, int idx_nodo) {
    int tipo;
    int linea;
    int cuerpo;
    int stmt;
    int r;
    int prev;
    int casos;
    int idx_caso;
    int res;
    int cuerpo_caso;
    int stmt_c;
    int r2;
    if ((idx_nodo < 0)) {
        return;
    }
    tipo = nodo_tipo(est, idx_nodo);
    linea = nodo_linea(est, idx_nodo);
    if ((tipo == NODO_ASIGNACION)) {
        { /* unsafe */
            { int* _phi=(int*)est.asignaciones_campos_campo.datos; uintptr_t _bp=(uintptr_t)(unsigned)est.nodos[idx_nodo].ptr_str; if(_phi){ _bp|=((uintptr_t)(unsigned)_phi[idx_nodo])<<32; } const char* _v=(const char*)_bp; if(_v){ CadenaSegura _cs={.longitud=(int)strlen(_v),.datos=_v}; if(tabla_buscar(est,_cs)<0) sem_error(est,ERR_SEM_VAR_NO_DECLARADA,idx_nodo,_cs); } };
        }
        return;
    }
    if ((tipo == NODO_DECLARACION)) {
        { /* unsafe */
            { int* _phi=(int*)est.asignaciones_campos_campo.datos; uintptr_t _bp=(uintptr_t)(unsigned)est.nodos[idx_nodo].ptr_str; if(_phi){ _bp|=((uintptr_t)(unsigned)_phi[idx_nodo])<<32; } const char* _v=(const char*)_bp; if(_v){ CadenaSegura _cs={.longitud=(int)strlen(_v),.datos=_v}; if(tabla_buscar(est,_cs)>=0){ sem_error(est,ERR_SEM_REDEFINICION,idx_nodo,_cs); }else{ CadenaSegura _t={.longitud=5,.datos="entero"}; tabla_declarar(est,_cs,_t,idx_nodo,0); } } };
        }
        return;
    }
    if ((tipo == NODO_SI)) {
        tabla_entrar_scope(est);
        cuerpo = nodo_hijo_izq(est, idx_nodo);
        stmt = cuerpo;
        r = 1;
        while ((r == 1)) {
            if ((stmt <= 0)) {
                r = 0;
                break;
            }
            analizar_sentencia(est, stmt);
            { /* unsafe */
                stmt = est.nodos[stmt].hermano;
            }
        }
        tabla_salir_scope(est);
        return;
    }
    if ((tipo == NODO_MIENTRAS)) {
        tabla_entrar_scope(est);
        cuerpo = nodo_hijo_izq(est, idx_nodo);
        stmt = cuerpo;
        r = 1;
        while ((r == 1)) {
            if ((stmt <= 0)) {
                r = 0;
                break;
            }
            analizar_sentencia(est, stmt);
            { /* unsafe */
                stmt = est.nodos[stmt].hermano;
            }
        }
        tabla_salir_scope(est);
        return;
    }
    if ((tipo == NODO_INSEGURO)) {
        tabla_entrar_scope(est);
        prev = est.dentro_de_inseguro;
        est.dentro_de_inseguro = 1;
        cuerpo = nodo_hijo_izq(est, idx_nodo);
        stmt = cuerpo;
        r = 1;
        while ((r == 1)) {
            if ((stmt <= 0)) {
                r = 0;
                break;
            }
            analizar_sentencia(est, stmt);
            { /* unsafe */
                stmt = est.nodos[stmt].hermano;
            }
        }
        est.dentro_de_inseguro = prev;
        tabla_salir_scope(est);
        return;
    }
    if ((tipo == NODO_COINCIDIR)) {
        est.en_coincidir = 1;
        casos = nodo_hijo_izq(est, idx_nodo);
        idx_caso = casos;
        r = 1;
        while ((r == 1)) {
            if ((idx_caso <= 0)) {
                r = 0;
                break;
            }
            CadenaSegura tag_nombre = (CadenaSegura){ .longitud = (int)strlen(""), .datos = "" };
            CadenaSegura var_nombre = (CadenaSegura){ .longitud = (int)strlen(""), .datos = "" };
            res = 0;
            { /* unsafe */
                int* _phi=(int*)est.asignaciones_campos_campo.datos; uintptr_t _bp=(uintptr_t)(unsigned)est.nodos[idx_caso].ptr_str; if(_phi){ _bp|=((uintptr_t)(unsigned)_phi[idx_caso])<<32; } CadenaSegura _patron_s = { .longitud = 255, .datos = (const char*)_bp };
                res = parsear_patron_coincidir(_patron_s, tag_nombre, var_nombre);
            }
            if ((res == 0)) {
                tabla_entrar_scope(est);
                cuerpo_caso = nodo_hijo_izq(est, idx_caso);
                stmt_c = cuerpo_caso;
                r2 = 1;
                while ((r2 == 1)) {
                    if ((stmt_c <= 0)) {
                        r2 = 0;
                        break;
                    }
                    analizar_sentencia(est, stmt_c);
                    { /* unsafe */
                        stmt_c = est.nodos[stmt_c].hermano;
                    }
                }
                tabla_salir_scope(est);
            }
            if ((res == 1)) {
                tabla_declarar(est, var_nombre, (CadenaSegura){ .longitud = (int)strlen("int"), .datos = "int" }, idx_caso, 0);
                tabla_entrar_scope(est);
                cuerpo_caso = nodo_hijo_izq(est, idx_caso);
                stmt_c = cuerpo_caso;
                r2 = 1;
                while ((r2 == 1)) {
                    if ((stmt_c <= 0)) {
                        r2 = 0;
                        break;
                    }
                    analizar_sentencia(est, stmt_c);
                    { /* unsafe */
                        stmt_c = est.nodos[stmt_c].hermano;
                    }
                }
                tabla_salir_scope(est);
            }
            { /* unsafe */
                idx_caso = est.nodos[idx_caso].hermano;
            }
        }
        est.en_coincidir = 0;
        return;
    }
    if ((tipo == NODO_EXPR)) {
        return;
    }
    if ((tipo == NODO_LOG)) {
        return;
    }
    return;
}

void analizar_paso_estructuras(struct AnalizadorSemanticoEst est, int idx_programa) {
    int stmt;
    int r;
    int tipo;
    stmt = nodo_hijo_izq(est, idx_programa);
    r = 1;
    while ((r == 1)) {
        if ((stmt <= 0)) {
            r = 0;
            break;
        }
        tipo = nodo_tipo(est, stmt);
        if ((tipo == NODO_ESTRUCTURA)) {
            CadenaSegura nombre = (CadenaSegura){ .longitud = (int)strlen(""), .datos = "" };
            { /* unsafe */
                // Obtener nombre de estructura del nodo;
            }
            registrar_estructura(est, nombre, stmt);
        }
        { /* unsafe */
            stmt = est.nodos[stmt].hermano;
        }
    }
}

void analizar_paso_funciones(struct AnalizadorSemanticoEst est, int idx_programa) {
    int stmt;
    int r;
    int tipo;
    int ok;
    CadenaSegura nombre = (CadenaSegura){ .longitud = (int)strlen(""), .datos = "" };
    stmt = nodo_hijo_izq(est, idx_programa);
    r = 1;
    while ((r == 1)) {
        if ((stmt <= 0)) {
            r = 0;
            break;
        }
        tipo = nodo_tipo(est, stmt);
        if ((tipo == NODO_FUNCION)) {
            { /* unsafe */
                // Obtener nombre de funcion del nodo;
            }
            if ((es_builtin(nombre) == 0)) {
                ok = tabla_declarar(est, nombre, (CadenaSegura){ .longitud = (int)strlen("int"), .datos = "int" }, stmt, 0);
                if ((ok == 0)) {
                    sem_error(est, ERR_SEM_REDEFINICION, stmt, nombre);
                }
            }
        }
        if ((tipo == NODO_EXTERNO)) {
            { /* unsafe */
                // Obtener nombre externo del nodo;
            }
            ok = tabla_declarar(est, nombre, (CadenaSegura){ .longitud = (int)strlen("int"), .datos = "int" }, stmt, 0);
            if ((ok == 0)) {
                sem_error(est, ERR_SEM_REDEFINICION, stmt, nombre);
            }
        }
        { /* unsafe */
            stmt = est.nodos[stmt].hermano;
        }
    }
}

void analizar_paso_cuerpos(struct AnalizadorSemanticoEst est, int idx_programa) {
    int stmt;
    int r;
    int tipo;
    int cuerpo;
    int stmt_cuerpo;
    int r2;
    stmt = nodo_hijo_izq(est, idx_programa);
    r = 1;
    while ((r == 1)) {
        if ((stmt <= 0)) {
            r = 0;
            break;
        }
        tipo = nodo_tipo(est, stmt);
        if ((tipo == NODO_FUNCION)) {
            CadenaSegura nombre = (CadenaSegura){ .longitud = (int)strlen(""), .datos = "" };
            { /* unsafe */
                // Obtener nombre de funcion y analizar cuerpo;
            }
            if ((es_builtin(nombre) == 0)) {
                tabla_entrar_scope(est);
                est.func_actual = nombre;
                cuerpo = nodo_hijo_izq(est, stmt);
                stmt_cuerpo = cuerpo;
                r2 = 1;
                while ((r2 == 1)) {
                    if ((stmt_cuerpo <= 0)) {
                        r2 = 0;
                        break;
                    }
                    analizar_sentencia(est, stmt_cuerpo);
                    { /* unsafe */
                        stmt_cuerpo = est.nodos[stmt_cuerpo].hermano;
                    }
                }
                tabla_salir_scope(est);
                est.func_actual = (CadenaSegura){ .longitud = (int)strlen(""), .datos = "" };
            }
        }
        { /* unsafe */
            stmt = est.nodos[stmt].hermano;
        }
    }
}

void analizar(struct AnalizadorSemanticoEst est) {
    int idx_programa;
    idx_programa = 0;
    { /* unsafe */
        idx_programa = 0;
        // Buscar el nodo raiz NODO_PROGRAMA;
        for (int _i = 0; _i < est.total_nodos; _i++) {
            if (est.nodos[_i].tipo_nodo == 1) { idx_programa = _i; break; }
        }
    }
    if ((idx_programa < 0)) {
        return;
    }
    analizar_paso_estructuras(est, idx_programa);
    analizar_paso_funciones(est, idx_programa);
    analizar_paso_cuerpos(est, idx_programa);
}

struct AnalizadorSemanticoEst analizador_nuevo(struct SemNodo nodos, int total) {
    struct AnalizadorSemanticoEst est;
    est = (struct AnalizadorSemanticoEst){0};
    { /* unsafe */
        est.nodos = (struct SemNodo*)&nodos;
        est.total_nodos = total;
        est.tabla->nivel_actual = 0;
        est.tabla->total_entradas = 0;
    }
    est.func_retorno = (CadenaSegura){ .longitud = (int)strlen(""), .datos = "" };
    est.func_actual = (CadenaSegura){ .longitud = (int)strlen(""), .datos = "" };
    est.en_coincidir = 0;
    est.dentro_de_inseguro = 0;
    est.hay_error = 0;
    est.total_estructuras = 0;
    est.total_asignaciones = 0;
    struct AnalizadorSemanticoEst _ret_685 = est;
    return _ret_685;
}

#define _GEN_TMP_SIZE (4096)
void traducir_tipo_c(void* tipo_synapse) {
    { /* unsafe */
        const char* _t = (const char*)tipo_synapse;
        if (!_t) { strcpy(_gen_tmp_buf, "void"); return; }
        int _len = (int)strlen(_t);
        if (_len > 7 && _t[0]=='C' && _t[1]=='a' && _t[2]=='n' && _t[3]=='a' && _t[4]=='l' && _t[5]=='<');
            { strcpy(_gen_tmp_buf, "CanalConcurrencia*"); return; }
        if (_len > 10 && _t[0]=='R' && _t[1]=='e' && _t[2]=='s' && _t[3]=='u' && _t[4]=='l' && _t[5]=='t' && _t[6]=='a' && _t[7]=='d' && _t[8]=='o' && _t[9]=='<');
            { strcpy(_gen_tmp_buf, "Resultado_T"); return; }
        if (strcmp(_t, "entero")==0 || strcmp(_t, "int")==0) { strcpy(_gen_tmp_buf, "int"); return; }
        if (strcmp(_t, "vacio")==0 || strcmp(_t, "nulo")==0 || strcmp(_t, "void")==0) { strcpy(_gen_tmp_buf, "void"); return; }
        if (strcmp(_t, "decimal")==0 || strcmp(_t, "real")==0 || strcmp(_t, "flotante")==0) { strcpy(_gen_tmp_buf, "float"); return; }
        if (strcmp(_t, "Tensor")==0 || strcmp(_t, "tensor")==0) { strcpy(_gen_tmp_buf, "Tensor"); return; }
        if (strcmp(_t, "Canal")==0 || strcmp(_t, "canal")==0) { strcpy(_gen_tmp_buf, "Canal"); return; }
        if (strcmp(_t, "texto")==0 || strcmp(_t, "cadena")==0) { strcpy(_gen_tmp_buf, "CadenaSegura"); return; }
        if (strcmp(_t, "booleano")==0 || strcmp(_t, "logico")==0) { strcpy(_gen_tmp_buf, "int"); return; }
        if (strcmp(_t, "char")==0) { strcpy(_gen_tmp_buf, "char"); return; }
        if (strcmp(_t, "double")==0) { strcpy(_gen_tmp_buf, "double"); return; }
        if (strcmp(_t, "puntero")==0) { strcpy(_gen_tmp_buf, "void*"); return; }
        snprintf(_gen_tmp_buf, 64, "struct %s", _t);
    }
}

void gen_emitir_linea(struct GeneradorCEst est, CadenaSegura linea) {
    { /* unsafe */
        extern char _G_emit_buf[1048576]; extern int _G_emit_pos;
        {
            const char* _gs = linea.datos;
            int _gl = linea.longitud;
            if (_G_emit_pos + _gl + 2 > 1048576) return;
            memcpy(_G_emit_buf + _G_emit_pos, _gs, _gl);
            _G_emit_pos += _gl;
            _G_emit_buf[_G_emit_pos] = 10;
            _G_emit_pos++;
            _G_emit_buf[_G_emit_pos] = 0;
        }
    }
}

void gen_emitir_str(struct GeneradorCEst est, void* str) {
    { /* unsafe */
        if (!str) return;
        const char* _s = (const char*)str;
        int _len = (int)strlen(_s);
        CadenaSegura _cs = {_len, _s};
        gen_emitir_linea(est, _cs);
    }
}

void gen_emitir_nueva_linea(struct GeneradorCEst est) {
    { /* unsafe */
        extern char _G_emit_buf[1048576]; extern int _G_emit_pos;
        {
            if (_G_emit_pos + 2 > 1048576) return;
            _G_emit_buf[_G_emit_pos] = 10;
            _G_emit_pos++;
            _G_emit_buf[_G_emit_pos] = 0;
        }
    }
}

CadenaSegura gen_obtener_salida(struct GeneradorCEst est) {
    CadenaSegura r = (CadenaSegura){ .longitud = (int)strlen(""), .datos = "" };
    { /* unsafe */
        extern char _G_emit_buf[1048576]; extern int _G_emit_pos;
        if (_G_emit_pos > 0) {
            _G_emit_buf[_G_emit_pos] = 0;
            strcpy(_gen_tmp_buf, _G_emit_buf);
        } else {
            strcpy(_gen_tmp_buf, "");
        }
        r = (CadenaSegura){.longitud=(int)strlen(_gen_tmp_buf), .datos=strdup(_gen_tmp_buf)};
    }
    CadenaSegura _ret_291 = r;
    return _ret_291;
}

void gen_escribir_cadena_escapada(struct GeneradorCEst est, void* str) {
    { /* unsafe */
        const char* _s=(const char*)str;if(!_s)return;char _esc[16384];int _epos=0;int _ei=0;while(_s[_ei]&&_epos<16380){char _c=_s[_ei];if(_c==10){_esc[_epos++]=92;_esc[_epos++]=110;}else if(_c==34){_esc[_epos++]=92;_esc[_epos++]=34;}else if(_c==92){_esc[_epos++]=92;_esc[_epos++]=92;}else if(_c==9){_esc[_epos++]=92;_esc[_epos++]=116;}else if(_c==13){_esc[_epos++]=92;_esc[_epos++]=114;}else{_esc[_epos++]=_c;}_ei++;}_esc[_epos]=0;CadenaSegura _esc_cs={.longitud=_epos,.datos=_esc};gen_emitir_linea(est,_esc_cs);
    }
}

void gen_emitir_traza(struct GeneradorCEst est, void* modulo, void* nombre_nodo) {
    { /* unsafe */
        const char* _mod = (const char*)modulo;
        const char* _nn = (const char*)nombre_nodo;
        if (!_mod || !_nn) return;
        char _buf[512];
        snprintf(_buf, 512, "  /* [Traza: %s - %s] */", _mod, _nn);
        gen_emitir_str(est, _buf);
    }
}

void gen_abrir_bloque_c(struct GeneradorCEst est) {
    { /* unsafe */
        extern char _G_emit_buf[1048576]; extern int _G_emit_pos;
        if (_G_emit_pos + 2 > 1048576) return;
        _G_emit_buf[_G_emit_pos] = '{';
        _G_emit_pos++;
        _G_emit_buf[_G_emit_pos] = 10;
        _G_emit_pos++;
        _G_emit_buf[_G_emit_pos] = 0;
    }
}

void gen_cerrar_bloque_c(struct GeneradorCEst est) {
    { /* unsafe */
        extern char _G_emit_buf[1048576]; extern int _G_emit_pos;
        if (_G_emit_pos + 2 > 1048576) return;
        _G_emit_buf[_G_emit_pos] = '}';
        _G_emit_pos++;
        _G_emit_buf[_G_emit_pos] = 10;
        _G_emit_pos++;
        _G_emit_buf[_G_emit_pos] = 0;
    }
}

int _syn_es_tipo(void* ptr_tipo_nodo, void* esperado) {
    { /* unsafe */
        if (!ptr_tipo_nodo || !esperado) return 0;
        return strncmp((const char*)ptr_tipo_nodo, (const char*)esperado, 64) == 0;
    }
}

void _oo_expr_a_c(struct GeneradorCEst est, void* nodo, void* buf, int bufsz) {
    { /* unsafe */
        struct Nodo* _n = (struct Nodo*)nodo;
        char* _b = (char*)buf;
        int _sz = bufsz;
        if (!_n || !_b || _sz <= 0) return;
        const char* _t = _n->tipo.datos;
        if (!_t) { strcpy(_b, "0"); return; }
        _b[0] = 0;

        if (_syn_es_tipo(_t, "LiteralNumero")) {
            struct LiteralNumero* _ln = (struct LiteralNumero*)_n;
            snprintf(_b, _sz, "%d", _ln->valor);
            return;
        }

        if (_syn_es_tipo(_t, "LiteralDecimal")) {
            // NOTE: No struct LiteralDecimal in ast_types.h yet.;
            // Using lexeme from the token IF accessible, otherwise snprintf float.;
            // The LiteralDecimal node in OO layer may have a token reference;
            // for now emit 0.0f as safe default (micro-tests use ints).;
            extern char _gen_tmp_buf[4096];
            // Try to snprintf from float valor if struct has it;
            struct LiteralNumero* _ld = (struct LiteralNumero*)_n;
            snprintf(_b, _sz, "%%d.0f", _ld->valor);
            return;
        }

        if (_syn_es_tipo(_t, "Identificador")) {
            struct Identificador* _id = (struct Identificador*)_n;
            if (_id->nombre.datos) strncpy(_b, _id->nombre.datos, _sz - 1);
            return;
        }

        if (_syn_es_tipo(_t, "LiteralCadena")) {
            struct LiteralCadena* _lc = (struct LiteralCadena*)_n;
            if (_lc->valor.datos && _lc->valor.longitud > 0) {
                snprintf(_b, _sz, "\"%s\"", _lc->valor.datos);
            } else {
                strcpy(_b, "\"\"");
            }
            return;
        }

        if (_syn_es_tipo(_t, "OpBinaria")) {
            struct OpBinaria* _op = (struct OpBinaria*)_n;
            char _izq[512], _der[512];
            _izq[0] = _der[0] = 0;
            if (_op->izquierdo) { _oo_expr_a_c(est, _op->izquierdo, _izq, 512); }
            if (_op->derecho) { _oo_expr_a_c(est, _op->derecho, _der, 512); }
            const char* _op_str = "";
            if (_op->operador) {
                int _ot = _op->operador->tipo;
                switch (_ot) {
                    case 30: _op_str = " + "; break;
                    case 31: _op_str = " - "; break;
                    case 32: _op_str = " * "; break;
                    case 33: _op_str = " / "; break;
                    case 16: _op_str = " > "; break;
                    case 17: _op_str = " < "; break;
                    case 25: _op_str = " == "; break;
                    case 26: _op_str = " != "; break;
                    case 28: _op_str = " >= "; break;
                    case 27: _op_str = " <= "; break;
                    case 14: _op_str = " && "; break;
                    case 15: _op_str = " || "; break;
                    default: _op_str = " ? "; break;
                }
            }
            snprintf(_b, _sz, "%s%s%s", _izq, _op_str, _der);
            return;
        }

        if (_syn_es_tipo(_t, "OpUnaria")) {
            struct OpUnaria* _ou = (struct OpUnaria*)_n;
            char _uexpr[512]; _uexpr[0] = 0;
            if (_ou->expr) { _oo_expr_a_c(est, _ou->expr, _uexpr, 512); }
            const char* _uop = "";
            if (_ou->operador) {
                int _ut = _ou->operador->tipo;
                if (_ut == 31) { _uop = "-"; } else if (_ut == 16) { _uop = "!"; }
            }
            snprintf(_b, _sz, "%s%s", _uop, _uexpr);
            return;
        }

        if (_syn_es_tipo(_t, "LlamadaFuncion")) {
            struct LlamadaFuncion* _lf = (struct LlamadaFuncion*)_n;
            if (_lf->nombre.datos) strcpy(_b, _lf->nombre.datos);
            strcat(_b, "(");
            int _arg_idx = 0;
            struct ListaNodo* _arg_cur = _lf->argumentos;
            while (_arg_cur) {
                struct Nodo* _arg_n = _arg_cur->cabeza;
                if (_arg_n) {
                    if (_arg_idx > 0) strcat(_b, ", ");
                    char _arg_buf[256]; _arg_buf[0] = 0;
                    _oo_expr_a_c(est, _arg_n, _arg_buf, 256);
                    strcat(_b, _arg_buf);
                    _arg_idx++;
                }
                _arg_cur = _arg_cur->cola;
            }
            strcat(_b, ")");
            return;
        }

        // Fallback;
        strcpy(_b, "0");
    }
}

void gen_visitar_si(struct GeneradorCEst est, void* stmt) {
    { /* unsafe */
        struct SentenciaSi* _s = (struct SentenciaSi*)stmt;
        if (!_s) return;
        gen_emitir_traza(est, "nodos_flujo.syn", "SentenciaSi");
        char _buf[4096], _buf2[4096];
        // if (condition) (;
        _buf[0] = 0;
        strcat(_buf, "    if (");
        _buf2[0] = 0;
        if (_s->condicion) { _oo_expr_a_c(est, _s->condicion, _buf2, 4096); }
        strcat(_buf, _buf2);
        strcat(_buf, ")");
        gen_emitir_str(est, _buf);
        gen_abrir_bloque_c(est);
        // Visit if-body via dispatcher;
        {
            struct ListaNodo* _ic = _s->cuerpo;
            while (_ic) {
                struct Nodo* _is = _ic->cabeza;
                if (_is) { gen_visitar_stmt_generico(est, _is); }
                _ic = _ic->cola;
            }
        }
        gen_cerrar_bloque_c(est);
        if (_s->cuerpo_sino) {
            gen_emitir_str(est, "    else");
            gen_abrir_bloque_c(est);
            struct ListaNodo* _ec = _s->cuerpo_sino;
            while (_ec) {
                struct Nodo* _es = _ec->cabeza;
                if (_es) { gen_visitar_stmt_generico(est, _es); }
                _ec = _ec->cola;
            }
            gen_cerrar_bloque_c(est);
        }
    }
}

void gen_visitar_mientras(struct GeneradorCEst est, void* stmt) {
    { /* unsafe */
        struct SentenciaMientras* _w = (struct SentenciaMientras*)stmt;
        if (!_w) return;
        gen_emitir_traza(est, "nodos_flujo.syn", "SentenciaMientras");
        char _buf[4096], _buf2[4096];
        // while (condition) (;
        _buf[0] = 0;
        strcat(_buf, "    while (");
        _buf2[0] = 0;
        if (_w->condicion) { _oo_expr_a_c(est, _w->condicion, _buf2, 4096); }
        strcat(_buf, _buf2);
        strcat(_buf, ")");
        gen_emitir_str(est, _buf);
        gen_abrir_bloque_c(est);
        // While-body via dispatcher;
        {
            struct ListaNodo* _wc = _w->cuerpo;
            while (_wc) {
                struct Nodo* _ws = _wc->cabeza;
                if (_ws) { gen_visitar_stmt_generico(est, _ws); }
                _wc = _wc->cola;
            }
        }
        gen_cerrar_bloque_c(est);
    }
}

void gen_visitar_retornar(struct GeneradorCEst est, void* stmt) {
    { /* unsafe */
        struct SentenciaRetornar* _rt = (struct SentenciaRetornar*)stmt;
        if (!_rt) return;
        gen_emitir_traza(est, "nodos_flujo.syn", "SentenciaRetornar");
        char _buf[4096], _buf2[4096];
        _buf[0] = 0;
        strcat(_buf, "    return ");
        _buf2[0] = 0;
        if (_rt->expr) { _oo_expr_a_c(est, _rt->expr, _buf2, 4096); }
        strcat(_buf, _buf2);
        strcat(_buf, ";");
        gen_emitir_str(est, _buf);
    }
}

void gen_visitar_declaracion(struct GeneradorCEst est, void* stmt) {
    { /* unsafe */
        struct DeclaracionVariable* _dv = (struct DeclaracionVariable*)stmt;
        if (!_dv) return;
        gen_emitir_traza(est, "nodos_flujo.syn", "DeclaracionVariable");
        if (!_dv->nombre.datos) {
            fprintf(stderr, "Error Fatal Generador: DeclaracionVariable sin nombre\n");
            exit(1);
        }
        char _buf[4096], _buf2[4096];
        _buf[0] = 0;
        // Detect string literal -> use const char*;
        const char* _var_type = "int ";
        if (_dv->expresion && _dv->expresion->tipo.datos && strcmp(_dv->expresion->tipo.datos, "LiteralCadena") == 0) {
            _var_type = "const char* ";
        }
        strcat(_buf, "    ");
        strcat(_buf, _var_type);
        strcat(_buf, _dv->nombre.datos);
        strcat(_buf, " = ");
        _buf2[0] = 0;
        if (_dv->expresion) { _oo_expr_a_c(est, _dv->expresion, _buf2, 4096); }
        strcat(_buf, _buf2);
        strcat(_buf, ";");
        gen_emitir_str(est, _buf);
    }
}

void gen_visitar_asignacion(struct GeneradorCEst est, void* stmt) {
    { /* unsafe */
        struct AsignacionVariable* _a = (struct AsignacionVariable*)stmt;
        if (!_a) return;
        gen_emitir_traza(est, "nodos_flujo.syn", "AsignacionVariable");
        if (!_a->nombre.datos) {
            fprintf(stderr, "Error Fatal Generador: AsignacionVariable sin nombre\n");
            exit(1);
        }
        char _buf[4096], _buf2[4096];
        _buf[0] = 0;
        // Detect string literal assignment -> use const char*;
        const char* _var_type = "int ";
        if (_a->expresion && _a->expresion->tipo.datos && strcmp(_a->expresion->tipo.datos, "LiteralCadena") == 0) {
            _var_type = "const char* ";
        }
        strcat(_buf, "    ");
        strcat(_buf, _var_type);
        strcat(_buf, _a->nombre.datos);
        strcat(_buf, " = ");
        _buf2[0] = 0;
        if (_a->expresion) { _oo_expr_a_c(est, _a->expresion, _buf2, 4096); }
        strcat(_buf, _buf2);
        strcat(_buf, ";");
        gen_emitir_str(est, _buf);
    }
}

void gen_visitar_expr(struct GeneradorCEst est, void* stmt) {
    { /* unsafe */
        struct SentenciaExpr* _s = (struct SentenciaExpr*)stmt;
        if (!_s) return;
        gen_emitir_traza(est, "nodos_flujo.syn", "SentenciaExpr");
        char _buf[4096];
        _buf[0] = 0;
        if (_s->expr) { _oo_expr_a_c(est, _s->expr, _buf, 4096); }
        strcat(_buf, ";");
        gen_emitir_str(est, _buf);
    }
}

void gen_visitar_romper(struct GeneradorCEst est, void* stmt) {
    { /* unsafe */
        struct SentenciaRomper* _br = (struct SentenciaRomper*)stmt;
        if (!_br) return;
        gen_emitir_traza(est, "nodos_flujo.syn", "SentenciaRomper");
        gen_emitir_str(est, "    break;");
    }
}

void gen_visitar_siguiente(struct GeneradorCEst est, void* stmt) {
    { /* unsafe */
        struct SentenciaSiguiente* _ct = (struct SentenciaSiguiente*)stmt;
        if (!_ct) return;
        gen_emitir_traza(est, "nodos_flujo.syn", "SentenciaSiguiente");
        gen_emitir_str(est, "    continue;");
    }
}

void gen_visitar_stmt_generico(struct GeneradorCEst est, void* stmt) {
    { /* unsafe */
        struct Nodo* _n = (struct Nodo*)stmt;
        if (!_n) return;
        const char* _t = _n->tipo.datos;
        if (!_t) {
            fprintf(stderr, "Error Fatal Generador: Nodo sin tipo (puntero nulo en tipo.datos)\n");
            exit(1);
        }
        if (_syn_es_tipo(_t, "SentenciaSi")) { gen_visitar_si(est, stmt); }
        else if (_syn_es_tipo(_t, "SentenciaMientras")) { gen_visitar_mientras(est, stmt); }
        else if (_syn_es_tipo(_t, "SentenciaRetornar")) { gen_visitar_retornar(est, stmt); }
        else if (_syn_es_tipo(_t, "AsignacionVariable")) { gen_visitar_asignacion(est, stmt); }
        else if (_syn_es_tipo(_t, "SentenciaExpr")) { gen_visitar_expr(est, stmt); }
        else if (_syn_es_tipo(_t, "DeclaracionVariable")) { gen_visitar_declaracion(est, stmt); }
        else if (_syn_es_tipo(_t, "AsignacionCampo")) { gen_visitar_expr(est, stmt); }
        else if (_syn_es_tipo(_t, "SentenciaRomper")) { gen_visitar_romper(est, stmt); }
        else if (_syn_es_tipo(_t, "SentenciaSiguiente")) { gen_visitar_siguiente(est, stmt); }
        else if (_syn_es_tipo(_t, "BloqueInseguro")) {
            struct BloqueInseguro* _sbi = (struct BloqueInseguro*)stmt;
            gen_emitir_traza(est, "nodos_flujo.syn", "BloqueInseguro");
            struct ListaNodo* _sbl = (struct ListaNodo*)_sbi->cuerpo;
            while (_sbl) {
                struct Nodo* _sbs = _sbl->cabeza;
                if (_sbs) { gen_visitar_stmt_generico(est, _sbs); }
                _sbl = _sbl->cola;
            }
        } else {
            fprintf(stderr, "Error Fatal Generador: Nodo tipo [%s] no reconocido\n", _t);
            exit(1);
        }
    }
}

int generar(struct Programa programa, CadenaSegura ruta) {
    int r;
    struct GeneradorCEst est;
    r = 0;
    est = (struct GeneradorCEst){0};
    { /* unsafe */
        fprintf(stderr, "[Orquestador] Abriendo archivo...\n"); fflush(stderr);
        extern char _G_emit_buf[1048576]; extern int _G_emit_pos;
        _G_emit_pos = 0;
        FILE* _G_out = fopen(ruta.datos, "w");
        if (!_G_out) { fprintf(stderr, "[Orquestador] ERROR FATAL: No se pudo abrir %s\n", ruta.datos); r = 1; return r; }
        extern FILE* _G_fp; _G_fp = _G_out;
        fprintf(stderr, "[Orquestador] Archivo abierto\n"); fflush(stderr);
    }
    gen_emitir_linea(est, (CadenaSegura){ .longitud = (int)strlen("// Generado por Synapse (nuevo generador modular)"), .datos = "// Generado por Synapse (nuevo generador modular)" });
    gen_emitir_linea(est, (CadenaSegura){ .longitud = (int)strlen("#include <stdio.h>"), .datos = "#include <stdio.h>" });
    gen_emitir_linea(est, (CadenaSegura){ .longitud = (int)strlen("#include <stdlib.h>"), .datos = "#include <stdlib.h>" });
    gen_emitir_linea(est, (CadenaSegura){ .longitud = (int)strlen("#include <string.h>"), .datos = "#include <string.h>" });
    gen_emitir_linea(est, (CadenaSegura){ .longitud = (int)strlen("typedef struct { int longitud; const char* datos; } CadenaSegura;"), .datos = "typedef struct { int longitud; const char* datos; } CadenaSegura;" });
    gen_emitir_linea(est, (CadenaSegura){ .longitud = (int)strlen("#define nulo ((void*)0)"), .datos = "#define nulo ((void*)0)" });
    gen_emitir_linea(est, (CadenaSegura){ .longitud = (int)strlen("#define verdadero 1"), .datos = "#define verdadero 1" });
    gen_emitir_linea(est, (CadenaSegura){ .longitud = (int)strlen("#define falso 0"), .datos = "#define falso 0" });
    gen_emitir_linea(est, (CadenaSegura){ .longitud = (int)strlen("int _g_argc;"), .datos = "int _g_argc;" });
    gen_emitir_linea(est, (CadenaSegura){ .longitud = (int)strlen("char** _g_argv;"), .datos = "char** _g_argv;" });
    { /* unsafe */
        fprintf(stderr, "[Orquestador] Iniciando recorrido AST\n"); fflush(stderr);
        struct ListaNodo* _cur = programa.sentencias;
        if (!_cur) { fprintf(stderr, "[Orquestador] ERROR FATAL: AST vacio (sentencias nulo)\n"); r = 1; return r; }
        int _count = 0;
        while (_cur) {
            _count++;
            struct Nodo* _n = _cur->cabeza;
            if (!_n) { _cur = _cur->cola; continue; }
            fprintf(stderr, "[Orquestador] Node %d: tipo='%s'\n", _count, _n->tipo.datos ? _n->tipo.datos : "(null)"); fflush(stderr);
            gen_visitar_top_level(est, _n);
            _cur = _cur->cola;
        }
        fprintf(stderr, "[Orquestador] Recorrido AST completado: %d nodos\n", _count); fflush(stderr);
    }
    gen_emitir_linea(est, (CadenaSegura){ .longitud = (int)strlen("int main(int argc, char** argv) {"), .datos = "int main(int argc, char** argv) {" });
    gen_emitir_linea(est, (CadenaSegura){ .longitud = (int)strlen("    _g_argc = argc;"), .datos = "    _g_argc = argc;" });
    gen_emitir_linea(est, (CadenaSegura){ .longitud = (int)strlen("    _g_argv = argv;"), .datos = "    _g_argv = argv;" });
    gen_emitir_linea(est, (CadenaSegura){ .longitud = (int)strlen("    pool_init(64, 4096);"), .datos = "    pool_init(64, 4096);" });
    gen_emitir_linea(est, (CadenaSegura){ .longitud = (int)strlen("    return principal();"), .datos = "    return principal();" });
    gen_emitir_linea(est, (CadenaSegura){ .longitud = (int)strlen("}"), .datos = "}" });
    { /* unsafe */
        fprintf(stderr, "[Orquestador] Escribiendo archivo de salida...\n"); fflush(stderr);
        extern char _G_emit_buf[1048576]; extern int _G_emit_pos;
        extern FILE* _G_fp;
        if (!_G_fp) { fprintf(stderr, "[Orquestador] ERROR FATAL: _G_fp nulo\n"); r = 1; return r; }
        if (_G_emit_pos > 0) {
            fwrite(_G_emit_buf, 1, _G_emit_pos, _G_fp);
        }
        fclose(_G_fp);
        _G_fp = nulo;
        fprintf(stderr, "[Nuevo Generador] Codigo C generado exitosamente\n"); fflush(stderr);
    }
    int _ret_794 = r;
    return _ret_794;
}

void gen_visitar_top_level(struct GeneradorCEst est, void* stmt) {
    { /* unsafe */
        struct Nodo* _n = (struct Nodo*)stmt;
        if (!_n) { fprintf(stderr, "[DEBUG] gen_visitar_top_level: stmt is NULL\n"); return; }
        const char* _t = _n->tipo.datos;
        if (!_t) { fprintf(stderr, "[DEBUG] gen_visitar_top_level: tipo.datos is NULL\n"); exit(1); }
        fprintf(stderr, "[DEBUG] gen_visitar_top_level: tipo='%s'\n", _t);
        if (_syn_es_tipo(_t, "DefinicionFuncion")) {
            struct DefinicionFuncion* _f = (struct DefinicionFuncion*)_n;
            fprintf(stderr, "[DEBUG]   DefinicionFuncion: _f=%p\n", (void*)_f);
            fprintf(stderr, "[DEBUG]   nombre.datos=%p\n", (void*)_f->nombre.datos);
            const char* _fn = _f->nombre.datos;
            if (!_fn) { fprintf(stderr, "Error Fatal: DefinicionFuncion sin nombre\n"); exit(1); }
            fprintf(stderr, "[DEBUG]   nombre='%s'\n", _fn);
            char _sig[4096];
            snprintf(_sig, 4096, "int %s()", _fn);
            fprintf(stderr, "[DEBUG]   emit function signature\n");
            gen_emitir_str(est, _sig);
            gen_abrir_bloque_c(est);
            fprintf(stderr, "[DEBUG]   start walking body\n");
            struct ListaNodo* _bc = _f->cuerpo;
            fprintf(stderr, "[DEBUG]   cuerpo=%p\n", (void*)_bc);
            int _bs_count = 0;
            while (_bc) {
                _bs_count++;
                struct Nodo* _bs = _bc->cabeza;
                fprintf(stderr, "[DEBUG]   body stmt %d: _bs=%p\n", _bs_count, (void*)_bs);
                if (!_bs) { _bc = _bc->cola; continue; }
                if (_bs->tipo.datos) {
                    fprintf(stderr, "[DEBUG]     tipo='%s'\n", _bs->tipo.datos);
                }
                fprintf(stderr, "[DEBUG]     calling gen_visitar_stmt_generico...\n");
                gen_visitar_stmt_generico(est, _bs);
                fprintf(stderr, "[DEBUG]     return OK\n");
                _bc = _bc->cola;
            }
            fprintf(stderr, "[DEBUG]   body done (%d stmts)\n", _bs_count);
            gen_cerrar_bloque_c(est);
            fprintf(stderr, "[DEBUG]   function done\n");
        } else if (_syn_es_tipo(_t, "SentenciaExpr")) {
            gen_visitar_expr(est, stmt);
        } else if (_syn_es_tipo(_t, "AsignacionVariable")) {
            gen_visitar_asignacion(est, stmt);
        } else if (_syn_es_tipo(_t, "DefinicionEstructura")) {
            /* skip struct */;
        } else if (_syn_es_tipo(_t, "DeclaracionExterna")) {
            /* skip extern */;
        } else if (_syn_es_tipo(_t, "SentenciaImportar")) {
            /* skip import - NOT a BloqueInseguro, do NOT cast */;
        }
        else if (_syn_es_tipo(_t, "SentenciaSi")) { gen_visitar_si(est, stmt); }
        else if (_syn_es_tipo(_t, "SentenciaMientras")) { gen_visitar_mientras(est, stmt); }
        else if (_syn_es_tipo(_t, "SentenciaRetornar")) { gen_visitar_retornar(est, stmt); }
        else if (_syn_es_tipo(_t, "SentenciaRomper")) { gen_visitar_romper(est, stmt); }
        else if (_syn_es_tipo(_t, "SentenciaSiguiente")) { gen_visitar_siguiente(est, stmt); }
        else if (_syn_es_tipo(_t, "DeclaracionVariable")) { gen_visitar_declaracion(est, stmt); }
        else if (_syn_es_tipo(_t, "BloqueInseguro")) {
            struct BloqueInseguro* _sbi = (struct BloqueInseguro*)stmt;
            struct ListaNodo* _sbl = (struct ListaNodo*)_sbi->cuerpo;
            while (_sbl) {
                struct Nodo* _sbs = _sbl->cabeza;
                if (_sbs) { gen_visitar_stmt_generico(est, _sbs); }
                _sbl = _sbl->cola;
            }
        }
        else {
            fprintf(stderr, "Error Fatal Generador: Nodo tipo [%s] no reconocido\n", _t);
            exit(1);
        }
    }
}

#define AXON_MODULES ((CadenaSegura){ .longitud = (int)strlen("axon_modules"), .datos = "axon_modules" })
CadenaSegura buscar_en(CadenaSegura dir_base, CadenaSegura ruta_import) {
    CadenaSegura r = (CadenaSegura){ .longitud = (int)strlen(""), .datos = "" };
    { /* unsafe */
        char _buf[1024];
        snprintf(_buf, 1024, "%s/%s/%s/principal.syn", dir_base.datos, "axon_modules", ruta_import.datos);
        FILE* _f = fopen(_buf, "r");
        if (_f) { fclose(_f); r = (CadenaSegura){.longitud=(int)strlen(_buf),.datos=strdup(_buf)}; } else {
            snprintf(_buf, 1024, "%s/%s/%s.syn", dir_base.datos, "axon_modules", ruta_import.datos);
            for (char* _p = _buf; *_p; _p++) if (*_p == '.') *_p = '/';
            _f = fopen(_buf, "r");
            if (_f) { fclose(_f); r = (CadenaSegura){.longitud=(int)strlen(_buf),.datos=strdup(_buf)}; }
        }
    }
    CadenaSegura _ret_20 = r;
    return _ret_20;
}

CadenaSegura resolver(CadenaSegura ruta_import, CadenaSegura dir_base, CadenaSegura dependencias_nombres, CadenaSegura dependencias_valores, int total_dependencias) {
    CadenaSegura r = (CadenaSegura){ .longitud = (int)strlen(""), .datos = "" };
    { /* unsafe */
        // Check if dependency is in the declared list;
        for (int _di = 0; _di < total_dependencias; _di++) {
            if (strcmp(dependencias_nombres.datos + _di * 128, ruta_import.datos) == 0) {
                r = (CadenaSegura){.longitud=(int)strlen(dependencias_valores.datos + _di * 512),.datos=strdup(dependencias_valores.datos + _di * 512)};
                break;
            }
        }
        if (r.longitud == 0) {
            // Look up in filesystem;
            char _ruta[1024];
            snprintf(_ruta, 1024, "%s/%s/%s/principal.syn", dir_base.datos, "axon_modules", ruta_import.datos);
            FILE* _f = fopen(_ruta, "r");
            if (_f) { fclose(_f); r = (CadenaSegura){.longitud=(int)strlen(_ruta),.datos=strdup(_ruta)}; } else {
                snprintf(_ruta, 1024, "%s/%s/%s.syn", dir_base.datos, "axon_modules", ruta_import.datos);
                for (char* _p = _ruta; *_p; _p++) if (*_p == '.') *_p = '/';
                _f = fopen(_ruta, "r");
                if (_f) { fclose(_f); r = (CadenaSegura){.longitud=(int)strlen(_ruta),.datos=strdup(_ruta)}; }
            }
        }
        if (r.longitud == 0) {
            // Not found - build error message;
            char _msg[4096];
            snprintf(_msg, 4096, "No se pudo resolver la importacion: %s", ruta_import.datos);
            r = (CadenaSegura){.longitud=(int)strlen(_msg),.datos=strdup(_msg)};
        }
    }
    CadenaSegura _ret_50 = r;
    return _ret_50;
}

extern struct NodoJson _json_parse(CadenaSegura entrada);
extern struct NodoJson _json_nodo_new(void);
extern void _json_nodo_liberar(struct NodoJson n);
extern struct NodoJson _json_array_get(struct NodoJson nodo, int indice);
extern struct NodoJson _json_object_get(struct NodoJson nodo, CadenaSegura clave);
struct NodoJson desde_texto(CadenaSegura entrada) {
    struct NodoJson _ret_29 = _json_parse(entrada);
    return _ret_29;
}

void liberar_nodo(struct NodoJson n) {
    _json_nodo_liberar(n);
    _json_nodo_liberar(n);
    return;
}

struct NodoJson obtener_elemento(struct NodoJson nodo, int indice) {
    struct NodoJson _ret_36 = _json_array_get(nodo, indice);
    return _ret_36;
}

struct NodoJson obtener_campo(struct NodoJson nodo, CadenaSegura clave) {
    struct NodoJson _ret_39 = _json_object_get(nodo, clave);
    return _ret_39;
}

#define _LSP_BUF_SIZE (262144)
#define _LSP_MAX_URI (1024)
#define _LSP_MAX_TEXT (131072)
int principal(void) {
    int r;
    r = 0;
    { /* unsafe */
        setbuf(stderr, NULL);
        extern int _setmode(int,int); _setmode(1,0x8000);
        fprintf(stderr, "[Synapse-LSP] v0.2.5 (F14.4) iniciando...\n");
        char _lsp_uri[_LSP_MAX_URI] = {0};
        int _lsp_run = 1;
        char _lsp_buf[_LSP_BUF_SIZE];
        while (_lsp_run) {
            int _cl = 0; int _hp = 0; int _hd = 0; int _el = 0; int _ec = 0;
            while (!_hd) {
                int _c = fgetc(stdin);
                if (_c == (-1)) { _lsp_run = 0; break; }
                if (_hp < _LSP_BUF_SIZE - 1) { _lsp_buf[_hp++] = (char)_c; }
                _lsp_buf[_hp] = 0;
                // Detectar CRLF CRLF (modo binario) y LF-only (modo texto);
                if (_hp >= 4) {
                    char* _x = _lsp_buf + _hp - 4;
                    if (_x[0]==13 && _x[1]==10 && _x[2]==13 && _x[3]==10) { _hd = 1; }
                }
                if (_hp >= 2 && !_hd) {
                    char* _y = _lsp_buf + _hp - 2;
                    if (_y[0]==10 && _y[1]==10) { _hd = 1; }
                }
                if (_hp > 8192) { _hd = 1; break; }
            }
            if (!_lsp_run) break;
            char* _cm = strstr(_lsp_buf, "Content-Length:");
            if (!_cm) { _cm = strstr(_lsp_buf, "content-length:"); }
            if (_cm) { _cm += 15; while (*_cm==' '||*_cm==9) { _cm++; } _cl = atoi(_cm); }
            if (_cl <= 0 || _cl > _LSP_BUF_SIZE - 64) {
                continue;
            }
            int _br = 0;
            while (_br < _cl) {
                int _c = fgetc(stdin);
                if (_c == (-1)) { _lsp_run = 0; break; }
                _lsp_buf[_br++] = (char)_c;
            }
            if (!_lsp_run) break;
            _lsp_buf[_cl] = 0;
            CadenaSegura _ji = { .longitud = _cl, .datos = _lsp_buf };
            NodoJson _msg = _json_parse(_ji);
            if (_msg.tipo < 0) { _json_nodo_liberar(_msg); continue; }
            NodoJson _method = _json_object_get(_msg, (CadenaSegura){6,"method"});
            NodoJson _id = _json_object_get(_msg, (CadenaSegura){2,"id"});
            NodoJson _params = _json_object_get(_msg, (CadenaSegura){6,"params"});
            const char* _ms = (_method.tipo == 3) ? _method.valor_str.datos : "";
            int _is_notif = (_id.tipo < 0);
            int _method_known = 0;
            if (strcmp(_ms, "initialize") == 0) {
                _method_known = 1;
                const char* _R = "{\"jsonrpc\":\"2.0\",\"id\":1,\"result\":{\"capabilities\":{\"textDocumentSync\":{\"openClose\":true,\"change\":1,\"save\":{\"includeText\":true}}},\"serverInfo\":{\"name\":\"synapse-lsp-native\",\"version\":\"0.2.5\"}}}";
                fprintf(stdout, "Content-Length: %d\r\n\r\n%s", (int)strlen(_R), _R);
                fflush(stdout);
            }
            if (strcmp(_ms, "initialized") == 0) {
                _method_known = 1;
            }
            if (strcmp(_ms, "shutdown") == 0) {
                _method_known = 1;
                const char* _R = "{\"jsonrpc\":\"2.0\",\"id\":null,\"result\":null}";
                fprintf(stdout, "Content-Length: %d\r\n\r\n%s", (int)strlen(_R), _R);
                fflush(stdout);
                _lsp_run = 0;
            }
            if (strcmp(_ms, "exit") == 0) {
                _method_known = 1;
                _lsp_run = 0;
            }
            if (strcmp(_ms, "textDocument/didOpen") == 0 || strcmp(_ms, "textDocument/didChange") == 0 || strcmp(_ms, "textDocument/didSave") == 0) {
                _method_known = 1;
                NodoJson _td = _json_object_get(_params, (CadenaSegura){12,"textDocument"});
                char _uri[_LSP_MAX_URI] = {0}; char _text[_LSP_MAX_TEXT] = {0};
                if (_td.tipo == 5) {
                    NodoJson _un = _json_object_get(_td, (CadenaSegura){3,"uri"});
                    if (_un.tipo == 3 && _un.valor_str.datos) strncpy(_uri, _un.valor_str.datos, _LSP_MAX_URI-1);
                    _json_nodo_liberar(_un);
                    NodoJson _tn = _json_object_get(_td, (CadenaSegura){4,"text"});
                    if (_tn.tipo == 3 && _tn.valor_str.datos) strncpy(_text, _tn.valor_str.datos, _LSP_MAX_TEXT-1);
                    _json_nodo_liberar(_tn);
                    NodoJson _cc = _json_object_get(_params, (CadenaSegura){14,"contentChanges"});
                    if (_cc.tipo == 4 && _cc.longitud > 0) {
                        NodoJson _lc = _json_array_get(_cc, _cc.longitud-1);
                        if (_lc.tipo == 5) { NodoJson _ct = _json_object_get(_lc, (CadenaSegura){4,"text"});
                            if (_ct.tipo == 3 && _ct.valor_str.datos) strncpy(_text, _ct.valor_str.datos, _LSP_MAX_TEXT-1);
                            _json_nodo_liberar(_ct);
                        }
                        _json_nodo_liberar(_lc);
                    }
                    _json_nodo_liberar(_cc);
                }
                _json_nodo_liberar(_td);
                if (_uri[0] == 0 || _text[0] == 0) {
                    _json_nodo_liberar(_method); _json_nodo_liberar(_id); _json_nodo_liberar(_params); _json_nodo_liberar(_msg);
                    continue;
                }
                strncpy(_lsp_uri, _uri, _LSP_MAX_URI-1);
                CadenaSegura _fs = { .longitud = (int)strlen(_text), .datos = _text };
                int _diag_count = 0;
                char _diag_json[_LSP_BUF_SIZE/2]; _diag_json[0] = 0;
                extern _P_Token _P_tks[];
                extern int _P_ntks, _P_tpos, _P_p_err;
                extern int _P_nivel_pila; extern int _P_pila_indent[64];
                // Resetear estado global para reentrancia;
                _P_ntks = 0; _P_tpos = 0; _P_p_err = 0; _P_nivel_pila = 0; _P_pila_indent[0] = 0;
                // Validar #lang antes de invocar pipeline;
                int _has_lang = 0;
                if (_fs.longitud >= 6 && _fs.datos[0] == '#' && _fs.datos[1] == 'l' && _fs.datos[2] == 'a' && _fs.datos[3] == 'n' && _fs.datos[4] == 'g' && _fs.datos[5] == ':') { _has_lang = 1; }
                if (!_has_lang && _fs.longitud > 0) {
                    _diag_count = 1;
                    snprintf(_diag_json, sizeof(_diag_json), "[{\"range\":{\"start\":{\"line\":0,\"character\":0},\"end\":{\"line\":0,\"character\":1}},\"severity\":1,\"code\":\"ERR_LANG_MISSING\",\"source\":\"synapse\",\"message\":\"Falta declaracion #lang: <codigo> en la linea 1\"}]");
                }
                if (_has_lang) {
                    extern int tokenizar(CadenaSegura);
                    int _nt = tokenizar(_fs);
                    if (_nt < 0) {
                        if (_P_ntks > 0) { _el = _P_tks[_P_ntks-1].linea - 1; _ec = _P_tks[_P_ntks-1].col; }
                        _diag_count = 1;
                        snprintf(_diag_json, sizeof(_diag_json), "[{\"range\":{\"start\":{\"line\":%d,\"character\":%d},\"end\":{\"line\":%d,\"character\":%d}},\"severity\":1,\"code\":\"ERR_LEX\",\"source\":\"synapse\"}]", _el, _ec, _el, _ec+1);
                    }
                    if (_nt >= 0) {
                        extern struct Programa parsear(CadenaSegura);
                        _P_p_err = 0; _P_ntks = 0; _P_tpos = 0;
                        struct Programa _ast = parsear(_fs);
                        if (_P_p_err != 0) {
                            if (_P_tpos > 0 && _P_tpos <= _P_ntks) { _el = _P_tks[_P_tpos-1].linea - 1; _ec = _P_tks[_P_tpos-1].col; }
                            _diag_count = 1;
                            snprintf(_diag_json, sizeof(_diag_json), "[{\"range\":{\"start\":{\"line\":%d,\"character\":%d},\"end\":{\"line\":%d,\"character\":%d}},\"severity\":1,\"code\":\"ERR_SYNTAX\",\"source\":\"synapse\"}]", _el, _ec, _el, _ec+1);
                        }
                        if (_P_p_err == 0) {
                            int _s_cnt=0,_s_lvl=0,_s_err=0;
                            char _sn[4096][64],_st[4096][64]; int _sl[4096],_sc[4096];
                            #define _SEM_SD(n,t,c) do{ int _i; for(_i=0;_i<_s_cnt;_i++) if(strcmp(_sn[_i],n)==0&&_sl[_i]==_s_lvl){ _s_err=1; _i=-2; break; } if(_i>=0||_s_cnt==0){ if(_i<0||_i>=_s_cnt)_i=_s_cnt; strcpy(_sn[_i],n); strcpy(_st[_i],t); _sl[_i]=_s_lvl; _sc[_i]=c; _s_cnt++; } }while(0);
                            #define _SEM_SI() _s_lvl++;
                            #define _SEM_SO() do{ while(_s_cnt>0&&_sl[_s_cnt-1]==_s_lvl) _s_cnt--; _s_lvl--; }while(0);
                            { struct ListaNodo* _lp=_ast.sentencias; while(_lp){ void* _n=_lp->cabeza; if(_n){
                                const char* _tp=((struct Nodo*)_n)->tipo.datos;
                                if(strcmp(_tp,"DefinicionFuncion")==0){ struct DefinicionFuncion* _f=(struct DefinicionFuncion*)_n; _SEM_SD(_f->nombre.datos,"int",0); }
                            } _lp=_lp->cola; }}
                            { struct ListaNodo* _lp=_ast.sentencias; while(_lp){ void* _n=_lp->cabeza; if(_n){
                                const char* _tp=((struct Nodo*)_n)->tipo.datos;
                                if(strcmp(_tp,"DefinicionFuncion")==0){
                                    struct DefinicionFuncion* _f=(struct DefinicionFuncion*)_n;
                                    _SEM_SI();
                                    struct ListaParametro* _pl=(struct ListaParametro*)_f->parametros;
                                    while(_pl){ struct Parametro* _p=(struct Parametro*)_pl->cabeza; if(_p) _SEM_SD(_p->nombre.datos,_p->tipo.datos,0); _pl=_pl->cola; }
                                    struct ListaNodo* _bl=(struct ListaNodo*)_f->cuerpo;
                                    while(_bl){ void* _stmt=_bl->cabeza; if(_stmt){
                                        const char* _st=((struct Nodo*)_stmt)->tipo.datos;
                                        if(strcmp(_st,"AsignacionVariable")==0){
                                            struct AsignacionVariable* _a=(struct AsignacionVariable*)_stmt;
                                            int _si=-1; for(int _i=0;_i<_s_cnt;_i++) if(strcmp(_sn[_i],_a->nombre.datos)==0){ _si=_i;break; }
                                            if(_si<0){ _SEM_SD(_a->nombre.datos,"int",0); } else if(_sc[_si]){ _s_err=1; }
                                        }
                                    } _bl=_bl->cola; }
                                    _SEM_SO();
                                }
                            } _lp=_lp->cola; }}
                            if (_s_err) { _diag_count = 1; snprintf(_diag_json, sizeof(_diag_json), "[{\"range\":{\"start\":{\"line\":0,\"character\":0},\"end\":{\"line\":0,\"character\":1}},\"severity\":1,\"code\":\"ERR_SEM\",\"source\":\"synapse\"}]", _el, _ec, _el, _ec+1); } else { strcpy(_diag_json, "[]"); }
                        }
                    }
                }
                int _nn = snprintf(_lsp_buf, _LSP_BUF_SIZE, "{\"jsonrpc\":\"2.0\",\"method\":\"textDocument/publishDiagnostics\",\"params\":{\"uri\":\"%s\",\"diagnostics\":%s}}", _uri, _diag_json);
                fprintf(stdout, "Content-Length: %d\r\n\r\n%s", _nn, _lsp_buf);
                fflush(stdout);
            }
            if (strcmp(_ms, "textDocument/didClose") == 0) {
                _method_known = 1;
                int _n = snprintf(_lsp_buf, _LSP_BUF_SIZE, "{\"jsonrpc\":\"2.0\",\"method\":\"textDocument/publishDiagnostics\",\"params\":{\"uri\":\"%s\",\"diagnostics\":[]}}", _lsp_uri);
                fprintf(stdout, "Content-Length: %d\r\n\r\n%s", _n, _lsp_buf);
                fflush(stdout);
                _lsp_uri[0] = 0;
            }
            if (!_method_known) {
                if (!_is_notif) {
                    const char* _R = "{\"jsonrpc\":\"2.0\",\"id\":null,\"error\":{\"code\":-32601,\"message\":\"Method not found\"}}";
                    fprintf(stdout, "Content-Length: %d\r\n\r\n%s", (int)strlen(_R), _R);
                    fflush(stdout);
                }
            }
            _json_nodo_liberar(_method);
            _json_nodo_liberar(_id);
            _json_nodo_liberar(_params);
            _json_nodo_liberar(_msg);
        }
        fprintf(stderr, "[Synapse-LSP] Servidor finalizado\n");
    }
    int _ret_241 = r;
    return _ret_241;
}

int main(int argc, char** argv) {
    _g_argc = argc;
    _g_argv = argv;
    pool_init(POOL_BLOQUES, TAMANO_BLOQUE);
    return principal();
    synapse_esperar_hilos();
    return 0;
}